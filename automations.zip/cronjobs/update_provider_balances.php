<?php
// This script runs in the background via cron job.
// It fetches balance for every active provider and stores it in the database.
// It does NOT run when a user visits the admin page — so the page loads instantly.

set_time_limit(120); // allow up to 2 minutes for this background job only

define("BASEPATH", TRUE);
require __DIR__ . '/../vendor/autoload.php';
require __DIR__ . '/../app/init.php';

if (!class_exists('SMMApi')) {
    require __DIR__ . '/../app/classes/smm.php';
}

$providers = $conn->prepare("SELECT * FROM service_api WHERE status = 1");
$providers->execute();
$providers = $providers->fetchAll(PDO::FETCH_ASSOC);

$smmapi = new SMMApi();

foreach ($providers as $provider) {

    $veri = $smmapi->action(
        array('key' => $provider["api_key"], 'action' => 'balance'),
        $provider["api_url"]
    );

    if (is_object($veri) && isset($veri->balance) && empty($veri->error)) {
        // Success — store the fresh balance
        $update = $conn->prepare("UPDATE service_api SET cached_balance = :balance, cached_currency = :currency, balance_updated_at = NOW() WHERE id = :id");
        $update->execute(array(
            "balance"  => $veri->balance,
            "currency" => $veri->currency,
            "id"       => $provider["id"]
        ));
    } else {
        // Failed — mark provider as error status (same behavior as before)
        // and keep the last known cached balance untouched (don't overwrite with 0)
        $update = $conn->prepare("UPDATE service_api SET status = 2, balance_updated_at = NOW() WHERE id = :id");
        $update->execute(array("id" => $provider["id"]));
    }
}

echo "Balance sync completed at " . date("Y-m-d H:i:s") . " for " . count($providers) . " providers.\n";