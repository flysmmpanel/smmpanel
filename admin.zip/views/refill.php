<!---------   
=== Refill Management Admin View
=== flysmmpanel.com
=== Updated with full search + bulk actions + status badges + status filter bar + mobile responsive table
 ----------->  
 
 <?php include 'header.php'; ?>

<style>
.rf-badge { display:inline-block; padding:3px 10px; border-radius:20px; font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:.04em; white-space:nowrap; }
.rf-badge-Pending   { background:rgba(255,200,0,.15);  color:#ffc800; border:1px solid rgba(255,200,0,.35); }
.rf-badge-Refilling { background:rgba(91,156,246,.15); color:#5b9cf6; border:1px solid rgba(91,156,246,.35); }
.rf-badge-Completed { background:rgba(137,233,0,.15);  color:#89E900; border:1px solid rgba(137,233,0,.35); }
.rf-badge-Rejected  { background:rgba(255,80,80,.15);  color:#ff6b6b; border:1px solid rgba(255,80,80,.35); }
.rf-badge-Error     { background:rgba(255,140,0,.15);  color:#ff8c00; border:1px solid rgba(255,140,0,.35); }

/* ===== Status Filter Bar ===== */
.rf-filter-bar {
  display: flex;
  align-items: center;
  gap: 18px;
  flex-wrap: nowrap;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
  padding: 10px 4px;
  margin-bottom: 10px;
  border-bottom: 1px solid rgba(255,255,255,0.08);
  scrollbar-width: thin;
}
.rf-filter-bar::-webkit-scrollbar { height: 4px; }
.rf-filter-bar::-webkit-scrollbar-thumb { background: rgba(137,233,0,0.4); border-radius: 4px; }
.rf-filter-item {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  white-space: nowrap;
  font-size: 13px;
  font-weight: 600;
  color: #8a8a8a;
  text-decoration: none !important;
  padding: 4px 2px;
  border-bottom: 2px solid transparent;
  transition: color .15s ease, border-color .15s ease;
}
.rf-filter-item:hover { color: #c9c9c9; }
.rf-filter-item.active { color: #89E900; border-bottom-color: #89E900; }
.rf-filter-count {
  background: #3a3a3a;
  color: #fff;
  font-size: 11px;
  font-weight: 700;
  padding: 1px 7px;
  border-radius: 10px;
  line-height: 16px;
}
.rf-filter-item.active .rf-filter-count { background: #89E900; color: #142400; }

/* ===== Mobile responsive table wrapper ===== */
.rf-table-wrap {
  width: 100%;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
}
.rf-table-wrap table {
  min-width: 900px; /* keeps columns from squishing; wrap scrolls instead */
}
@media (max-width: 768px) {
  .rf-filter-bar { gap: 14px; }
}
</style>

<div class="container-fluid">

  <!-- Status filter bar -->
  <?php
    $rf_filters = [
      ''           => 'All Refills',
      'Pending'    => 'Pending',
      'Refilling'  => 'Refilling',
      'Completed'  => 'Completed',
      'Rejected'   => 'Rejected',
      'Error'      => 'Error',
    ];
  ?>
  <div class="rf-filter-bar">
    <?php foreach($rf_filters as $rf_val => $rf_label):
        $rf_active = ($search_where == 'status' && $search_word == $rf_val) || ($rf_val == '' && $search_where == '');
        if($rf_val == ''):
            $rf_count = countRow(['table' => 'refill_status']);
            $rf_href  = site_url('admin/refill');
        else:
            $rf_count = countRow(['table' => 'refill_status', 'where' => ['refill_status' => $rf_val]]);
            $rf_href  = site_url('admin/refill').'?search='.$rf_val.'&search_type=status';
        endif;
    ?>
      <a href="<?=$rf_href?>" class="rf-filter-item<?php if($rf_active) echo ' active'; ?>">
        <?=$rf_label?> <span class="rf-filter-count"><?=$rf_count ?: 0?></span>
      </a>
    <?php endforeach; ?>
  </div>

  <!-- Search bar -->
  <ul class="nav nav-tabs">
    <li class="pull-right custom-search">
      <form class="form-inline" action="<?=site_url("admin/refill")?>" method="get">
        <div class="input-group">
          <input type="text" name="search" class="form-control" value="<?=htmlspecialchars($search_word)?>" placeholder="Search...">
          <span class="input-group-btn search-select-wrap">
            <select class="form-control search-select" name="search_type">
              <option value="refill_apiid" <?php if($search_where=="refill_apiid") echo 'selected'; ?>>Refill API ID</option>
              <option value="order_id"    <?php if($search_where=="order_id")    echo 'selected'; ?>>Order ID</option>
              <option value="username"    <?php if($search_where=="username")    echo 'selected'; ?>>Username</option>
              <option value="status"      <?php if($search_where=="status")      echo 'selected'; ?>>Status</option>
            </select>
            <button type="submit" class="btn btn-default"><span class="fa fa-search"></span></button>
          </span>
        </div>
      </form>
    </li>
  </ul>

  <!-- Bulk action form -->
  <form method="post" action="<?=site_url("admin/refill/multi-action")?>" id="bulk-form">
    <div style="display:flex; align-items:center; gap:10px; margin:12px 0;">
      <label style="font-size:13px; color:#aaa;">
        <input type="checkbox" id="select-all"> Select All
      </label>
      <select name="bulkStatus" class="form-control" style="width:160px; display:inline-block;">
        <option value="">— Bulk Action —</option>
        <option value="Pending">Mark Pending</option>
        <option value="Refilling">Mark Refilling</option>
        <option value="Completed">Mark Completed</option>
        <option value="Rejected">Mark Rejected</option>
        <option value="Error">Mark Error</option>
      </select>
      <button type="submit" class="btn btn-default btn-sm" onclick="return confirmBulk()">Apply</button>
    </div>

    <div class="rf-table-wrap">
    <table class="table table-hover">
      <thead>
        <tr>
          <th width="30"><input type="checkbox" id="select-all-th"></th>
          <th style="font-weight:600;">ID</th>
          <th style="font-weight:600;">Username</th>
          <th style="font-weight:600;">Order ID</th>
          <th style="font-weight:600;">Link</th>
          <th style="font-weight:600;">Service Name</th>
          <th style="font-weight:600;">Date</th>
          <th style="font-weight:600;">Status</th>
          <th style="font-weight:600;">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($refills as $refill): ?>
        <tr>
          <td><input type="checkbox" name="order[<?=$refill['id']?>]" value="1" class="row-cb"></td>
          <td>
            <?=htmlspecialchars($refill['id'])?>
            <?php if($refill['refill_apiid'] != 0): ?>
              <div class="label label-api"><?=htmlspecialchars($refill['refill_apiid'])?></div>
            <?php endif; ?>
          </td>
          <td>
            <?=htmlspecialchars($refill['username'] ?? '—')?>
            <?php if($refill['refill_where'] == 'api'): ?>
              <span class="label label-api">API</span>
            <?php endif; ?>
          </td>
          <td>
            <a target="_blank" href="<?=site_url()?>/admin/orders?search=<?=urlencode($refill['order_id'])?>&search_type=order_id">
              <?=htmlspecialchars($refill['order_id'])?>
            </a>
            <?php if($refill['order_apiid'] != 0): ?>
              <div class="label label-api"><?=htmlspecialchars($refill['order_apiid'])?></div>
            <?php endif; ?>
          </td>
          <td>
            <a target="_blank" href="<?=htmlspecialchars($refill['order_url'])?>">
              <?=htmlspecialchars(substr($refill['order_url'],0,40)).(strlen($refill['order_url'])>40?'…':'')?>
            </a>
          </td>
          <td><?=htmlspecialchars($refill['service_name'])?></td>
          <td style="white-space:nowrap; font-size:12px;"><?=htmlspecialchars($refill['creation_date'])?></td>
          <td>
            <span class="rf-badge rf-badge-<?=htmlspecialchars($refill['refill_status'])?>">
              <?=htmlspecialchars($refill['refill_status'])?>
            </span>
          </td>
          <td class="service-block__action">
            <div class="dropdown pull-right">
              <button type="button" class="btn btn-default btn-xs dropdown-toggle btn-xs-caret" data-toggle="dropdown">
                Action <span class="caret"></span>
              </button>
              <ul class="dropdown-menu">
                <li class="dropdown dropdown-submenu">
                  <a href="#" class="dropdown_menu">Update Status</a>
                  <ul class="dropdown-menu submenu_drop">
                    <li><a href="#" data-toggle="modal" data-target="#confirmChange" data-href="<?=site_url("admin/refill/refill_Pending/".$refill['id'])?>">Pending</a></li>
                    <li><a href="#" data-toggle="modal" data-target="#confirmChange" data-href="<?=site_url("admin/refill/refill_refilling/".$refill['id'])?>">Refilling</a></li>
                    <li><a href="#" data-toggle="modal" data-target="#confirmChange" data-href="<?=site_url("admin/refill/refill_complete/".$refill['id'])?>">Completed</a></li>
                    <li><a href="#" data-toggle="modal" data-target="#confirmChange" data-href="<?=site_url("admin/refill/refill_reject/".$refill['id'])?>">Rejected</a></li>
                    <li><a href="#" data-toggle="modal" data-target="#confirmChange" data-href="<?=site_url("admin/refill/refill_Error/".$refill['id'])?>">Error</a></li>
                  </ul>
                </li>
              </ul>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    </div>
  </form>

  <!-- Pagination -->
  <?php if($paginationArr["count"] > 1): ?>
  <div class="row">
    <div class="col-sm-8">
      <nav>
        <ul class="pagination">
          <?php if($paginationArr["current"] != 1): ?>
          <li class="prev"><a href="<?=site_url("admin/refill/1/".$search_link)?>">&laquo;</a></li>
          <li class="prev"><a href="<?=site_url("admin/refill/".$paginationArr["previous"]."/".$search_link)?>">&lsaquo;</a></li>
          <?php endif;
          for($p=1; $p<=$pageCount; $p++):
            if($p >= ($paginationArr['current']-9) && $p <= ($paginationArr['current']+9)): ?>
          <li class="<?php if($p==$paginationArr["current"]) echo 'active'; ?>">
            <a href="<?=site_url("admin/refill/".$p."/".$search_link)?>"><?=$p?></a>
          </li>
          <?php endif; endfor;
          if($paginationArr["current"] != $paginationArr["count"]): ?>
          <li class="next"><a href="<?=site_url("admin/refill/".$paginationArr["next"]."/".$search_link)?>">&rsaquo;</a></li>
          <li class="next"><a href="<?=site_url("admin/refill/".$paginationArr["count"]."/".$search_link)?>">&raquo;</a></li>
          <?php endif; ?>
        </ul>
      </nav>
    </div>
  </div>
  <?php endif; ?>

</div>

<!-- Confirm modal -->
<div class="modal modal-center fade" id="confirmChange" tabindex="-1" role="dialog" data-backdrop="static">
  <div class="modal-dialog modal-dialog-center" role="document">
    <div class="modal-content">
      <div class="modal-body text-center">
        <h4>Are you sure you want to update the status?</h4>
        <div align="center">
          <a class="btn btn-primary" href="" id="confirmYes">Yes</a>
          <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
// Modal confirm href
$('#confirmChange').on('show.bs.modal', function(e) {
  $('#confirmYes').attr('href', $(e.relatedTarget).data('href'));
});

// Select all checkboxes
function syncAll(v) { document.querySelectorAll('.row-cb').forEach(cb => cb.checked = v); }
document.getElementById('select-all')?.addEventListener('change', function(){ syncAll(this.checked); document.getElementById('select-all-th').checked = this.checked; });
document.getElementById('select-all-th')?.addEventListener('change', function(){ syncAll(this.checked); document.getElementById('select-all').checked = this.checked; });

// Bulk submit guard
function confirmBulk() {
  var action  = document.querySelector('[name="bulkStatus"]').value;
  var checked = document.querySelectorAll('.row-cb:checked').length;
  if (!action) { alert('Please select a bulk action.'); return false; }
  if (!checked) { alert('Please select at least one row.'); return false; }
  return confirm('Apply "' + action + '" to ' + checked + ' refill(s)?');
}
</script>

<?php include 'footer.php'; ?>