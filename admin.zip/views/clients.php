<!---------   
=== Theme Author : Evan Ahmed EMon
=== Theme Designed By: TWG
=== Contact Whatsapp: +8801864614704
 ----------->  
 <?php include 'header.php'; ?>
<style>
.container-fluid  {
    width:100%;
}
.clients-table {
    overflow-y:scroll;
    width:calc(100% + 40px);
}
.tooltip-container {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
}

.tooltip5 {
    display: inline-flex;
    align-items: center;
}
</style>



<div class="container-fluid p-3">
     


  <ul class="nav nav-tabs">
    <li class="p-b m-r"><button class="btn btn-default" type="button" data-toggle="modal" data-target="#modalDiv" data-action="new_user">Registration user</button></li>
    <li class="p-b m-r"><button class="btn btn-default" type="button" data-toggle="modal" data-target="#modalDiv" data-action="export_user">Backup users</button></li>
    <li class="p-b m-r"><button class="btn btn-default" type="button" data-toggle="modal" data-target="#modalDiv" data-action="all_numbers">Contact Information</button></li>
    <li class="p-b m-r"><button class="btn btn-default" type="button" data-toggle="modal" data-target="#modalDiv" data-action="details">Details</button></li>
    
   </ul>
<div class="dropdown">
    <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
        <?= isset($units['unit']) ? $units['unit'] : 100; ?> Per Page
        <span style="margin-left:8px;" class="caret"></span>
    </button>
    <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
        <li><a href="<?= site_url("admin/clients") ?>?units=100">100 Per Page</a></li>
        <li><a href="<?= site_url("admin/clients") ?>?units=200">200 Per Page</a></li>
        <li><a href="<?= site_url("admin/clients") ?>?units=500">500 Per Page</a></li>
        <li><a href="<?= site_url("admin/clients") ?>?units=1000">1000 Per Page</a></li>
        <li><a href="<?= site_url("admin/clients") ?>?units=1500">1500 Per Page</a></li>
    </ul>
</div>
<br>
<form class="form-inline" action="" method="get" enctype="multipart/form-data">
<div class="input-group">
<input type="text" name="search" class="form-control" value="<?=$search_word?>" placeholder="Search">
<span class="input-group-btn search-select-wrap">
<select class="form-control search-select" name="search_type">
    <option value="username" <?php if( $search_where == "username" ): echo 'selected'; endif; ?>>Username</option>
    <option value="name" <?php if( $search_where == "name" ): echo 'selected'; endif; ?>>Name</option>
    <option value="email" <?php if( $search_where == "email" ): echo 'selected'; endif; ?>>Email</option>
    <option value="telephone" <?php if( $search_where == "telephone" ): echo 'selected'; endif; ?>>Phone No.</option>
    <option value="whatsapp" <?php if( $search_where == "whatsapp" ): echo 'selected'; endif; ?>>WhatsApp</option>
    <option value="telegram" <?php if( $search_where == "telegram" ): echo 'selected'; endif; ?>>Telegram</option>
    <option value="website" <?php if( $search_where == "website" ): echo 'selected'; endif; ?>>Website</option>
</select>
<button type="submit" class="btn btn-default"><span class="fa fa-search" aria-hidden="true"></span></button>
  </span>
       </div>
     </form>
  
 
<div class="clients-table">
  <table class="table" style="border:1px solid #ddd">


 

    <thead>
      <tr>      
      <th class="column-id">ID</th>
     <th width="10%">Username</th>
      <th>Email</th>
      <?php if( $settings["skype_area"] == 2 ): echo " <th>Phone number</th>"; endif; ?>
      <th>Balance</th>
      <th>Spent</th>  
<th>Orders</th>
<th>Services Discount</th>
<th>Special Pricing</th>
      <th nowrap="">Registered Date</th>
      <th>Last Login Date</th>
      <th></th>
      <th></th>
  </tr>
</thead>
<tbody>
  <?php foreach($clients as $client ): ?>
      <tr class="<?php if( $client["client_type"] == 1 ): echo "grey "; endif; ?>">
 
 <td>
 <?php echo $client["client_id"] ?>
 </td>
 

 
 <td>
          <?php echo $client["username"] ?> 
          
          <?php if($client["client_type"] == 2): ?>
           
            <a href="<?php echo site_url("admin/clients/view/".$client["client_id"]) ?>">
              <i class="fa-solid fa-right-to-bracket" aria-hidden="true"></i>
            </a>
          <?php else: ?>
        
            <div class="tooltip5" style="display: inline-block; margin-left: 5px;">
                <i class="fa fa-user-slash" style="color:gray;"></i>
                <span class="tooltiptext5">Deactive</span>
            </div>
          <?php endif; ?>
        </td>       
        

<td>
    <?php
    if ($_SESSION['user_role'] == 'admin') {
        echo $client["email"]; 
    } else {
        $encoded_email = base64_encode($client["email"]); 
        echo '<span class="__cf_email__" data-cfemail="' . $encoded_email . '">[email&#160;protected]</span>';
    }
    ?>

    <!-- Create a container for tooltips that will appear in the same line as email -->
    <div class="tooltip-container">
        
        <!-- Google Verified Tooltip -->
        <?php if (!empty($client["google_login_verified"]) && $client["google_login_verified"] == 1): ?>
            <span class="tooltip5">
                <i class="fab fa-google-plus-g" style="color:#DB4437;"></i>
                <span class="tooltiptext5">Google Verified</span>
            </span>
        <?php endif; ?>
        
        <!-- Email Verification Status -->
        <?php if ($client["email_type"] == 2): ?>
        
        <?php else: ?>
            <span class="tooltip5">
                <i style="color:red;" class="far fa-times-circle"></i>
                <span class="tooltiptext5">Email is Not Verified</span>
            </span>
        <?php endif; ?> 

        <!-- Name Tooltip -->
        <?php if (!empty($client["name"])): ?>
            <span class="tooltip5">
                <i class="fa-regular fa-circle-user" style="color:blue;"></i>
                <span class="tooltiptext5"><?php echo $client["name"]; ?></span>
            </span>
        <?php endif; ?> 
        
        <!-- Telegram Tooltip -->
        <?php if (!empty($client["telegram"])): ?>
            <span class="tooltip5">
                <i class="fab fa-telegram" style="color:#0088cc;"></i>
                <span class="tooltiptext5"><?php echo $client["telegram"]; ?></span>
            </span>
        <?php endif; ?>

        <!-- WhatsApp Tooltip -->
        <?php if (!empty($client["whatsapp"])): ?>
            <span class="tooltip5">
                <i class="fab fa-whatsapp" style="color:#25D366;"></i>
                <span class="tooltiptext5"><?php echo $client["whatsapp"]; ?></span>
            </span>
        <?php endif; ?>

        <!-- Website Tooltip -->
        <?php if (!empty($client["website"])): ?>
            <span class="tooltip5">
                <i class="fas fa-globe" style="color:#0077B5;"></i>
                <span class="tooltiptext5"><?php echo $client["website"]; ?></span>
            </span>
        <?php endif; ?>
    </div>
</td>




<?php if( $settings["skype_area"] == 2 ): echo "<td>"; echo $client["telephone"]; echo "</td>"; endif; ?>
               



<td>
 <div style="width:85px;">
 <?php echo format_amount_string($settings["site_base_currency"],$client["balance"]); ?>
 </div>
 </td>
 <td>

<div style="width:85px;">
 <?php echo format_amount_string($settings["site_base_currency"],$client["spent"]);?>
 </div>
 </td>
<td><?php echo countRow(["table"=>"orders","where"=>["client_id"=>$client["client_id"]] ]) ?></td>
<td>
  <button type="button" class="btn btn-default btn-xs disabled " style="cursor:pointer;" href="#" class="dcs-pointer" data-toggle="modal" data-target="#modalDiv" data-id="<?php echo $client["client_id"] ?>" data-action="set_discount_percentage">Discount (<?php echo $client ["discount_percentage"]; ?>%)</button>
</td>
<td><button type="button" class="btn btn-default btn-xs <?php if( !countRow(["table"=>"clients_price","where"=>["client_id"=>$client["client_id"]] ]) ): echo "disabled"; endif; ?> " style="cursor:pointer"  data-toggle="modal" data-target="#modalDiv" data-id="<?php echo $client["client_id"] ?>" data-action="price_user">Special Pricing
               
                       <?php if( countRow(["table"=>"clients_price","where"=>["client_id"=>$client["client_id"]] ]) ): ?>  <span class="badge badge-xs"><?php echo countRow(["table"=>"clients_price","where"=>["client_id"=>$client["client_id"]] ]) ?></span><?php endif; ?>
 
               
            </button></td>


<td>
  <?php 
    // Register Date
    $registerDate = strtotime($client["register_date"]);
    // Show only date and time (e.g., 1st Jan 2024 at 1:00pm)
    $formattedDate = date('jS M Y \a\t g:ia', $registerDate);
    
    // Display formatted date and time
    echo $formattedDate;
  ?>
</td>


<td>
  <?php 
    // Check if login_date is not NULL or empty
    if (!is_null($client["login_date"]) && $client["login_date"] != '') {
      $loginDate = strtotime($client["login_date"]);
      // Show date and time (e.g., 1st Jan 2024 at 1:00pm)
      $formattedLoginDate = date('jS M Y \a\t g:ia', $loginDate);
      
      // Display formatted login date and time
      echo $formattedLoginDate;
    } else {
      // If no login date, show --
      echo " ";
    }
  ?>
</td>

<td>
  <?php 
    // Check if login_ip is not NULL or empty
    if (!is_null($client["login_ip"]) && $client["login_ip"] != '') {
      // Call the getCountryCodeByIP function with the login_ip
      $countryCode = getCountryCodeByIP($client["login_ip"]);
      
      // Display the country code
      echo $countryCode;
    } else {
      // If no IP address, show --
      echo " ";
    }
  ?>
</td>
<td>
 
</td>


 <td class="td-caret">
 <div class="dropdown pull-right">
   <button type="button" class="btn btn-primary btn-xs dropdown-toggle btn-xs-caret" data-toggle="dropdown">Action</button>
   <ul class="dropdown-menu">
       <li>
  <a class="dcs-pointer" data-toggle="modal" data-target="#modalDiv" data-action="edit_user" data-id="<?=$client["client_id"]?>">Edit User</a>
       </li>
    
    
    
    <li>
  <a class="dcs-pointer" data-toggle="modal" data-target="#modalDiv" data-action="sign_history" data-id="<?=$client["client_id"]?>">Sign-in history</a>
</li>
    
    

       <li>
  <a class="dcs-pointer" data-toggle="modal" data-target="#modalDiv" data-action="pass_user" data-id="<?=$client["client_id"]?>">Change Password</a>
       </li>

       <?php if( $client["client_type"] == 1 ): $type = "active"; else: $type = "deactive"; endif; ?>
       <li>
  <a href="<?php echo site_url("admin/clients/".$type."/".$client["client_id"]) ?>"><?php if( $client["client_type"] == 1 ): echo "Activate"; else: echo "Deactivate"; endif; ?> Account</a>
       </li>
       
       <li>
  <a href="<?php echo site_url("admin/clients/del_price/".$client["client_id"]) ?>">Delet Special Pricing</a>
       </li>
       <li><a style="cursor:pointer;"  data-toggle="modal" data-target="#modalDiv" data-action="secret_user" data-id="<?=$client["client_id"]?>">Special Categories</a></li>
   </ul>
 </div>
 </td>
      </tr>
  <?php endforeach; ?>
</tbody>
</table>
</div>
     </div>

   <?php if( $paginationArr["count"] > 1 ): ?>
     <div class="row">
        <div class="col-sm-8">
  <nav>
 <ul class="pagination">
 <?php if( $paginationArr["current"] != 1 ): ?>
  <li class="prev"><a href="<?php echo site_url("admin/clients/1".$search_link) ?>">&laquo;</a></li>
  <li class="prev"><a href="<?php echo site_url("admin/clients/".$paginationArr["previous"].$search_link) ?>">&lsaquo;</a></li>
  <?php
      endif;
      for ($page=1; $page<=$pageCount; $page++):
        if( $page >= ($paginationArr['current']-9) and $page <= ($paginationArr['current']+9) ):
  ?>
  <li class="<?php if( $page == $paginationArr["current"] ): echo "active"; endif; ?> "><a href="<?php echo site_url("admin/clients/".$page.$search_link) ?>"><?=$page?></a></li>
  <?php endif; endfor;
        if( $paginationArr["current"] != $paginationArr["count"] ):
  ?>
  <li class="next"><a href="<?php echo site_url("admin/clients/".$paginationArr["next"].$search_link) ?>" data-page="1">&rsaquo;</a></li>
  <li class="next"><a href="<?php echo site_url("admin/clients/".$paginationArr["count"].$search_link) ?>" data-page="1">&raquo;</a></li> 
  <?php endif; ?>
 </ul>
  </nav>
        </div>
     </div>
   <?php endif; ?>
</div>


<div class="modal modal-center fade" id="confirmChange" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static">
   <div class="modal-dialog modal-dialog-center" role="document">
      <div class="modal-content">
<div class="modal-body text-center">
   <h4>Are you sure you want to update the status?</h4>
   <div align="center">
<a class="btn btn-primary" href="" id="confirmYes">Yes</a>
<button type="button" class="btn btn-default" data-dismiss="modal">No</button>
   </div>
</div>
      </div>
   </div>
</div>
<script type="text/javascript">
    window.onload = function() {
        var elements = document.getElementsByClassName('__cf_email__');
        
       
        for (var i = 0; i < elements.length; i++) {
            var encodedEmail = elements[i].getAttribute('data-cfemail');
            var decodedEmail = decodeEmail(encodedEmail);
            elements[i].innerHTML = decodedEmail; 
        }
    };

    
    function decodeEmail(encoded) {
        var decodedEmail = atob(encoded); 
        return decodedEmail;
    }
</script>

<?php include 'footer.php'; ?>