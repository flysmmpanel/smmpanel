<?php require admin_view('header'); ?>

<style>
    
    .row {
        margin-top: 10px;
    }
    
/* Add to your existing <style> */
.card-box {
    position: relative; /* Ensure pseudo-element is relative to the card */
    overflow: hidden;   /* Hide overflow for animation */
}

/* Animated Gradient Border */
.card-box::before {
    content: "";
    position: absolute;
    top: -2px;
    left: -2px;
    right: -2px;
    bottom: -2px;
    background: linear-gradient(270deg, #FF6F61, #FFD700, #00BFFF, #32CD32, #FF6F61);
    background-size: 1000% 1000%; /* Big background for smooth animation */
    z-index: 0;
    border-radius: 10px; /* Match card radius */
    animation: borderMove 10s linear infinite;
}

/* Put card content above the animated border */
.card-box > * {
    position: relative;
    z-index: 1;
}

/* Animation Keyframes */
@keyframes borderMove {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

/* ===== Premium Headings ===== */
.card h6 {
    font-size: 18px;
    font-weight: 700;
    position: relative;
    display: inline-block;
    padding-bottom: 6px;
}

.card h6::after {
    content: "";
    position: absolute;
    left: 0;
    bottom: 0;
    width: 50%;
    height: 3px;
    background: linear-gradient(90deg, #FFD700, #FF6F61); /* gold to coral gradient */
    border-radius: 3px;
}

/* ===== Universal Responsive Cards ===== */
.container-fluid > .row, 
.card-row, /* agar top lists ya analytics me alag row class use ho */
.row.mb-4 {
    display: flex;
    flex-wrap: wrap;
    gap: 15px; /* spacing between cards */
}

.container-fluid > .row > div,
.card-row > div,
.row.mb-4 > div {
    flex: 1 1 22%; /* default: 4 cards per row */
    min-width: 220px;
}

/* Medium screens (md/lg) → 2 per row */
@media (max-width: 992px) {
    .container-fluid > .row > div,
    .card-row > div,
    .row.mb-4 > div {
        flex: 1 1 45%;
    }
}

/* Small screens (xs/sm) → 1 per row */
@media (max-width: 576px) {
    .container-fluid > .row > div,
    .card-row > div,
    .row.mb-4 > div {
        flex: 1 1 100%;
    }
}

/* ===== Top List Styles: ID | Username | Budget ===== */
.top-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.top-list li {
    display: flex;
    align-items: center;
    justify-content: space-between; /* space between for ID, username, budget */
    padding: 12px 18px;
    margin-bottom: 10px;
    border-radius: 12px;
    background: #f1f3f5;
    box-shadow: 0 4px 8px rgba(0,0,0,0.05);
    transition: all 0.3s ease;
    cursor: pointer;
    font-weight: 500;
}

/* Hover effect */
.top-list li:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 16px rgba(0,0,0,0.12);
}

/* Premium Top 3 Gradients */
.top-list li:nth-child(1) { background: linear-gradient(90deg, #FFD700, #FFE066); color: #000; }
.top-list li:nth-child(2) { background: linear-gradient(90deg, #C0C0C0, #E0E0E0); color: #000; }
.top-list li:nth-child(3) { background: linear-gradient(90deg, #CD7F32, #E6A07A); color: #fff; }

/* Remove medal icons */
.top-list li::before { content: none; }

/* ID styling: left with right border */
.top-list li .client-id,
.top-list li .service-id {
    flex: 0 0 auto; /* fixed width */
    padding-right: 12px;
    margin-right: 12px;
    border-right: 2px solid rgba(0,0,0,0.2);
    text-align: left;
}

/* Username / Title: center aligned */
.top-list li .username,
.top-list li .service-name {
    flex: 1 1 auto;
    text-align: center;
    font-weight: 600;
    font-size: 15px;
    padding: 0 12px;
}

/* Budget styling: right aligned with left border */
.top-list li strong {
    flex: 0 0 auto; /* fit to content */
    margin-left: 12px;
    padding-left: 12px;
    border-left: 2px solid rgba(0,0,0,0.2);
    font-weight: 700;
    font-size: 15px;
    text-align: right;
}

</style>


<div class="container-fluid mt-4">

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
        <h4>Analytics Dashboard</h4>
        <input type="text" id="daterange" class="form-control mt-2 mt-md-0" style="max-width:250px;" />
    </div>

    <!-- ===== Orders Summary Boxes ===== -->
    <div class="row mb-4">
        <div class="col-md-3 mb-2">
            <div class="card-box text-center p-3 shadow-sm" style="border-radius:12px; background:#28a745; color:#fff;">
                <h6>Total Completed</h6>
                <h4 id="totalCompleted">0</h4>
            </div>
        </div>
        <div class="col-md-3 mb-2">
            <div class="card-box text-center p-3 shadow-sm" style="border-radius:12px; background:#dc3545; color:#fff;">
                <h6>Total Canceled</h6>
                <h4 id="totalCanceled">0</h4>
            </div>
        </div>
        <div class="col-md-3 mb-2">
            <div class="card-box text-center p-3 shadow-sm" style="border-radius:12px; background:#ffc107; color:#fff;">
                <h6>Total Partial</h6>
                <h4 id="totalPartial">0</h4>
            </div>
        </div>
        <div class="col-md-3 mb-2">
            <div class="card-box text-center p-3 shadow-sm" style="border-radius:12px; background:#17a2b8; color:#fff;">
                <h6>Total Orders</h6>
                <h4 id="totalOrders">0</h4>
            </div>
        </div>
    </div>

    <!-- ===== Orders Trend Line Chart ===== -->
    <div class="card shadow-sm p-4 mb-4" style="background:#fff; border-radius:12px;">
        <h6 class="mb-3">Orders Trend (Completed / Canceled / Partial)</h6>
        <canvas id="ordersTrendChart"></canvas>
    </div>
      
      <hr>
      
    <!-- ===== Funds Summary Boxes ===== -->
    <div class="row mb-4">
        <div class="col-md-4 mb-2">
            <div class="card-box text-center p-3 shadow-sm" style="border-radius:12px; background:#6c757d; color:#fff;">
                <h6>Total Lifetime</h6>
                <h4 id="totalLifetime">0</h4>
            </div>
        </div>
        <div class="col-md-4 mb-2">
            <div class="card-box text-center p-3 shadow-sm" style="border-radius:12px; background:#007bff; color:#fff;">
                <h6>Total Added</h6>
                <h4 id="totalAdded">0</h4>
            </div>
        </div>
        <div class="col-md-4 mb-2">
            <div class="card-box text-center p-3 shadow-sm" style="border-radius:12px; background:#fd7e14; color:#fff;">
                <h6>Total Deducted</h6>
                <h4 id="totalDeducted">0</h4>
            </div>
        </div>
    </div>

    <!-- ===== Funds Trend Line Chart ===== -->
    <div class="card shadow-sm p-4 mb-4" style="background:#fff; border-radius:12px;">
        <h6 class="mb-3">Funds Trend (Added / Deducted)</h6>
        <canvas id="fundsTrendChart"></canvas>
    </div>
    
    <hr>
    
    <!-- ===== CLIENTS SUMMARY BOXES ===== -->
<div class="row mb-4">
    <div class="col-md-4 mb-2">
        <div class="card-box text-center p-3 shadow-sm bg-dark text-white">
            <h6>Total Clients</h6>
            <h4 id="totalClients">0</h4>
        </div>
    </div>

    <div class="col-md-4 mb-2">
        <div class="card-box text-center p-3 shadow-sm bg-primary text-white">
            <h6>Google Clients</h6>
            <h4 id="googleClients">0</h4>
        </div>
    </div>

    <div class="col-md-4 mb-2">
        <div class="card-box text-center p-3 shadow-sm bg-success text-white">
            <h6>Normal Clients</h6>
            <h4 id="normalClients">0</h4>
        </div>
    </div>
</div>

<div class="card shadow-sm p-4 mb-4">
    <h6 class="mb-3">Signup Source (Google vs Normal)</h6>
    <canvas id="signupSourceChart"></canvas>
</div>

<hr>

    <div class="card shadow-sm p-4 mb-4">
    <h6>Top 10 Spenders</h6>
    <ul id="topSpendersList" class="top-list"></ul>
</div> 
       
         <hr>

<div class="card shadow-sm p-4 mb-4">
    <h6>Top 10 Depositors</h6>
    <ul id="topDepositorsList" class="top-list"></ul>
</div>

          <hr>

<div class="card shadow-sm p-4 mb-4">
    <h6>Top 10 Revenue Services</h6>
    <ul id="topServicesList" class="top-list"></ul>
</div>


</div>

<?php require admin_view('footer'); ?>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- Date Range Picker -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css"/>
<script src="https://cdn.jsdelivr.net/npm/moment/min/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>

<script>
let ordersChart;
let fundsChart;
let signupSourceChart;

function loadAnalytics(start, end){
    fetch("<?= site_url('admin/analytics_data') ?>?start="+start+"&end="+end)
    .then(res => res.json())
    .then(data => {
        const ctxOrders = document.getElementById('ordersTrendChart').getContext('2d');
        const ctxFunds  = document.getElementById('fundsTrendChart').getContext('2d');

        // --- Orders totals for summary boxes ---
        const totalCompleted = data.completed.reduce((a,b)=>a+b,0);
        const totalCanceled  = data.canceled.reduce((a,b)=>a+b,0);
        const totalPartial   = data.partial.reduce((a,b)=>a+b,0);
        const totalOrders    = totalCompleted + totalCanceled + totalPartial;

        document.getElementById('totalCompleted').innerText = totalCompleted;
        document.getElementById('totalCanceled').innerText  = totalCanceled;
        document.getElementById('totalPartial').innerText   = totalPartial;
        document.getElementById('totalOrders').innerText    = totalOrders;

        // Destroy previous charts
        if(ordersChart) ordersChart.destroy();
        if(fundsChart)  fundsChart.destroy();
        if(signupSourceChart) signupSourceChart.destroy();

        // ---- Orders Trend Chart ----
        ordersChart = new Chart(ctxOrders, {
            type: 'line',
            data: {
                labels: data.labels,
                datasets: [
                    { label: 'Completed', data: data.completed, borderColor: '#28a745', backgroundColor: 'rgba(40,167,69,0.1)', fill:false, tension:0.3 },
                    { label: 'Canceled',  data: data.canceled,  borderColor: '#dc3545', backgroundColor: 'rgba(220,53,69,0.1)', fill:false, tension:0.3 },
                    { label: 'Partial',   data: data.partial,   borderColor: '#ffc107', backgroundColor: 'rgba(255,193,7,0.1)', fill:false, tension:0.3 }
                ]
            },
            options: { responsive:true, plugins:{ legend:{position:'top'} }, scales:{ y:{ beginAtZero:true } } }
        });

        // ---- Funds Trend Chart ----
        fundsChart = new Chart(ctxFunds, {
            type: 'line',
            data: {
                labels: data.labels,
                datasets: [
                    { label:'Added',    data:data.addedFunds,    borderColor:'#007bff', backgroundColor:'rgba(0,123,255,0.1)', fill:false, tension:0.3 },
                    { label:'Deducted', data:data.deductedFunds, borderColor:'#fd7e14', backgroundColor:'rgba(253,126,20,0.1)', fill:false, tension:0.3 }
                ]
            },
            options: { responsive:true, plugins:{ legend:{position:'top'} }, scales:{ y:{ beginAtZero:true } } }
        });

        // ---- Update Funds Totals ----
         const totalAdded = data.addedFunds.reduce((a,b)=>a+b,0);
const totalDeducted = data.deductedFunds.reduce((a,b)=>a+b,0);
const totalNet = totalAdded + totalDeducted;

document.getElementById('totalAdded').innerText = totalAdded.toFixed(2);
document.getElementById('totalDeducted').innerText = totalDeducted.toFixed(2);
document.getElementById('totalLifetime').innerText = totalNet.toFixed(2);

// ===== CLIENTS BAR CHART =====
const ctxSignup = document.getElementById('signupSourceChart').getContext('2d');

signupSourceChart = new Chart(ctxSignup, {
    type: 'line',
    data: {
        labels: data.labels,
        datasets: [
            {
                label: 'Google Clients',
                data: data.googleUsers,
                borderColor: '#4285F4',
                backgroundColor: 'rgba(66,133,244,0.1)',
                fill: false,
                tension: 0.3,
                pointRadius: 3
            },
            {
                label: 'Normal Clients',
                data: data.normalUsers,
                borderColor: '#28a745',
                backgroundColor: 'rgba(40,167,69,0.1)',
                fill: false,
                tension: 0.3,
                pointRadius: 3
            }
        ]
    },
    options: {
        responsive: true,
        plugins: {
            legend: { position: 'top' }
        },
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

        
// ===== CLIENT SUMMARY BOXES =====
document.getElementById('totalClients').innerText = data.totalClients;
document.getElementById('googleClients').innerText = data.totalGoogle;
document.getElementById('normalClients').innerText = data.totalNormal;


      // ----- TOP SPENDERS -----
let spenderHTML = '';
data.topSpenders.forEach(row=>{
    spenderHTML += `
        <li class="list-group-item d-flex justify-content-between" data-client-id="${row.client_id}">
            <div class="client-id">ID: ${row.client_id}</div>
            <div class="username">${row.username}</div>
            <strong>${parseFloat(row.total_spent).toFixed(2)}</strong>
        </li>
    `;
});
document.getElementById('topSpendersList').innerHTML = spenderHTML;

// ----- TOP DEPOSITORS -----
let depositorHTML = '';
data.topDepositors.forEach(row=>{
    depositorHTML += `
        <li class="list-group-item d-flex justify-content-between" data-client-id="${row.client_id}">
            <div class="client-id">ID: ${row.client_id}</div>
            <div class="username">${row.username}</div>
            <strong>${parseFloat(row.total_deposit).toFixed(2)}</strong>
        </li>
    `;
});
document.getElementById('topDepositorsList').innerHTML = depositorHTML;

// ----- TOP SERVICES -----
let servicesHTML = '';
data.topServices.forEach(row=>{
    servicesHTML += `
        <li class="list-group-item d-flex justify-content-between" data-service-id="${row.service_id}">
            <div class="service-id">ID: ${row.service_id}</div>
            <div class="service-name">${row.service_name}</div>
            <strong>${parseFloat(row.total_revenue).toFixed(2)}</strong>
        </li>
    `;
});
document.getElementById('topServicesList').innerHTML = servicesHTML;
    
    }).catch(err => { console.error('Analytics data fetch error:', err); });
    

}


// ---- Date Range Picker Init ----
$(function() {
    let start = moment().subtract(6,'days');
    let end   = moment();

    function cb(start,end){
        $('#daterange').val(start.format('YYYY-MM-DD')+' - '+end.format('YYYY-MM-DD'));
        loadAnalytics(start.format('YYYY-MM-DD'), end.format('YYYY-MM-DD'));
    }

    $('#daterange').daterangepicker({
        startDate:start,
        endDate:end,
        ranges:{
            'Today':[moment(),moment()],
            'Last 7 Days':[moment().subtract(6,'days'),moment()],
            'Last 30 Days':[moment().subtract(29,'days'),moment()],
            'This Month':[moment().startOf('month'),moment().endOf('month')],
            'Lifetime':[moment().subtract(5,'years'),moment()]
        }
    }, cb);

    cb(start,end);
});
</script>
