<!---------   
=== Theme Author : Evan Ahmed EMon
=== Theme Designed By: TWG
=== Contact Whatsapp: +8801864614704
=== Modernized Glass & Color UI
 ----------->  
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <base href="<?= site_url() ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $settings["site_name"] ?></title>
    
    <!-- CDN Links -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/11.10.6/sweetalert2.css"/> 
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.18/summernote.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.8.1/css/bootstrap-select.css">
    <link rel="stylesheet" href="https://itsjavi.com/fontawesome-iconpicker/dist/css/fontawesome-iconpicker.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    <!-- Custom Admin Assets -->
    <link href="<?php echo site_url('assets/admin/bootstrap.css'); ?>" rel="stylesheet">
    <link href="<?php echo site_url('assets/admin/style.css'); ?>" rel="stylesheet">
    <link href="<?php echo site_url('assets/admin/toastDemo.css'); ?>" rel="stylesheet">
    <link href="<?php echo site_url('assets/admin/tooltip.css'); ?>" rel="stylesheet">
    <link href="<?php echo site_url('assets/admin/tinytoggle.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo site_url('assets/admin/iziToast.min.css'); ?>" rel="stylesheet">
    <link href="<?php echo site_url('assets/admin/image-picker.css'); ?>" rel="stylesheet">
    <link href="<?php echo site_url('assets/admin/maint.css'); ?>" rel="stylesheet">
    <link href="<?php echo site_url('assets/admin/adcustom.css'); ?>" rel="stylesheet">
    <link href="<?php echo site_url('assets/admin/fontawesome5pro.css'); ?>" rel="stylesheet">

    <!-- Scripts -->
    <script src="https://kit.fontawesome.com/e1d6cf68d9.js" crossorigin="anonymous"></script>
    <script src="<?php echo site_url('assets/admin/iziToast.min.js'); ?>"></script>

<style>
/* ── Global Font & Badge Fixes ── */
.badge.badge-primary { color: white; }
.far { font-family: "Font Awesome 5 Pro"; font-weight: 400; }
.fa, .fas { font-family: "Font Awesome 5 Pro"; font-weight: 900; }

/* ── Modern Top Navbar Styling ── */
.navbar-default {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border-bottom: 1px solid rgba(226, 232, 240, 0.8);
    box-shadow: 0 4px 20px -2px rgba(0, 0, 0, 0.05);
    transition: all 0.3s ease;
}
.dark-mode .navbar-default {
    background: rgba(15, 23, 42, 0.92);
    border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    box-shadow: 0 4px 25px -2px rgba(0, 0, 0, 0.3);
}
.navbar-nav > li > a {
    font-weight: 500;
    font-size: 13.5px;
    padding: 15px 12px;
    display: flex;
    align-items: center;
    gap: 6px;
    transition: all 0.2s ease;
}
.navbar-nav > li > a i {
    font-size: 16px;
    transition: transform 0.2s ease;
}
.navbar-nav > li:hover > a i {
    transform: translateY(-2px);
}

/* ── Top Nav Colorful Icon Badges ── */
.nav-icon-dashboard { color: #3b82f6 !important; }
.nav-icon-overview  { color: #8b5cf6 !important; }
.nav-icon-clients   { color: #10b981 !important; }
.nav-icon-payments  { color: #f59e0b !important; }
.nav-icon-services  { color: #06b6d4 !important; }
.nav-icon-orders    { color: #6366f1 !important; }
.nav-icon-tickets   { color: #ef4444 !important; }
.nav-icon-earning   { color: #10b981 !important; }
.nav-icon-more      { color: #64748b !important; }
.nav-icon-appearance{ color: #ec4899 !important; }
.nav-icon-settings  { color: #64748b !important; }
.nav-icon-feedback  { color: #14b8a6 !important; }
.nav-icon-theme     { color: #f59e0b !important; }

/* ── Glowing Badges ── */
.nav-badge-purple {
    background: linear-gradient(135deg, #8b5cf6, #6366f1);
    color: #fff;
    border-radius: 12px;
    padding: 3px 8px;
    font-size: 10px;
    font-weight: 700;
    box-shadow: 0 2px 8px rgba(99, 102, 241, 0.4);
}
.nav-badge-red {
    background: linear-gradient(135deg, #ef4444, #f43f5e);
    color: #fff;
    border-radius: 12px;
    padding: 3px 8px;
    font-size: 10px;
    font-weight: 700;
    box-shadow: 0 2px 8px rgba(239, 68, 68, 0.5);
    animation: pulseGlow 2s infinite;
}
@keyframes pulseGlow {
    0%, 100% { transform: scale(1); box-shadow: 0 2px 8px rgba(239, 68, 68, 0.5); }
    50% { transform: scale(1.06); box-shadow: 0 0 14px rgba(239, 68, 68, 0.8); }
}

/* ── Upgraded Dropdown Menus ── */
.dropdown-menu {
    border-radius: 12px;
    border: 1px solid rgba(226, 232, 240, 0.8);
    box-shadow: 0 15px 35px -5px rgba(0, 0, 0, 0.12), 0 5px 15px rgba(0, 0, 0, 0.04);
    padding: 6px;
}
.dark-mode .dropdown-menu {
    background: #1e293b;
    border-color: rgba(255, 255, 255, 0.08);
}
.dropdown-menu > li > a {
    border-radius: 8px;
    padding: 8px 14px;
    font-size: 13px;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: all 0.15s ease;
}
.dropdown-menu > li > a:hover {
    background: #f1f5f9;
    transform: translateX(3px);
}
.dark-mode .dropdown-menu > li > a:hover {
    background: #334155;
    color: #fff;
}
</style>

<!-- ===== FLOATING GLASS BOTTOM QUICK NAV CSS ===== -->
<style>
/* ── Entrance Animation ── */
@keyframes qnavFloatIn {
    0% {
        opacity: 0;
        transform: translate(-50%, 45px) scale(0.92);
    }
    60% {
        transform: translate(-50%, -4px) scale(1.02);
    }
    100% {
        opacity: 1;
        transform: translate(-50%, 0) scale(1);
    }
}

/* ── Floating Glass Dock ── */
#admin-quick-nav {
    position: fixed;
    bottom: 18px;
    left: 50%;
    transform: translate(-50%, 0);
    z-index: 99999;
    
    width: auto;
    min-width: 340px;
    max-width: 92vw;
    height: 64px;
    padding: 6px 10px;
    
    display: flex;
    align-items: center;
    justify-content: space-around;
    gap: 6px;

    /* Glassmorphism Formula */
    background: rgba(255, 255, 255, 0.72);
    backdrop-filter: blur(24px) saturate(190%);
    -webkit-backdrop-filter: blur(24px) saturate(190%);
    border: 1px solid rgba(255, 255, 255, 0.85);
    border-radius: 26px;
    box-shadow: 
        0 14px 40px -5px rgba(0, 0, 0, 0.12),
        0 6px 15px -2px rgba(0, 0, 0, 0.05),
        inset 0 1px 1px 0 rgba(255, 255, 255, 0.9);

    /* Animation on reload */
    animation: qnavFloatIn 0.65s cubic-bezier(0.16, 1, 0.3, 1) forwards;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

/* Dark Mode Glass */
body.dark-mode #admin-quick-nav {
    background: rgba(15, 23, 42, 0.78);
    backdrop-filter: blur(24px) saturate(200%);
    -webkit-backdrop-filter: blur(24px) saturate(200%);
    border: 1px solid rgba(255, 255, 255, 0.12);
    box-shadow: 
        0 18px 45px -5px rgba(0, 0, 0, 0.5),
        0 4px 12px rgba(0, 0, 0, 0.4),
        inset 0 1px 1px 0 rgba(255, 255, 255, 0.15);
}

/* ── Individual Nav Item ── */
.qnav-item {
    flex: 1;
    min-width: 58px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 3px;
    text-decoration: none !important;
    color: #64748b !important;
    font-size: 10px;
    font-weight: 600;
    letter-spacing: 0.3px;
    padding: 6px 10px;
    border-radius: 18px;
    position: relative;
    cursor: pointer;
    transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
}
body.dark-mode .qnav-item {
    color: #94a3b8 !important;
}

/* Hover State */
.qnav-item:hover {
    color: #0f172a !important;
    background: rgba(0, 0, 0, 0.04);
    transform: translateY(-2px);
}
body.dark-mode .qnav-item:hover {
    color: #f8fafc !important;
    background: rgba(255, 255, 255, 0.08);
}

/* ── Active State (Glass Pill) ── */
.qnav-item.qnav-active {
    color: #2563eb !important;
    background: rgba(37, 99, 235, 0.1);
    font-weight: 700;
    box-shadow: inset 0 0 0 1px rgba(37, 99, 235, 0.2);
}
body.dark-mode .qnav-item.qnav-active {
    color: #60a5fa !important;
    background: rgba(96, 165, 250, 0.15);
    box-shadow: inset 0 0 0 1px rgba(96, 165, 250, 0.3);
}

/* Active Top Indicator Glow */
.qnav-item.qnav-active::before {
    content: '';
    position: absolute;
    top: 3px;
    width: 14px;
    height: 3px;
    background: #3b82f6;
    border-radius: 3px;
    box-shadow: 0 0 10px #3b82f6;
}
body.dark-mode .qnav-item.qnav-active::before {
    background: #60a5fa;
    box-shadow: 0 0 10px #60a5fa;
}

/* ── Icon & SVG Styling with Dynamic Gradients ── */
.qnav-icon {
    width: 22px;
    height: 22px;
    display: flex;
    align-items: center;
    justify-content: center;
    position: relative;
    transition: transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);
}
.qnav-icon svg {
    width: 21px;
    height: 21px;
    fill: none;
    stroke: currentColor;
    stroke-width: 1.9;
    stroke-linecap: round;
    stroke-linejoin: round;
    transition: all 0.25s ease;
}

/* Micro-bounces & Glow on Hover/Active */
.qnav-item:hover .qnav-icon,
.qnav-item.qnav-active .qnav-icon {
    transform: translateY(-2px) scale(1.1);
}
.qnav-item.qnav-active .qnav-icon svg {
    filter: drop-shadow(0 2px 8px rgba(37, 99, 235, 0.45));
}
body.dark-mode .qnav-item.qnav-active .qnav-icon svg {
    filter: drop-shadow(0 2px 10px rgba(96, 165, 250, 0.6));
}

.qnav-label {
    font-size: 9.5px;
    line-height: 1;
    white-space: nowrap;
}
</style>
</head>

<body class="<?php if($admin["mode"]=="dark" ): echo "dark-mode" ; endif; ?>">

<nav class="navbar navbar-static-top navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
              aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
    </div>
    <div id="navbar" class="collapse navbar-collapse">

      <ul class="nav navbar-nav navbar-left-block">
        <?php if ($admin["access"]["admin_access"] && $_SESSION["msmbilisim_adminlogin"]) : ?>

          <?php if ($admin["access"]["admin_access"]): ?>
            <li class="<?php if(route(1) == "index" || empty(route(1))): echo 'active' ; endif; ?>">
              <a class="ajax-link" href="<?php echo site_url("admin") ?>">
                <i class="bi bi-house-door nav-icon-dashboard"></i> Dashboard 
              </a>
            </li>
          <?php endif; ?>

          <?php if ($admin["access"]["admin_access"]): ?>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                    <i class="bi bi-bar-chart-line nav-icon-overview"></i> Overview
                    <span class="caret"></span>
                </a>
                <ul class="dropdown-menu dropdown-max-height">
                    <li class="<?php if (route(1) == "analytics") : echo 'active'; endif; ?>">
                        <a class="ajax-link" href="<?php echo site_url("admin/analytics"); ?>">
                            <i class="bi bi-graph-up text-primary"></i> Analytics
                        </a>
                    </li>
                    <li class="<?php if (route(1) == "insights") : echo 'active'; endif; ?>">
                        <a class="ajax-link" href="<?php echo site_url("admin/insights"); ?>">
                            <i class="bi bi-lightbulb text-warning"></i> Insights
                        </a>
                    </li>
                </ul>
            </li>
          <?php endif; ?>

          <?php if ($admin["access"]["admin_access"] && $admin["access"]["users"]): ?>
            <li class="<?php if (route(1) == "clients") : echo 'active' ; endif; ?>">
                <a class="ajax-link" href="<?php echo site_url("admin/clients") ?>">
                    <i class="bi bi-person-lines-fill nav-icon-clients"></i><span> Clients</span>
                </a>
            </li>
          <?php endif; ?>

          <?php if ($admin["access"]["admin_access"]): ?>
            <li class="<?php if (route(1) == "fund-add-history") : echo 'active' ; endif; ?>">
                <a class="ajax-link" href="<?php echo site_url("admin/fund-add-history"); ?>">
                    <i class="bi bi-cash-stack nav-icon-payments"></i> Payments
                </a>
            </li>
          <?php endif; ?>

          <?php if ($admin["access"]["admin_access"] && $admin["access"]["services"]): ?>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> 
                    <i class="bi bi-list-task nav-icon-services"></i> Services <span class="caret"></span>
                </a>
                <ul class="dropdown-menu dropdown-max-height">
                    <li class="<?php if (route(1) == "services") : echo 'active'; endif; ?>">
                        <a class="ajax-link" href="<?php echo site_url("admin/services") ?>">
                            <i class="bi bi-list-columns text-info"></i><span> Services</span>
                        </a>
                    </li>
                    <li class="<?php if (route(1) == "archived_services") : echo 'active'; endif; ?>">
                        <a class="ajax-link" href="<?php echo site_url("admin/archived-services") ?>">
                            <i class="fas fa-archive text-warning"></i><span> Archived Services</span>
                        </a>
                    </li>
                    <li class="<?php if (route(1) == "update-prices") : echo 'active'; endif; ?>">
                        <a class="ajax-link" href="<?php echo site_url("admin/update-prices") ?>">
                            <i class="bi bi-cloud-upload text-primary"></i><span> Update Prices</span>
                        </a>
                    </li>
                    <li class="<?php if (route(1) == "price-update") : echo 'active'; endif; ?>">
                        <a class="ajax-link" href="<?php echo site_url("admin/price-update") ?>">
                            <i class="fa fa-refresh text-success" aria-hidden="true"></i><span> Price Updates</span>
                        </a>
                    </li>
                    <li class="<?php if (route(1) == "bulk") : echo 'active'; endif; ?>">
                        <a class="ajax-link" href="<?php echo site_url("admin/bulk") ?>">
                            <i class="bi bi-file-earmark-spreadsheet text-info"></i><span> Bulk Services Editor</span>
                        </a>
                    </li>
                    <li class="<?php if (route(1) == "bulkc") : echo 'active'; endif; ?>">
                        <a class="ajax-link" href="<?php echo site_url("admin/bulkc") ?>">
                            <i class="fa fa-list-ol text-purple"></i><span> Bulk Category Editor</span>
                        </a>
                    </li>
                    <li class="<?php if (route(1) == "category-sort") : echo 'active'; endif; ?>">
                        <a class="ajax-link" href="<?php echo site_url("admin/category-sort") ?>">
                            <i class="bi bi-sort-alpha-down text-primary"></i><span> Category Sort</span>
                        </a>
                    </li>
                </ul>
            </li>
          <?php endif; ?>

          <?php if ($admin["access"]["admin_access"] && $admin["access"]["orders"]): ?>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                    <i class="bi bi-bag-check nav-icon-orders"></i> Orders 
                    <span class='badge nav-badge-purple'>
                        <?php 
                            $total_tasks = countRow(['table' => 'tasks']) ?: 0;
                            echo $total_tasks;
                        ?>
                    </span>
                </a>
                <ul class="dropdown-menu dropdown-max-height">
                    <li class="<?php if (route(1) == "orders") : echo 'active'; endif; ?>">
                        <a class="ajax-link" href="<?php echo site_url("admin/orders") ?>">
                            <i class="bi bi-bag text-primary"></i> Orders
                            <span class='badge nav-badge-purple'>
                                <?= countRow(['table' => 'tasks']) ?: 0; ?>
                            </span>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo site_url('admin/tasks') ?>">
                            <i class="bi bi-x-circle text-danger"></i> Cancel
                            <span class='badge nav-badge-purple'>
                                <?= countRow(['table' => 'tasks', 'where' => ['task_status' => 'inprogress']]) ?: 0; ?>
                            </span>
                        </a>
                    </li>
                    <li class="<?php if (route(1) == "refill") : echo 'active'; endif; ?>">
                        <a href="<?php echo site_url('admin/refill') ?>">
                            <i class="bi bi-arrow-repeat text-success"></i> Refill
                            <span class='badge nav-badge-purple'>
                                <?= countRow(['table' => 'refills', 'where' => ['status' => 'pending']]) ?: 0; ?>
                            </span>
                        </a>
                    </li>
                    <li class="<?php if (route(1) == "dripfeeds") : echo 'active'; endif; ?>">
                        <a href="<?php echo site_url('admin/dripfeeds') ?>">
                            <i class="bi bi-clock-history text-warning"></i> Dripfeeds
                            <span class='badge nav-badge-purple'>
                                <?= countRow(['table' => 'dripfeeds', 'where' => ['status' => 'pending']]) ?: 0; ?>
                            </span>
                        </a>
                    </li>
                </ul>
            </li>
          <?php endif; ?>

          <?php if ($admin["access"]["admin_access"] && $admin["access"]["tickets"]): ?>
            <li class="<?php if (route(1) == "tickets") : echo 'active' ; endif; ?>">
                <a class="ajax-link" href="<?php echo site_url("admin/tickets") ?>">
                    <i class="bi bi-headset nav-icon-tickets"></i><span> Tickets 
                    <?php if(countRow(["table"=>"tickets","where"=>["client_new"=>2]]) > 0): ?>
                        <span class="badge nav-badge-red"><?= countRow(["table"=>"tickets","where"=>["client_new"=>2]]); ?></span>
                    <?php endif; ?>
                    </span>
                </a>
            </li>
          <?php endif; ?>

          <?php if ($admin["access"]["admin_access"] && $admin["access"]["referral"] && $admin["access"]["payments"]): ?>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                    <i class="bi bi-cash-coin nav-icon-earning"></i> Earning <span class="caret"></span>
                </a>
                <ul class="dropdown-menu dropdown-max-height">
                    <li class="<?php if (route(1) == "referrals") : echo 'active'; endif; ?>">
                        <a class="ajax-link" href="<?php echo site_url("admin/referrals") ?>">
                            <i class="bi bi-person-plus text-primary"></i> Referrals
                            <span class='badge nav-badge-purple'>
                                <?= countRow(['table' => 'referrals']) ?: 0; ?>
                            </span>
                        </a>
                    </li>
                    <li class="<?php if (route(1) == "payouts") : echo 'active'; endif; ?>">
                        <a href="<?php echo site_url("admin/payouts") ?>">
                            <i class="bi bi-currency-dollar text-success"></i> Payouts
                            <span class='badge nav-badge-purple'>
                                <?= countRow(['table' => 'payouts', 'where' => ['status' => 'pending']]) ?: 0; ?>
                            </span>
                        </a>
                    </li>
                    <li class="<?php if (route(1) == "earn") : echo 'active'; endif; ?>">
                        <a href="<?php echo site_url("admin/earn") ?>">
                            <i class="bi bi-coin text-warning"></i> Earn
                            <span class='badge nav-badge-purple'>
                                <?= countRow(['table' => 'earn', 'where' => ['status' => 'pending']]) ?: 0; ?>
                            </span>
                        </a>
                    </li>
                    <li class="<?php if (route(1) == "kuponlar") : echo 'active'; endif; ?>">
                        <a href="<?php echo site_url("admin/kuponlar") ?>">
                            <i class="bi bi-ticket-perforated text-info"></i> Coupons
                            <span class='badge nav-badge-purple'>
                                <?= countRow(['table' => 'kuponlar', 'where' => ['status' => 'active']]) ?: 0; ?>
                            </span>
                        </a>
                    </li>
                </ul>
            </li>
          <?php endif; ?>

          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
              <i class="bi bi-grid nav-icon-more"></i> Additionals <span class="caret"></span>
            </a>
            <ul class="dropdown-menu dropdown-max-height">
              <li class="<?php if (route(1) == "referrals") : echo 'active' ; endif; ?>">
                <a class="ajax-link" href="<?php echo site_url("admin/referrals") ?>"><i class="bi bi-award text-primary"></i><span> Affiliates</span></a>
              </li>
              <li class="<?php if (route(1) == "broadcasts") : echo 'active' ; endif; ?>">
                <a class="ajax-link" href="<?php echo site_url("admin/broadcasts") ?>"><i class="bi bi-megaphone text-info"></i><span> Broadcasts</span></a>
              </li>
              <li class="<?php if (route(1) == "logs") : echo 'active' ; endif; ?>">
                <a class="ajax-link" href="<?php echo site_url("admin/logs") ?>"><i class="bi bi-file-earmark-text text-secondary"></i><span> Panel Logs</span></a>
              </li>
              <li class="<?php if (route(1) == "child-panels") : echo 'active'; endif; ?>">
                <a class="ajax-link" href="<?php echo site_url("admin/child-panels") ?>">
                    <i class="bi bi-layout-text-window-reverse text-warning"></i><span> Child Panels</span>
                </a>
              </li>
              <li class="<?php if (route(1) == "reports") : echo 'active' ; endif; ?>">
                <a class="ajax-link" href="<?php echo site_url("admin/reports") ?>"><i class="bi bi-bar-chart-line text-success"></i><span> Reports</span></a>
              </li>
              <li class="<?php if (route(1) == "updates") : echo 'active' ; endif; ?>">
                <a class="ajax-link" href="<?php echo site_url("admin/updates") ?>"><i class="bi bi-cloud-arrow-down text-primary"></i><span> Updates</span></a>
              </li>
            </ul>
          </li>

          <?php if ($admin["access"]["admin_access"] && $admin["access"]["appearance"]): ?>
            <li class="<?php if (route(1) == "appearance") : echo 'active' ; endif; ?>">
                <a class="ajax-link" href="<?php echo site_url("admin/appearance") ?>"><i class="bi bi-palette nav-icon-appearance"></i><span> Appearance</span></a>
            </li>
          <?php endif; ?>

          <?php if ($admin["access"]["admin_access"] && $admin["access"]["settings"]): ?>
            <li class="<?php if (route(1) == "settings") : echo 'active' ; endif; ?>">
                <a class="ajax-link" href="<?php echo site_url("admin/settings") ?>"><i class="bi bi-gear nav-icon-settings"></i><span> Settings</span></a>
            </li>
          <?php endif; ?>

          <?php if ($admin["access"]["admin_access"] && $admin["access"]["feedback"]): ?>
            <li class="<?php if (route(1) == "feedback") : echo 'active' ; endif; ?>">
                <a class="ajax-link" href="<?php echo site_url("admin/feedback") ?>"><i class="bi bi-chat-left-dots nav-icon-feedback"></i><span> Feedback</span></a>
            </li>
          <?php endif; ?>

          <?php if ($admin["mode"] == "dark") : ?>
            <li><a id="enable-light-mode" href="javascript:void(0)"><i class="bi bi-sun-fill nav-icon-theme"></i><span> Light</span></a></li>
          <?php else: ?>
            <li><a id="enable-dark-mode" href="javascript:void(0)"><i class="bi bi-moon-stars-fill nav-icon-theme"></i><span> Dark</span></a></li>
          <?php endif; ?>

          <li class="dropdown">
            <a class="ajax-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="true">
              <i class="bi bi-person-circle text-primary" style="font-size:18px;"></i><span class="caret"></span>
            </a>
            <ul class="dropdown-menu">
              <?php if ($admin["access"]["admin_access"] && $admin["access"]["manager"]): ?>
              <li class="<?php if(route(1) == "manager") : echo "active" ; endif;?>">
                <a href="<?php echo site_url("admin/manager"); ?>" class="ajax-link"><i class="bi bi-shield-lock text-primary"></i> Manager</a>
              </li>
              <?php endif; ?>
              <li role="separator" class="divider"></li>
              <li class="<?php if (route(1) == "account") : echo 'active' ; endif; ?>">
                <a class="ajax-link" href="<?php echo site_url("admin/account") ?>"><i class="bi bi-person text-info"></i><span> Account</span></a>
              </li>
              <li>
                <a class="ajax-link text-danger" href="admin/logout"><i class="bi bi-box-arrow-right text-danger"></i> Logout</a>
              </li>
            </ul>
          </li>

        <?php endif; ?>
      </ul>

    </div>
  </div>
</nav>

<!-- ===== FLOATING GLASS BOTTOM QUICK DOCK ===== -->
<nav id="admin-quick-nav">

  <!-- Dashboard -->
  <a href="<?php echo site_url('admin'); ?>" class="qnav-item" data-route="index" title="Dashboard">
    <span class="qnav-icon">
      <svg viewBox="0 0 24 24">
        <path d="M3 9.5L12 3l9 6.5V20a1 1 0 01-1 1H4a1 1 0 01-1-1V9.5z" stroke="#3b82f6"/>
        <path d="M9 21V12h6v9" stroke="#3b82f6"/>
      </svg>
    </span>
    <span class="qnav-label">Dashboard</span>
  </a>

  <!-- Clients -->
  <a href="<?php echo site_url('admin/clients'); ?>" class="qnav-item" data-route="clients" title="Clients">
    <span class="qnav-icon">
      <svg viewBox="0 0 24 24">
        <circle cx="9" cy="7" r="4" stroke="#10b981"/>
        <path d="M3 21v-2a4 4 0 014-4h4a4 4 0 014 4v2" stroke="#10b981"/>
        <path d="M16 3.13a4 4 0 010 7.75" stroke="#10b981"/>
        <path d="M21 21v-2a4 4 0 00-3-3.87" stroke="#10b981"/>
      </svg>
    </span>
    <span class="qnav-label">Clients</span>
  </a>

  <!-- Orders -->
  <a href="<?php echo site_url('admin/orders'); ?>" class="qnav-item" data-route="orders" title="Orders">
    <span class="qnav-icon">
      <svg viewBox="0 0 24 24">
        <rect x="3" y="3" width="18" height="18" rx="2" stroke="#6366f1"/>
        <path d="M8 7h8M8 11h8M8 15h5" stroke="#6366f1"/>
      </svg>
    </span>
    <span class="qnav-label">Orders</span>
  </a>

  <!-- Services -->
  <a href="<?php echo site_url('admin/services'); ?>" class="qnav-item" data-route="services" title="Services">
    <span class="qnav-icon">
      <svg viewBox="0 0 24 24">
        <path d="M12 2L2 7l10 5 10-5-10-5z" stroke="#06b6d4"/>
        <path d="M2 17l10 5 10-5" stroke="#06b6d4"/>
        <path d="M2 12l10 5 10-5" stroke="#06b6d4"/>
      </svg>
    </span>
    <span class="qnav-label">Services</span>
  </a>

  <!-- Settings -->
  <a href="<?php echo site_url('admin/settings'); ?>" class="qnav-item" data-route="settings" title="Settings">
    <span class="qnav-icon">
      <svg viewBox="0 0 24 24">
        <circle cx="12" cy="12" r="3" stroke="#8b5cf6"/>
        <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z" stroke="#8b5cf6"/>
      </svg>
    </span>
    <span class="qnav-label">Settings</span>
  </a>

</nav>

<script>
(function(){
  // Active highlight using PHP route() value
  var currentRoute = '<?php echo route(1); ?>';
  var items = document.querySelectorAll('#admin-quick-nav .qnav-item');
  items.forEach(function(item){
    var r = item.getAttribute('data-route');
    if(r === currentRoute || (r === 'index' && (currentRoute === '' || currentRoute === 'index'))){
      item.classList.add('qnav-active');
    }
  });
  // Adjust bottom padding so floating dock never overlaps table content or forms
  document.body.style.paddingBottom = '95px';
})();
</script>