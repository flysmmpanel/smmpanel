<!---------   
=== Custom Page : Price Update (Category + Services)
 -----------> 
 
<?php include 'header.php'; ?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tom-select@2.2.2/dist/css/tom-select.bootstrap5.min.css">
<style>
.ts-dropdown-content::-webkit-scrollbar {
    width: 6px;
}
.ts-dropdown-content::-webkit-scrollbar-thumb {
    background: #ccc;
    border-radius: 10px;
}
</style>

<style>
/* SELECTED ITEMS SCROLL */
.ts-control {
    max-height: 300px;   /* height control */
    overflow-y: auto;    /* vertical scroll */
    overflow-x: hidden;
}

/* scrollbar styling */
.ts-control::-webkit-scrollbar {
    width: 5px;
}
.ts-control::-webkit-scrollbar-thumb {
    background: #bbb;
    border-radius: 10px;
}
</style>

<div class="container-fluid margin-top-container">
   <div class="container">
      <div class="row">
         <div class="col-md-6 col-md-offset-3">

            <div class="panel panel-default">
               <div class="panel-heading">
                  <strong>Update Prices (Category / Services)</strong>
               </div>

               <form id="priceUpdateForm" action="admin/price-update" method="POST">

               <div class="panel-body">
                   
                  <!-- CATEGORY -->
                  <div class="form-group">
                     <label>Select Category</label>
                   <div style="margin-bottom:10px;">
   <button type="button" id="select_all_categories" class="btn btn-success btn-sm">
      Select All
   </button>
   <button type="button" id="unselect_all_categories" class="btn btn-danger btn-sm">
      Unselect All
   </button>
</div>

                     <select name="category_ids[]" id="category_select" multiple>
                        <option value="all">All Categories</option>
                        <?php foreach($categories as $cat): ?>
                        <option value="<?= $cat["category_id"] ?>">
                           <?= $cat["category_name"] ?>
                        </option>
                        <?php endforeach; ?>
                     </select>
                  </div>
                  
                  <!-- PROVIDER FILTER -->
<div class="form-group">
   <label>Select Provider</label>
                  <div style="margin-bottom:10px;">
   <button type="button" id="select_all_provider" class="btn btn-success btn-sm">
      Select All
   </button>
   <button type="button" id="unselect_all_provider" class="btn btn-danger btn-sm">
      Unselect All
   </button>
</div>
   <select name="provider_ids[]" id="provider_select" multiple>
      <option value="all">All Providers</option>
   </select>
</div>
        
                  <!-- SERVICES -->
                  <div class="form-group">
                     <label>Select Services</label>
                    <div style="margin-bottom:10px;">
   <button type="button" id="select_all_services" class="btn btn-success btn-sm">
      Select All
   </button>
   <button type="button" id="unselect_all_services" class="btn btn-danger btn-sm">
      Unselect All
   </button>
</div>

                     <select name="service_ids[]" id="service_select" multiple>
                        <option value="all">All Services</option>
                        <?php foreach($services as $srv): ?>
                        <option value="<?= $srv["service_id"] ?>" data-category="<?= $srv["category_id"] ?>">
                           <?= $srv["service_id"] ?> — <?= $srv["service_name"] ?> (Cat: <?= $srv["category_id"] ?>)
                        </option>
                        <?php endforeach; ?>
                     </select>
                  </div>

                  <!-- PROFIT -->
                  <div class="form-group">
                     <label>Profit Percentage</label>
                     <div class="input-group">
                        <input type="number" name="profit_percent" id="profit_percent" class="form-control" placeholder="10">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-percent"></i></span>
                     </div>
                  </div>

                  <!-- ACTION -->
                  <div class="form-group" id="action_type_div"></div>

               </div>

               <div class="panel-footer text-center">
                  <button type="submit" class="btn btn-primary btn-lg">
                     Update Prices 🚀
                  </button>
               </div>

               </form>

            </div>

         </div>
      </div>
   </div>
</div>

<script src="//code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/tom-select@2.2.2/dist/js/tom-select.complete.min.js"></script>


<script>
$(document).ready(function () {

    let allServices = <?php echo json_encode($services); ?>;

    // =========================
    // CATEGORY
    // =========================
    let categorySelect = new TomSelect("#category_select", {
    plugins: ['remove_button'],
    placeholder: "Select categories...",
    searchField: ['text', 'value'],

    render: {

        option: function (data, escape) {
            return `
                <div>

                    <span style="background:#3498db;color:#fff;padding:2px 6px;border-radius:4px;font-size:11px;">
                        CAT ${data.value}
                    </span>

                    — <b>${escape(data.text)}</b>

                </div>
            `;
        },

        item: function (data, escape) {
            return `
                <div>

                    <span style="background:#3498db;color:#fff;padding:2px 6px;border-radius:4px;font-size:11px;">
                        CAT ${data.value}
                    </span>

                    — <b>${escape(data.text)}</b>

                </div>
            `;
        }
    }
});

    // =========================
    // PROVIDER
    // =========================
    let providerSelect = new TomSelect("#provider_select", {
    plugins: ['remove_button'],
    placeholder: "Select providers...",
    searchField: ['text', 'value'],

    render: {

        option: function (data, escape) {
            return `
                <div>

                    <span style="
                        background: linear-gradient(135deg,#8e44ad,#9b59b6);
                        color:#fff;
                        padding:2px 8px;
                        border-radius:20px;
                        font-size:10px;
                        font-weight:600;
                    ">
                        PROVIDER
                    </span>

                    — <b>${escape(data.text)}</b>

                </div>
            `;
        },

        item: function (data, escape) {
            return `
                <div>

                    <span style="
                        background: linear-gradient(135deg,#8e44ad,#9b59b6);
                        color:#fff;
                        padding:2px 8px;
                        border-radius:20px;
                        font-size:10px;
                        font-weight:600;
                    ">
                        PROVIDER
                    </span>

                    — <b>${escape(data.text)}</b>

                </div>
            `;
        }
    }
});

    // =========================
    // SERVICE
    // =========================
    let serviceSelect = new TomSelect("#service_select", {
    plugins: ['remove_button'],
    placeholder: "Search services...",
    maxOptions: 20000,
    searchField: ['text', 'value'],

    render: {

        option: function (data, escape) {
            return `
                <div>

                    <span style="background:#3498db;color:#fff;padding:2px 6px;border-radius:4px;font-size:11px;">
                        CAT ${data.category_id}
                    </span>

                    <span style="background:#2ecc71;color:#fff;padding:2px 6px;border-radius:4px;font-size:11px;margin-left:5px;">
                        ID ${data.value}
                    </span>

                    — <b>${escape(data.text)}</b>

                    <div style="margin-top:5px;display:flex;gap:5px;flex-wrap:wrap;">

                        <span style="
                            background: linear-gradient(135deg,#8e44ad,#9b59b6);
                            color:#fff;
                            padding:2px 8px;
                            border-radius:20px;
                            font-size:10px;
                            font-weight:600;
                        ">
                            ${escape(data.provider_name || 'No Provider')}
                        </span>

                        <span style="
                            background:#ecf0f1;
                            color:#555;
                            padding:2px 6px;
                            border-radius:10px;
                            font-size:10px;
                        ">
                            ${escape(data.api_name || 'Manual')}
                        </span>

                    </div>

                </div>
            `;
        },

        item: function (data, escape) {
            return `
                <div>

                    <span style="background:#3498db;color:#fff;padding:2px 6px;border-radius:4px;font-size:11px;">
                        CAT ${data.category_id}
                    </span>

                    <span style="background:#2ecc71;color:#fff;padding:2px 6px;border-radius:4px;font-size:11px;margin-left:5px;">
                        ID ${data.value}
                    </span>

                    — <b>${escape(data.text)}</b>

                    <span style="
                        background: linear-gradient(135deg,#8e44ad,#9b59b6);
                        color:#fff;
                        padding:2px 8px;
                        border-radius:20px;
                        font-size:10px;
                        font-weight:600;
                        margin-left:5px;
                    ">
                        ${escape(data.provider_name || 'No Provider')}
                    </span>


                </div>
            `;
        }
    }
});

    // =========================
    // FILTER SERVICES
    // =========================
    function filterServices() {

        let cats = categorySelect.getValue() || [];
        let providers = providerSelect.getValue() || [];

        let currentSelected = serviceSelect.getValue() || [];
        let validSelected = [];

        serviceSelect.clearOptions();

        // Select All option
        serviceSelect.addOption({
            value: "select_all",
            text: "Select All"
        });

        allServices.forEach(function (srv) {

            let matchCategory =
                cats.includes("all") ||
                cats.length === 0 ||
                cats.includes(String(srv.category_id));

            let matchProvider =
                providers.includes("all") ||
                providers.length === 0 ||
                providers.includes(srv.provider_name);

            if (matchCategory && matchProvider) {

                let id = String(srv.service_id);

                serviceSelect.addOption({
                    value: id,
                    text: srv.service_name,
                    category_id: srv.category_id,
                    provider_name: srv.provider_name,
                    api_name: srv.api_name
                });

                if (currentSelected.includes(id)) {
                    validSelected.push(id);
                }
            }
        });

        serviceSelect.refreshOptions(false);

        if (validSelected.length) {
            serviceSelect.setValue(validSelected);
        }
    }

    // =========================
    // LOAD PROVIDERS
    // =========================
    function loadProviders() {

        let selectedCategories = categorySelect.getValue() || [];

        providerSelect.clearOptions();

        providerSelect.addOption({
            value: "all",
            text: "All Providers"
        });

        let seen = {};

        allServices.forEach(function (srv) {

            let matchCategory =
                selectedCategories.includes("all") ||
                selectedCategories.length === 0 ||
                selectedCategories.includes(String(srv.category_id));

            if (matchCategory && srv.provider_name && !seen[srv.provider_name]) {
                seen[srv.provider_name] = true;

                providerSelect.addOption({
                    value: srv.provider_name,
                    text: `${srv.provider_name} (${srv.api_name || 'N/A'})`
                });
            }
        });

        providerSelect.refreshOptions(false);
    }

    // =========================
    // EVENTS
    // =========================
    categorySelect.on('change', function () {
        loadProviders();
        filterServices();
    });

    providerSelect.on('change', function () {
        filterServices();
    });

    // =========================
    // INITIAL LOAD
    // =========================
    loadProviders();
    filterServices();

    // =========================
    // CATEGORY BUTTONS
    // =========================
    $("#select_all_categories").click(function () {

        let all = [];

        $("#category_select option").each(function () {
            if ($(this).val() !== "all") {
                all.push($(this).val());
            }
        });

        categorySelect.setValue(all);
        loadProviders();
        filterServices();
    });

    $("#unselect_all_categories").click(function () {
        categorySelect.clear();
        providerSelect.clear();
        serviceSelect.clear();
    });

    
    // =========================
    // PROVIDER  BUTTONS
    // =========================
    $("#select_all_provider").click(function () {

    let allProviders = [];

    Object.values(providerSelect.options).forEach(function (opt) {
        if (opt.value !== "all") {
            allProviders.push(opt.value);
        }
    });

    providerSelect.setValue(allProviders);

});

     $("#unselect_all_provider").click(function () {
    providerSelect.clear();
    serviceSelect.clear();
});
    // =========================
    // SERVICE BUTTONS
    // =========================
    $("#select_all_services").click(function () {

        let allValues = [];

        Object.values(serviceSelect.options).forEach(function (opt) {
            if (opt.value !== "select_all") {
                allValues.push(opt.value);
            }
        });

        serviceSelect.setValue(allValues);
    });

    $("#unselect_all_services").click(function () {
        serviceSelect.clear();
    });

    // =========================
    // SELECT ALL INSIDE DROPDOWN
    // =========================
    serviceSelect.on('change', function (value) {

        if (Array.isArray(value) && value.includes("select_all")) {

            let allValues = [];

            Object.values(serviceSelect.options).forEach(function (opt) {
                if (opt.value !== "select_all") {
                    allValues.push(opt.value);
                }
            });

            serviceSelect.setValue(allValues);
        }
    });

    // =========================
    // MULTI ID SEARCH
    // =========================
    serviceSelect.on('type', function (str) {

        if (!str || str.indexOf(",") === -1) return;

        let ids = str.split(",").map(x => x.trim()).filter(Boolean);

        let matched = [];

        ids.forEach(function (id) {
            if (serviceSelect.options[id]) {
                matched.push(id);
            }
        });

        if (matched.length) {
            serviceSelect.setValue(matched);
        }
    });

    // =========================
    // PROFIT UI
    // =========================
    $("#profit_percent").keyup(function () {

        let val = $(this).val();

        if (val) {
            $("#action_type_div").html(`
                <label>Action</label>
                <select name="action_type" class="form-control">
                    <option value="set_profit">Set profit to ${val}%</option>
                    <option value="increase_profit">Increase by ${val}%</option>
                    <option value="decrease_profit">Decrease by ${val}%</option>
                </select>
            `);
        } else {
            $("#action_type_div").html("");
        }
    });

    // =========================
    // AJAX SUBMIT
    // =========================
    $("#priceUpdateForm").submit(function (e) {

        e.preventDefault();

        $.ajax({
            type: "POST",
            url: $(this).attr("action"),
            data: $(this).serialize(),
            success: function (res) {
                alert(res);
            },
            error: function () {
                alert("Error occurred!");
            }
        });

    });

});
</script>
<?php include 'footer.php'; ?>