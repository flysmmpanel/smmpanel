<div class="container-fluid">
    <h3>Leaderboard Management</h3>
    <hr>

    <div class="alert alert-success">
        Leaderboard Admin Page is Working ✅
    </div>

    <p>Total Users: <?= $total_users ?></p>
    <p>Total Participants: <?= $total_participants ?></p>
</div>