<!---------   
=== Theme Author : Evan Ahmed EMon
=== Theme Designed By: TWG
=== Contact Whatsapp: +8801864614704
----------->

<div class="col-md-8">

<?php if($active){ ?>
<!-- Active Section -->
<div class="card mb-4">
   <div class="card-header bg-primary text-white">
      <h5 class="mb-0">Active Integrations</h5>
   </div>
   <div class="card-body">
      <table class="table table-bordered table-striped">
         <thead class="thead-light">
            <tr>
               <th>Icon</th>
               <th>Name & Description</th>
               <th>Actions</th>
            </tr>
         </thead>
         <tbody>
         <?php foreach($active as $int) { ?>
            <tr>
               <td class="align-middle text-center" style="width: 10%;">
                  <img src="<?=$int['icon_url']?>" alt="<?=$int['name']?>" class="img-thumbnail" style="max-width: 50px;">
               </td>
               <td class="align-middle">
                  <strong><?=$int['name']?></strong>
                  <p class="text-muted mb-0"><?=$int['description']?></p>
               </td>
               <td class="align-middle text-center">
                  <?php if($int['id'] == 13) { ?>
                     <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modalDiv" data-action="edit_google">Edit</button>
                  <?php } elseif($int['id'] == 15) { ?>
                     <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modalDiv" data-action="edit_seo">Edit</button>
                  <?php } else { ?>
                     <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modalDiv" data-action="edit_code" data-id="<?=$int['id']?>">Edit</button>
                  <?php } ?>
               </td>
            </tr>
         <?php } ?>
         </tbody>
      </table>
   </div>
</div>
<?php } ?>

<?php if($other){ ?>
<!-- Other Section -->
<div class="card mb-4">
   <div class="card-header bg-secondary text-white">
      <h5 class="mb-0">Other Integrations</h5>
   </div>
   <div class="card-body">
      <table class="table table-bordered table-striped">
         <thead class="thead-light">
            <tr>
               <th>Icon</th>
               <th>Name & Description</th>
               <th>Actions</th>
            </tr>
         </thead>
         <tbody>
         <?php foreach($other as $int) { ?>
            <tr class="text-muted">
               <td class="align-middle text-center" style="width: 10%;">
                  <img src="<?=$int['icon_url']?>" alt="<?=$int['name']?>" class="img-thumbnail" style="max-width: 50px;">
               </td>
               <td class="align-middle">
                  <strong><?=$int['name']?></strong>
                  <p class="text-muted mb-0"><?=$int['description']?></p>
               </td>
               <td class="align-middle text-center">
                  <a class="btn btn-success btn-sm activate-integration" href="/admin/appearance/integrations/<?= ($int['id'] == 13) ? 'enabledg' : 'enabled'; ?>/<?=$int['id']?>">Activate</a>
               </td>
            </tr>
         <?php } ?>
         </tbody>
      </table>
   </div>
</div>
<?php } ?>

</div>
