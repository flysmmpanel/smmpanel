<!---------   
=== Theme Author : Evan Ahmed EMon
=== Theme Designed By: TWG
=== Contact Whatsapp: +8801864614704
 ----------->   

<style>
    /* Additional styles */
    .delete-file {
        background-color: transparent;
        color: #f44336;
        border: none;
        font-size: 24px; /* Font size increased */
        cursor: pointer;
    }

    .delete-file:hover {
        color: #d32f2f;
    }
    
    .table td a {
    display: inline-block;
    max-width: 190px;  
    overflow: hidden;      
    word-break: break-all;
}
</style>

<div class="col-md-8">
    <div class="p-b">
        <div class="pull-left">
            <form action="/admin/appearance/files" method="POST" enctype="multipart/form-data">
                <input class="form-control" type="file" name="logo" accept="image/*"> 
        </div>
        <div class="pull-right">
            <button style="margin-bottom: 12px;" type="submit" class="btn btn-default">Upload File</button>
        </div>  
        </form>   
    </div>

    <div id="filesContainer">
<table class="table files__table">
    <thead>
        <tr>
            <th>Logo</th>
            <th>Link</th>
            <th>Size</th>
            <th class="text-right"></th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($fileList as $file) { ?>
            <tr>
                <td>
                    <div class="files__table-preview">
                        <?php 
                        // Display the image if it is an image file
                        if (preg_match('/\.(jpg|jpeg|png|gif|webp)$/i', $file['link'])) { 
                        ?>
    <img src="<?=$file['link']?>" onerror="this.style.display='none'">
                        <?php } else { ?>
                            <!-- Default icon for non-image files -->
                            <i class="fa fa-file" style="font-size:24px;"></i>
                        <?php } ?>
                    </div>
                </td>
                
                <td>
                    <a href="<?= site_url() . $file['link'] ?>" target="_blank">
                        <?php
                        $m2 = str_ireplace(site_url(), "", $file["link"]);
                        echo site_url() . $m2;
                        ?>
                    </a>
                </td>
                <td><?= $file['size']; ?> KB</td>
                <td class="p-r text-right">
                    <a class="delete-file" href="/admin/appearance/files/delete/<?= $file['id'] ?>">
                        <i class="fa fa-trash"></i>
                    </a>  
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>

        <nav>
        </nav>            
    </div>
</div>