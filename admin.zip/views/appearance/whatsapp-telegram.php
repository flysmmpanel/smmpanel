<!---------   
=== Theme Author : Evan Ahmed EMon
=== Theme Designed By: TWG
=== Contact Whatsapp: +8801864614704
 ----------->  

<div class="col-md-8">
  <div class="panel panel-default">
    <div class="panel-body">
      <form action="" method="post" enctype="multipart/form-data">

        <!-- Whatsapp Settings -->
        <h4><i class="fa fa-whatsapp"></i> Whatsapp Settings</h4>
        <p>Enable or configure the Whatsapp button on your website.</p>
        
        <div class="form-group">
          <label class="control-label"><i class="fa fa-toggle-on"></i> Whatsapp Button</label>
          <select class="form-control" name="whatsappbutton">
            <option value="0" <?= $settings["whatsappbutton"] == 0 ? "selected" : null; ?>>Passive</option>
            <option value="1" <?= $settings["whatsappbutton"] == 1 ? "selected" : null; ?>>Active</option>
          </select>
        </div>

        <div class="form-group">
          <label class="control-label"><i class="fa fa-phone"></i> Whatsapp No. (With Country Code)</label>
          <input type="text" class="form-control" name="whatsappnumber" value="<?=$settings["whatsappnumber"]?>">
        </div>

        <div class="form-group">
          <label class="control-label"><i class="fa fa-comment"></i> Whatsapp Auto Message</label>
          <input type="text" class="form-control" name="whatsappcolour" value="<?=$settings["whatsappcolour"]?>">
        </div>

        <div class="form-group">
          <label class="control-label"><i class="fa fa-map-marker"></i> Whatsapp Button Position</label>
          <select class="form-control" name="whatsappposition">
            <option value="left" <?= $settings["whatsappposition"] == "left" ? "selected" : null; ?>>Left</option>
            <option value="right" <?= $settings["whatsappposition"] == "right" ? "selected" : null; ?>>Right</option>
          </select>
        </div>

        <hr>

        <!-- Telegram Settings -->
        <h4><i class="fa fa-telegram"></i> Telegram Settings</h4>
        <p>Enable or configure the Telegram button on your website.</p>
        
        <div class="form-group">
          <label class="control-label"><i class="fa fa-toggle-on"></i> Telegram Button</label>
          <select class="form-control" name="telegrambutton">
            <option value="0" <?= $settings["telegrambutton"] == 0 ? "selected" : null; ?>>Passive</option>
            <option value="1" <?= $settings["telegrambutton"] == 1 ? "selected" : null; ?>>Active</option>
          </select>
        </div>

        <div class="form-group">
          <label class="control-label"><i class="fa fa-user"></i> Telegram Username (Without @)</label>
          <input type="text" class="form-control" name="telegramusername" value="<?=$settings["telegramusername"]?>">
        </div>

        <div class="form-group">
          <label class="control-label"><i class="fa fa-map-marker"></i> Telegram Button Position</label>
          <select class="form-control" name="telegramposition">
            <option value="left" <?= $settings["telegramposition"] == "left" ? "selected" : null; ?>>Left</option>
            <option value="right" <?= $settings["telegramposition"] == "right" ? "selected" : null; ?>>Right</option>
          </select>
        </div>

        <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Update Settings</button>
      </form>
    </div>
  </div>
</div>
