<?php
if (!defined('BASEPATH')) {
    die('Direct access to the script is not allowed');
}

if (isset($_SESSION['logout_success'])) {
    $logout_message = $_SESSION['logout_success'];
    unset($_SESSION['logout_success']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Admin Login</title>

<link href="https://cdn.rentalpanelbd.com/cd7f76/main.649f08559dd1a6f53f02.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<script src="https://www.google.com/recaptcha/api.js" async defer></script>

<style>
@import url('https://fonts.googleapis.com/css2?family=Share+Tech+Mono&family=Orbitron:wght@700&display=swap');

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
    background: #000;
    color: #00ff41;
    font-family: 'Share Tech Mono', monospace;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    position: relative;
}

/* ── Matrix Rain Canvas ── */
#matrix-canvas {
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    z-index: 0;
    opacity: 0.18;
}

/* ── Scanline overlay ── */
body::after {
    content: '';
    position: fixed;
    inset: 0;
    background: repeating-linear-gradient(
        0deg,
        transparent,
        transparent 2px,
        rgba(0,0,0,0.08) 2px,
        rgba(0,0,0,0.08) 4px
    );
    z-index: 1;
    pointer-events: none;
}

/* ── Login Card ── */
.hk-wrap {
    position: relative;
    z-index: 10;
    width: 380px;
}

.hk-card {
    background: rgba(0,0,0,0.88);
    border: 1px solid #00ff41;
    border-radius: 4px;
    padding: 36px 30px;
    box-shadow:
        0 0 12px rgba(0,255,65,0.3),
        0 0 40px rgba(0,255,65,0.1),
        inset 0 0 30px rgba(0,0,0,0.6);
    animation: bootUp 0.7s ease both;
}

@keyframes bootUp {
    from { opacity:0; transform:translateY(20px) scale(0.98); }
    to   { opacity:1; transform:translateY(0) scale(1); }
}

/* ── Header ── */
.hk-header {
    text-align: center;
    margin-bottom: 28px;
}

.hk-logo {
    font-family: 'Orbitron', sans-serif;
    font-size: 20px;
    color: #00ff41;
    letter-spacing: 4px;
    text-shadow: 0 0 10px #00ff41, 0 0 30px #00ff41;
    margin-bottom: 6px;
}

.hk-sub {
    font-size: 10px;
    color: #005515;
    letter-spacing: 3px;
    text-transform: uppercase;
}

.hk-divider {
    border: none;
    border-top: 1px solid #003310;
    margin: 18px 0;
    position: relative;
}
.hk-divider::before {
    content: '//';
    position: absolute;
    top: -9px; left: 50%;
    transform: translateX(-50%);
    background: #000;
    padding: 0 8px;
    font-size: 11px;
    color: #00ff41;
}

/* ── Alerts ── */
.alert {
    border-radius: 3px;
    padding: 10px 14px;
    font-size: 12px;
    margin-bottom: 16px;
    letter-spacing: 0.5px;
    border-left: 3px solid;
}
.alert-success {
    background: rgba(0,255,65,0.07);
    border-color: #00ff41;
    color: #00ff41;
}
.alert-danger {
    background: rgba(255,0,51,0.1);
    border-color: #ff0033;
    color: #ff4466;
    text-shadow: 0 0 6px rgba(255,0,51,0.5);
    animation: alertFlash 0.4s ease;
}
@keyframes alertFlash {
    0%,100%{opacity:1} 50%{opacity:0.4}
}

/* ── Form Labels ── */
.hk-label {
    display: block;
    font-size: 10px;
    letter-spacing: 2px;
    color: #00aa2a;
    margin-bottom: 6px;
    text-transform: uppercase;
}
.hk-label::before { content: '> '; color: #00ff41; }

/* ── Inputs ── */
.hk-group { margin-bottom: 16px; }

.hk-input-wrap { position: relative; }
.hk-input-wrap .hk-ico {
    position: absolute;
    left: 12px; top: 50%;
    transform: translateY(-50%);
    color: #005515;
    font-size: 13px;
    transition: color 0.3s;
}

.form-control {
    width: 100%;
    background: #050f05 !important;
    border: 1px solid #003310 !important;
    border-radius: 3px !important;
    color: #00ff41 !important;
    font-family: 'Share Tech Mono', monospace !important;
    font-size: 14px !important;
    padding: 11px 14px 11px 38px !important;
    outline: none !important;
    transition: border 0.3s, box-shadow 0.3s;
    caret-color: #00ff41;
}
.form-control::placeholder { color: #003a10 !important; }
.form-control:focus {
    border-color: #00ff41 !important;
    box-shadow: 0 0 0 2px rgba(0,255,65,0.15) !important;
}
.form-control:focus + .hk-ico,
.hk-input-wrap:focus-within .hk-ico {
    color: #00ff41;
}

/* Password toggle */
.hk-pass-wrap { display:flex; gap:0; }
.hk-pass-wrap .form-control { border-radius: 3px 0 0 3px !important; }
.hk-eye {
    background: #050f05;
    border: 1px solid #003310;
    border-left: none;
    border-radius: 0 3px 3px 0;
    padding: 0 14px;
    color: #005515;
    cursor: pointer;
    transition: color 0.2s, background 0.2s;
    font-size: 13px;
}
.hk-eye:hover { color: #00ff41; background: #0a1a0a; }

/* 2FA */
.form-control[type="number"] { letter-spacing: 4px; }

/* ── Submit Button ── */
.hk-btn {
    width: 100%;
    padding: 13px;
    margin-top: 8px;
    background: transparent;
    border: 1px solid #00ff41;
    border-radius: 3px;
    color: #00ff41;
    font-family: 'Orbitron', sans-serif;
    font-size: 13px;
    letter-spacing: 3px;
    text-transform: uppercase;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    transition: all 0.3s;
    box-shadow: 0 0 10px rgba(0,255,65,0.2);
}
.hk-btn::before {
    content: '';
    position: absolute;
    top: 0; left: -100%;
    width: 100%; height: 100%;
    background: linear-gradient(90deg, transparent, rgba(0,255,65,0.12), transparent);
    transition: left 0.5s;
}
.hk-btn:hover::before { left: 100%; }
.hk-btn:hover {
    background: rgba(0,255,65,0.08);
    box-shadow: 0 0 20px rgba(0,255,65,0.4), 0 0 40px rgba(0,255,65,0.1);
    letter-spacing: 4px;
}
.hk-btn:active { transform: scale(0.98); }

/* ── Footer status bar ── */
.hk-status {
    margin-top: 18px;
    font-size: 10px;
    color: #003310;
    letter-spacing: 1px;
    text-align: center;
}
.hk-status .dot {
    display: inline-block;
    width: 6px; height: 6px;
    border-radius: 50%;
    background: #00ff41;
    margin-right: 6px;
    animation: blink 1.2s infinite;
    vertical-align: middle;
}
@keyframes blink { 0%,100%{opacity:1} 50%{opacity:0.1} }

/* ── Cursor blink on logo ── */
.hk-cursor {
    display: inline-block;
    width: 10px; height: 18px;
    background: #00ff41;
    margin-left: 4px;
    vertical-align: middle;
    animation: blink 0.8s infinite;
}

/* recaptcha fix */
.g-recaptcha { filter: invert(0.85) hue-rotate(100deg); }
</style>
</head>

<body>

<!-- Matrix Canvas -->
<canvas id="matrix-canvas"></canvas>

<div class="hk-wrap">
  <div class="hk-card">

    <!-- Header -->
    <div class="hk-header">
      <div class="hk-logo">ADMIN<span class="hk-cursor"></span></div>
      <div class="hk-sub">Authorized Access Only</div>
    </div>
    <hr class="hk-divider">

    <!-- Form (ORIGINAL — untouched) -->
    <form action="admin" method="post">

      <?php if (isset($success)) : ?>
        <div class="alert alert-success">[OK] <?= htmlspecialchars($successText) ?></div>
      <?php elseif (isset($error)) : ?>
        <div class="alert alert-danger">[ERR] <?= htmlspecialchars($errorText) ?></div>
      <?php endif; ?>

      <?php if (isset($logout_message)): ?>
        <div class="alert alert-success">[OK] <?= htmlspecialchars($logout_message) ?></div>
      <?php endif; ?>

      <!-- Username -->
      <div class="hk-group">
        <label class="hk-label">Username</label>
        <div class="hk-input-wrap">
          <input class="form-control" type="text" name="username" placeholder="root@panel" required>
          <i class="fas fa-user hk-ico"></i>
        </div>
      </div>

      <!-- Password -->
      <div class="hk-group">
        <label class="hk-label">Password</label>
        <div class="hk-input-wrap hk-pass-wrap">
          <input id="password" class="form-control" type="password" name="password" placeholder="••••••••••" required>
          <button type="button" class="hk-eye" onclick="togglePass(this)">
            <i class="fas fa-eye"></i>
          </button>
        </div>
      </div>

      <!-- 2FA -->
      <div class="hk-group">
        <label class="hk-label">2FA Token</label>
        <div class="hk-input-wrap">
          <input class="form-control" type="number" name="two_factor_code" placeholder="000000">
          <i class="fas fa-shield-alt hk-ico"></i>
        </div>
      </div>

      <!-- Recaptcha (ORIGINAL) -->
      <?php if ($_SESSION["recaptcha"]) : ?>
        <div class="hk-group">
          <div class="g-recaptcha" data-sitekey="<?= htmlspecialchars($settings["recaptcha_key"]) ?>"></div>
        </div>
      <?php endif; ?>

      <!-- CSRF (ORIGINAL) -->
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">

      <button type="submit" class="hk-btn">⚡ Initialize Login</button>

    </form>

    <div class="hk-status">
      <span class="dot"></span> SECURE CHANNEL ESTABLISHED
    </div>

  </div>
</div>

<script>
/* ── Matrix Rain ── */
(function(){
    const c = document.getElementById('matrix-canvas');
    const ctx = c.getContext('2d');
    c.width  = window.innerWidth;
    c.height = window.innerHeight;
    window.addEventListener('resize',()=>{ c.width=window.innerWidth; c.height=window.innerHeight; });

    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%&<>/\\アイウエオカキクケコ';
    const fontSize = 14;
    const cols = Math.floor(c.width / fontSize);
    const drops = Array(cols).fill(1);

    function draw(){
        ctx.fillStyle = 'rgba(0,0,0,0.05)';
        ctx.fillRect(0,0,c.width,c.height);
        ctx.fillStyle = '#00ff41';
        ctx.font = fontSize + 'px Share Tech Mono, monospace';
        drops.forEach((y,i)=>{
            const ch = chars[Math.floor(Math.random()*chars.length)];
            ctx.fillStyle = Math.random()>0.95 ? '#fff' : '#00ff41';
            ctx.fillText(ch, i*fontSize, y*fontSize);
            if(y*fontSize > c.height && Math.random() > 0.975) drops[i] = 0;
            drops[i]++;
        });
    }
    setInterval(draw, 50);
})();

/* ── Password Toggle ── */
function togglePass(btn){
    const p = document.getElementById('password');
    if(p.type==='password'){
        p.type='text';
        btn.innerHTML='<i class="fas fa-eye-slash"></i>';
    } else {
        p.type='password';
        btn.innerHTML='<i class="fas fa-eye"></i>';
    }
}
</script>

</body>
</html>
