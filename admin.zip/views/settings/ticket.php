<!---------   
=== Theme Author : Evan Ahmed EMon
=== Theme Designed By: TWG
=== Contact Whatsapp: +8801864614704
 ----------->  

<div class="col-md-8">
    <form action="" method="post" enctype="multipart/form-data">
        <div class="panel panel-default">
            <div class="panel-body">
                <!-- Ticket Response Interval Time -->
              <!---  <div class="form-group">
                    <label for="" class="control-label">Ticket Response Interval Time (Minutes)
                        <div class="tooltip5">
                            <span class="fas fa-info-circle"></span>
                            <span class="tooltiptext5">Works when you select Auto Response (Interval)</span>
                        </div>
                    </label>
                    <input type="text" class="form-control" name="ticket_replytime" value="<?= isset($settings['ticket_replytime']) ? $settings['ticket_replytime'] : '180'; ?>">
                </div>

                <
                <div class="form-group">
                    <label for="" class="control-label">Ticket Form</label>
                    <select class="form-control" name="ticket_form">
                        <option value="1" <?= isset($settings["ticket_form"]) && $settings["ticket_form"] == 1 ? "selected" : null; ?>>V1</option>
                        <option value="2" <?= isset($settings["ticket_form"]) && $settings["ticket_form"] == 2 ? "selected" : null; ?>>V2</option>
                        <option value="3" <?= isset($settings["ticket_form"]) && $settings["ticket_form"] == 3 ? "selected" : null; ?>>V3</option>
                    </select>
                </div>

        
                <div class="form-group">
                    <label class="control-label" for="ticket_imgupload">
                        Ticket Image Upload
                        <div class="tooltip5">
                            <span class="fas fa-info-circle"></span>
                            <span class="tooltiptext5">Enable image upload for tickets</span>
                        </div>
                    </label>
                    <select class="form-control" name="ticket_imgupload" id="ticket_imgupload">
                        <option value="1" <?= isset($settings["ticket_imgupload"]) && $settings["ticket_imgupload"] == 1 ? "selected" : null; ?>>Yes</option>
                        <option value="2" <?= isset($settings["ticket_imgupload"]) && $settings["ticket_imgupload"] == 2 ? "selected" : null; ?>>No</option>
                    </select>
                </div>--->

                <!-- Ticket Create Restrictions -->
                <div class="form-group">
                    <label for="" class="control-label">Ticket Create Restrictions</label>
                    <select class="form-control" name="ticket_res">
                        <option value="1" <?= isset($settings["ticket_res"]) && $settings["ticket_res"] == 1 ? "selected" : null; ?>>Allow All</option>
                        <option value="2" <?= isset($settings["ticket_res"]) && $settings["ticket_res"] == 2 ? "selected" : null; ?>>Allow After Add Fund</option>
                    </select>
                </div>

                <!-- Ticket Autoclose -->
                <div class="form-group">
                    <label for="" class="control-label">Ticket Autoclose</label>
                    <select class="form-control" name="ticket_autoclose" id="ticket_autoclose">
                        <option value="1" <?= isset($settings["ticket_autoclose"]) && $settings["ticket_autoclose"] == 1 ? "selected" : null; ?>>On</option>
                        <option value="2" <?= isset($settings["ticket_autoclose"]) && $settings["ticket_autoclose"] == 2 ? "selected" : null; ?>>Off</option>
                    </select>
                </div>

                <!-- Autoclose Time (shown when On is selected) -->
                <div class="form-group" id="autoclose_time_div" style="display: <?= isset($settings["ticket_autoclose"]) && $settings["ticket_autoclose"] == 1 ? 'block' : 'none'; ?>;">
                    <label for="" class="control-label">Ticket Autoclose Time (Days)</label>
                    <input type="text" class="form-control" name="ticket_autoclose_time" value="<?= isset($settings['ticket_autoclose_time']) ? $settings['ticket_autoclose_time'] : ''; ?>">
                </div>

                <button type="submit" class="btn btn-primary">Update Settings</button>
            </div>
        </div>
    </form>

    <script type="text/javascript">
        // Toggle ticket image upload field visibility
        document.getElementById('ticket_imgupload').addEventListener('change', function() {
            const ticketImageDiv = document.getElementById('ticket_image_div');
            if (this.value == 1) {
                ticketImageDiv.style.display = 'block';
            } else {
                ticketImageDiv.style.display = 'none';
            }
        });

        // Show/hide fields on page load
        window.onload = function() {
            const ticketImageUpload = document.getElementById('ticket_imgupload').value;
            const ticketImageDiv = document.getElementById('ticket_image_div');
            if (ticketImageUpload == 1) {
                ticketImageDiv.style.display = 'block';
            } else {
                ticketImageDiv.style.display = 'none';
            }

            // Show/hide autoclose time field
            const autoclose = document.getElementById('ticket_autoclose').value;
            const autocloseTimeDiv = document.getElementById('autoclose_time_div');
            if (autoclose == 1) {
                autocloseTimeDiv.style.display = 'block';
            } else {
                autocloseTimeDiv.style.display = 'none';
            }
        };

        // Toggle autoclose time field visibility
        document.getElementById('ticket_autoclose').addEventListener('change', function() {
            const autocloseTimeDiv = document.getElementById('autoclose_time_div');
            if (this.value == 1) {
                autocloseTimeDiv.style.display = 'block';
            } else {
                autocloseTimeDiv.style.display = 'none';
            }
        });
    </script>
</div>