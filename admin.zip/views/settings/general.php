<!---------   
=== Theme Author : Evan Ahmed EMon
=== Theme Designed By: TWG
=== Contact Whatsapp: +8801864614704
 ----------->  
 
 <div class="col-md-8">
        <?php if( $success ): ?>
          <div class="alert alert-success "><?php echo $successText; ?></div>
        <?php endif; ?>
           <?php if( $error ): ?>
          <div class="alert alert-danger "><?php echo $errorText; ?></div>
        <?php endif; ?>
  <div class="panel panel-default">
    <div class="panel-body">
    
      <form action="" method="post" enctype="multipart/form-data">
 

<div class="alert">
        <div class="form-group">
        
          <div class="row">
            <div class="col-md-10">
              <label for="preferenceLogo" class="control-label">Site Logo</label>
              <input type="file" name="logo" id="preferenceLogo">
              <p class="help-block">200 x 80px recommended</p>
            </div>
            <div class="col-md-2">
              <?php if( $settings["site_logo"] ):  ?>
                <div class="setting-block__image">
                      <img class="img-thumbnail" src="<?=$settings["site_logo"]?>">
                    <div class="setting-block__image-remove">
                      <a href="" data-toggle="modal" data-target="#confirmChange" data-href="<?=site_url("admin/settings/general/delete-logo")?>"><span class="fa fa-remove"></span></a>
                    </div>
                </div>
              <?php endif; ?>
            </div>
          </div>
        </div>
        <div class="form-group">
          <div class="row">
            <div class="col-md-11">
              <label for="preferenceFavicon" class="control-label">Site Favicon</label>
              <input type="file" name="favicon" id="preferenceFavicon">
              <p class="help-block">16 x 16px .ico recommended</p> 
            </div>
            <div class="col-md-1">
              <?php if( $settings["favicon"] ):  ?>
                <div class="setting-block__image">
                    <img class="img-thumbnail" src="<?=$settings["favicon"]?>">
                    <div class="setting-block__image-remove">
                      <a href="" data-toggle="modal" data-target="#confirmChange" data-href="<?=site_url("admin/settings/general/delete-favicon")?>"><span class="fa fa-remove"></span></a>
                    </div>
                </div>
              <?php endif; ?>
            </div>
          </div>
        </div>
        <hr>
          
        <div class="form-group">
          <label class="control-label">Panel name</label>
          <input type="text" class="form-control" name="name" value="<?=$settings["site_name"]?>">
</div>

<div class="form-group">
          <label class="control-label">Panel Maintenance mode  
            </label>
          <select class="form-control" name="site_maintenance">
            <option value="2" <?= $settings["site_maintenance"] == 2 ? "selected" : null; ?> >Inactive</option>
            <option value="1" <?= $settings["site_maintenance"] == 1 ? "selected" : null; ?>>Active</option>
          </select></div>
        
        
    <!---    <div class="alert" style="background-color: gray;">
        <div class="form-group">
                      <label class="control-label">Admin 2fa <span class="fa fa-info-circle" data-toggle="tooltip" data-placement="top"></span></label>
            <select class="form-control" name="otp">
              <option value="2" <?= $settings["otp"] == 2 ? "selected" : null; ?> >Enable</option>
              <option value="1" <?= $settings["otp"] == 1 ? "selected" : null; ?>>Disable</option>
            </select>
        </div>
</div>---->
        
            
     
        
        
 <!-- Time Zone Selection -->
<div class="form-group">
    <label class="control-label">Panel Timezone</label>
     <select class="form-control" name="timezone">
                        <?php
                                foreach($timezones as $timezoneKey => $timezoneVal){
                                    if($settings["site_timezone"] == $timezoneVal["timezone"]){
                                        echo '<option selected value="'.$timezoneVal["timezone"].'">'.$timezoneVal["label"].'</option>';
                                    }else{
                                        echo '<option value="'.$timezoneVal["timezone"].'">'.$timezoneVal["label"].'</option>';
                                    }
                                }
                        
                        ?>
              </select>
</div> 


 
 <!-- Panel Recaptcha -->
<div class="form-group">
    <label for="" class="control-label">Panel Recaptcha
        <div class="tooltip5">
            <span class="fas fa-info-circle"></span>
            <span class="tooltiptext5">Enable or Disable recaptcha feature for the panel.</span>
        </div>
    </label>
    <select class="form-control" name="recaptcha" id="recaptcha-select">
        <option value="1" <?= $settings["recaptcha"] == 1 ? "selected" : null; ?>>Off</option>
        <option value="2" <?= $settings["recaptcha"] == 2 ? "selected" : null; ?>>On</option>
    </select>
</div>
<script>
document.getElementById('recaptcha-select').addEventListener('change', function() {
    var recaptchaKeys = document.getElementById('recaptcha-keys');
    if (this.value == '2') {
        recaptchaKeys.style.display = 'block';
    } else {
        recaptchaKeys.style.display = 'none';
    }
});
</script>
<div id="recaptcha-keys" style="display: <?= $settings["recaptcha"] == 2 ? 'block' : 'none'; ?>;">
    <div class="form-group">
        <label for="recaptcha_key" class="control-label">Recaptcha Key
            <div class="tooltip5">
                <span class="fas fa-info-circle"></span>
                <span class="tooltiptext5">Enter the Recaptcha Key you obtained from Google.</span>
            </div>
        </label>
        <input type="text" class="form-control" name="recaptcha_key" value="<?= $settings["recaptcha_key"] ?? ''; ?>">
    </div>
    <div class="form-group">
        <label for="recaptcha_secret" class="control-label">Recaptcha Secret
            <div class="tooltip5">
                <span class="fas fa-info-circle"></span>
                <span class="tooltiptext5">Enter the Recaptcha Secret you obtained from Google.</span>
            </div>
        </label>
        <input type="text" class="form-control" name="recaptcha_secret" value="<?= $settings["recaptcha_secret"] ?? ''; ?>">
    </div>
</div>
<hr>
<!-- New Order Search Functionality -->
<div class="form-group">
    <label class="control-label">New Order Search Functionality
        <div class="tooltip5">
            <span class="fas fa-info-circle"></span>
            <span class="tooltiptext5">Enable or Disable search functionality for new orders.</span>
        </div>
    </label>
    <select class="form-control" name="search_enabled" id="search-enabled-select">
        <option value="0" <?= $settings["search_enabled"] == 0 ? "selected" : null; ?>>Disabled</option>
        <option value="1" <?= $settings["search_enabled"] == 1 ? "selected" : null; ?>>Enabled</option>
    </select>
</div>

<!-- New Order Page Service Format -->
<?php 
$stmt = $conn->prepare("SELECT neworder_display FROM settings");
$stmt->execute();
$newOrderDisplay = $stmt->fetchColumn(); 
?>
<div class="form-group">
    <label class="control-label">New Order Page Service Format
        <div class="tooltip5">
            <span class="fas fa-info-circle"></span>
            <span class="tooltiptext5">Choose the format for displaying services on the New Order page.</span>
        </div>
    </label>
    <select class="form-control" name="neworder_display">
        <option value="1" <?php echo ($newOrderDisplay == 1) ? 'selected' : ''; ?>>Service ID - Service Name - Price</option>
        <option value="2" <?php echo ($newOrderDisplay == 2) ? 'selected' : ''; ?>>Service ID - Service Name - Price - Price Per 1000</option>
        <option value="3" <?php echo ($newOrderDisplay == 3) ? 'selected' : ''; ?>>Service Name - Price - Price Per 1000</option>
        <option value="4" <?php echo ($newOrderDisplay == 4) ? 'selected' : ''; ?>>Service Name - Price</option>
    </select>
</div>

<!-- New Order Checkbox -->
<div class="form-group">
    <label class="control-label">New order Checkbox
        <div class="tooltip5">
            <span class="fas fa-info-circle"></span>
            <span class="tooltiptext5">Enable or Disable the checkbox for new orders.</span>
        </div>
    </label>
    <select class="form-control" name="neworder_terms">
        <option value="2" <?= $settings["neworder_terms"] == 2 ? "selected" : null; ?>>Enable</option>
        <option value="1" <?= $settings["neworder_terms"] == 1 ? "selected" : null; ?>>Disable</option>
    </select>
</div>

<!-- Services Sort By -->
<?php 
$stmt = $conn->prepare("SELECT sort_by FROM settings");
$stmt->execute();
$sortBy = $stmt->fetchColumn();  
?>
<div class="form-group">
    <label for="" class="control-label">Services Sort By
        <div class="tooltip5">
            <span class="fas fa-info-circle"></span>
            <span class="tooltiptext5">Select the order for sorting services.</span>
        </div>
    </label>
    <select class="form-control" name="sort_by">
        <option value="1" <?php if ($sortBy == 1) echo 'selected'; ?>>Service Line</option>
        <option value="2" <?php if ($sortBy == 2) echo 'selected'; ?>>Low Price to High Price</option>
        <option value="3" <?php if ($sortBy == 3) echo 'selected'; ?>>High Price to Low Price</option>
    </select>
</div> 

<!-- Auto Refill -->
<div class="form-group">
    <label class="control-label">Auto Refill
        <div class="tooltip5">
            <span class="fas fa-info-circle"></span>
            <span class="tooltiptext5">Enable or Disable Auto Refill feature for services.</span>
        </div>
    </label>
    <select class="form-control" name="auto_refill">
        <option value="2" <?php if($settings["auto_refill"] == 2){ echo "selected"; } ?>>Enable</option>
        <option value="1" <?php if($settings["auto_refill"] == 1){ echo "selected"; } ?>>Disable</option>
    </select> 
</div>

<!-- Service Down on Provider -->
<div class="form-group">
    <label class="control-label">If Service Down on Provider
        <div class="tooltip5">
            <span class="fas fa-info-circle"></span>
            <span class="tooltiptext5">Choose the action to take if a service goes down on the provider.</span>
        </div>
    </label>
    <select class="form-control" name="ser_sync">
        <option value="2" <?= $settings["ser_sync"] == 2 ? "selected" : null; ?> >Just Alert</option>
        <option value="1" <?= $settings["ser_sync"] == 1 ? "selected" : null; ?>>Warning & Disable Service</option>
    </select>
</div>

<!-- Service List -->
<div class="form-group">
    <?php 
    if($settings["service_list"] == "2"){
        $servlist_active = "selected";
    } else {
        $servlist_passive = "selected";
    } ?>
    <label class="control-label">Service List
        <div class="tooltip5">
            <span class="fas fa-info-circle"></span>
            <span class="tooltiptext5">Choose whether the service list is active for everyone or only users.</span>
        </div>
    </label>
    <select class="form-control" name="service_list">
        <option value="2" <?= $servlist_active ?> >Active for everyone</option>
        <option value="1" <?= $servlist_passive ?>>Active for only users</option>
    </select>
</div>

<!-- Average Time -->
<div class="form-group">
    <?php 
    if($settings["services_average_time"] == "1"){
        $avg_time_active = "selected";
    } else {
        $avg_time_passive = "selected";
    } ?>
    <label class="control-label">Average time
        <div class="tooltip5">
            <span class="fas fa-info-circle"></span>
            <span class="tooltiptext5">Enable or Disable average time display for services.</span>
        </div>
    </label>
    <select class="form-control" name="services_average_time">
        <option value="1" <?= $avg_time_active ?> >Enabled</option>
        <option value="0" <?= $avg_time_passive ?>>Disabled</option>
    </select>
</div>
 
</div>
	
<div class="alert">
        <div class="row">	
          <div class="form-group col-md-4">
            <?php 
            if($settings["resetpass_page"] == "2"){
                $respass_active = "selected";
            }else{
                $respass_passive = "selected";
            } ?>  
            <label class="control-label">Reset Password</label>
            <select class="form-control" name="resetpass">
              <option value="2" <?= $respass_active ?> >Enabled</option>
              <option value="1" <?= $respass_passive ?>>Disabled</option>
            </select>
          </div>

         
          <div class="form-group col-md-4">
            <?php 
            if($settings["resetpass_email"] == "2"){
                $resemail_active = "selected";
            }else{
                $resemail_passive = "selected";
            } ?>
            <label class="control-label">Reset Using Email</label>
            <select class="form-control" name="resetmail">
              <option value="2" <?= $resemail_active ?> >Enabled</option>
              <option value="1" <?= $resemail_passive ?>>Disabled</option>
            </select>
          </div>
        </div></div>
        <hr>
<div class="alert">
        <div class="form-group">
            <?php 
            if($settings["ticket_system"] == "1"){
                $ticket_active = "selected";
            }else{
                $ticket_passive = "selected";
            } ?>
          <label class="control-label">Ticket system</label>
          <select class="form-control" name="ticket_system">
            <option value="1" <?= $ticket_active ?> >Enabled</option>
            <option value="2" <?= $ticket_passive ?>>Disabled</option>
          </select>
        </div>
<div class="form-group">
          <label class="control-label">Max Pending Tickets per user</label>
          <select class="form-control" name="tickets_per_user">
            <option value="1" <?= $settings["tickets_per_user"] == 1 ? "selected" : null; ?> >1</option>
            <option value="2" <?= $settings["tickets_per_user"] == 2 ? "selected" : null; ?>>2</option>
<option value="3" <?= $settings["tickets_per_user"] == 3 ? "selected" : null; ?>>3</option>
<option value="4" <?= $settings["tickets_per_user"] == 4 ? "selected" : null; ?> >4</option>
            <option value="5" <?= $settings["tickets_per_user"] == 5 ? "selected" : null; ?>>5</option>
<option value="6" <?= $settings["tickets_per_user"] == 6 ? "selected" : null; ?>>6</option>
<option value="7" <?= $settings["tickets_per_user"] == 7 ? "selected" : null; ?> >7</option>
            <option value="8" <?= $settings["tickets_per_user"] == 8 ? "selected" : null; ?>>8</option>
<option value="9" <?= $settings["tickets_per_user"] == 9 ? "selected" : null; ?>>9</option>
<option value="10" <?= $settings["tickets_per_user"] == 10 ? "selected" : null; ?> >10</option>
            <option value="9999999999" <?= $settings["tickets_per_user"] == 9999999999 ? "selected" : null; ?>>Unlimited</option>

          </select>
        </div>

<hr>
</div>
                  
<div class="alert">
        <div class="form-group">
          <label class="control-label">Header Code Field (Visible on All Pages) </label>
          <textarea class="form-control" rows="7" name="custom_header" placeholder='<style type="text/css">...</style>'><?=$settings["custom_header"]?></textarea>
        </div>
        <div class="form-group">
          <label>Footer Code Field (Visible on All Pages) </label>
          <textarea class="form-control" rows="7" name="custom_footer" placeholder='<script>...</script>'><?=$settings["custom_footer"]?></textarea>
        </div></div>
		<hr>
    <h3>Upload a Document</h3> 
        <label for="document">Choose a document (txt, xml, text):</label><br>
        <input type="file" name="document" id="document" accept=".txt, .xml, .text"><br><br>
</body>
</html>
                    
        <button type="submit" class="btn btn-primary">Update Settings</button>
      </form>
    </div>
  </div>
</div>
<div class="modal modal-center fade" id="confirmChange" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static">
 <div class="modal-dialog modal-dialog-center" role="document">
   <div class="modal-content">
     <div class="modal-body text-center">
       <h4>Are you sure?</h4>
       <div align="center">
         <a class="btn btn-primary" href="" id="confirmYes">Yes</a>
         <button type="button" class="btn btn-default" data-dismiss="modal">NO</button>
       </div>
     </div>
   </div>
 </div>
