<!---------   
=== Theme Author : Evan Ahmed EMon
=== Theme Designed By: TWG
=== Contact Whatsapp: +8801864614704
 ----------->  

<style>
  /* General Styles */
  body {
    font-family: 'Arial', sans-serif;
    background-color: #f9f9f9;
    color: #333;
  }

  .col-md-8 {
    margin: 40px auto;
  }

  .panel-body {
    padding: 30px;
    background-color: #ffffff;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  }

  hr {
  border: 0;
  height: 2px;
  background: #4caf50; /* Change to your desired color */
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
  margin: 20px 0;
}

  label {
    font-weight: bold;
    color: #337ab7; /* Green Color for Labels */
  }

  .tooltip5 {
    position: relative;
    display: inline-block;
  }

  .tooltip5 .fas {
    color: #007bff;
    cursor: pointer;
  }

  .tooltiptext5 {
    visibility: hidden;
    width: 200px;
    background-color: #333;
    color: #fff;
    text-align: center;
    border-radius: 8px;
    padding: 10px;
    position: absolute;
    z-index: 1;
    bottom: 130%;
    left: 50%;
    margin-left: -100px;
    opacity: 0;
    transition: opacity 0.3s;
  }

  .tooltip5:hover .tooltiptext5 {
    visibility: visible;
    opacity: 1;
  }

  select,
  input[type="text"] {
    width: 100%;
    padding: 10px;
    margin-bottom: 20px;
    border: 1px solid #ddd;
    border-radius: 5px;
    box-sizing: border-box;
    background-color: #fafafa;
    font-size: 14px;
  }

  select:focus,
  input[type="text"]:focus {
    border-color: #4caf50;
    outline: none;
  }

  .btn-primary {
    background-color: #4caf50;
    border: none;
    color: white;
    padding: 10px 20px;
    font-size: 16px;
    border-radius: 5px;
    cursor: pointer;
  }

  .btn-primary:hover {
    background-color: #45a049;
  }

  .alert {
    background-color: #e8f5e9;
    padding: 10px;
    border: 1px solid #c8e6c9;
    border-radius: 5px;
    color: #388e3c;
    font-size: 14px;
  }
</style>

<div class="col-md-8">
            <?php if( $success ): ?>
          <div class="alert alert-success "><?php echo $successText; ?></div>
        <?php endif; ?>
           <?php if( $error ): ?>
          <div class="alert alert-danger "><?php echo $errorText; ?></div>
        <?php endif; ?>
  <div class="panel panel-default">
    <div class="panel-body">
      <form action="" method="post" enctype="multipart/form-data">
        <label class="control-label">Users Notifications</label>
        <hr>
        <div class="alert">
          <div class="row">
            <div class="col-md-6 form-group">
              <label class="control-label">Welcome 
                <div class="tooltip5">
                  <span class="fas fa-info-circle"></span>
                  <span class="tooltiptext5">Sent to new users when their account is created.</span>
                </div>
              </label>
              <select class="form-control" name="welcomemail">
                <option value="2" <?= $settings["alert_welcomemail"] == 2 ? "selected" : null; ?>>Enabled</option>
                <option value="1" <?= $settings["alert_welcomemail"] == 1 ? "selected" : null; ?>>Disabled</option>
              </select>
            </div>

            <div class="col-md-6 form-group">
              <label class="control-label">API key changed
                <div class="tooltip5">
                  <span class="fas fa-info-circle"></span>
                  <span class="tooltiptext5">Sent to users when their API key is changed</span>
                </div>
              </label>
              <select class="form-control" name="apimail">
                <option value="2" <?= $settings["alert_apimail"] == 2 ? "selected" : null; ?>>Enabled</option>
                <option value="1" <?= $settings["alert_apimail"] == 1 ? "selected" : null; ?>>Disabled</option>
              </select>
            </div>

            <div class="col-md-6 form-group">
              <label class="control-label">New message
                <div class="tooltip5">
                  <span class="fas fa-info-circle"></span>
                  <span class="tooltiptext5">Sent to users when they receive a new message.</span>
                </div>
              </label>
              <select class="form-control" name="newmessage">
                <option value="2" <?= $settings["alert_newmessage"] == 2 ? "selected" : null; ?>>Enabled</option>
                <option value="1" <?= $settings["alert_newmessage"] == 1 ? "selected" : null; ?>>Disabled</option>
              </select>
            </div>
          </div>
        </div>

   
        <label class="control-label">Admin Notifications</label>
        <hr>
        <div class="row">
          <div class="col-md-6 form-group">
            <label class="control-label">Admin Login Alert</label>
            <div class="tooltip5">
              <span class="fas fa-info-circle"></span>
              <span class="tooltiptext5">Notification for admin login attempts.</span>
            </div>
            <select class="form-control" name="alert_adminlogin">
              <option value="2" <?= $settings["alert_adminlogin"] == 2 ? "selected" : null; ?>>Enabled</option>
              <option value="1" <?= $settings["alert_adminlogin"] == 1 ? "selected" : null; ?>>Disabled</option>
            </select>
          </div>
<!----
<div class="col-md-6 form-group">
            <label class="control-label">New Payment notification</label>
            <select class="form-control" name="alert_newpay">
              <option value="2" <?= $settings["alert_newpay"] == 2 ? "selected" : null; ?> >Enabled</option>
              <option value="1" <?= $settings["alert_newpay"] == 1 ? "selected" : null; ?>>Disabled</option>
            </select>
          </div>
---->

          <div class="col-md-6 form-group">
            <label class="control-label">API balance notification</label>
            <select class="form-control" name="alert_apibalance">
              <option value="2" <?= $settings["alert_apibalance"] == 2 ? "selected" : null; ?>>Enabled</option>
              <option value="1" <?= $settings["alert_apibalance"] == 1 ? "selected" : null; ?>>Disabled</option>
            </select>
          </div>

          <div class="col-md-6 form-group">
            <label class="control-label">New support ticket notification</label>
            <select class="form-control" name="alert_newticket">
              <option value="2" <?= $settings["alert_newticket"] == 2 ? "selected" : null; ?>>Enabled</option>
              <option value="1" <?= $settings["alert_newticket"] == 1 ? "selected" : null; ?>>Disabled</option>
            </select>
          </div>

          <div class="col-md-6 form-group">
            <label class="control-label">New manual orders
              <div class="tooltip5">
                <span class="fas fa-info-circle"></span>
                <span class="tooltiptext5">Periodically sent to staff if new manual orders are received.</span>
              </div>
            </label>
            <select class="form-control" name="alert_newmanuelservice">
              <option value="2" <?= $settings["alert_newmanuelservice"] == 2 ? "selected" : null; ?>>Enabled</option>
              <option value="1" <?= $settings["alert_newmanuelservice"] == 1 ? "selected" : null; ?>>Disabled</option>
            </select>
          </div>

          <div class="col-md-6 form-group">
            <label class="control-label">Failed orders
              <div class="tooltip5">
                <span class="fas fa-info-circle"></span>
                <span class="tooltiptext5">Sent to staff if some orders fail.</span>
              </div>
            </label>
            <select class="form-control" name="orderfail">
              <option value="2" <?= $settings["alert_orderfail"] == 2 ? "selected" : null; ?>>Enabled</option>
              <option value="1" <?= $settings["alert_orderfail"] == 1 ? "selected" : null; ?>>Disabled</option>
            </select>
          </div>

          <div class="col-md-12 form-group">
            <label class="control-label">Service provider changed information</label>
            <select class="form-control" name="serviceapialert">
              <option value="2" <?= $settings["alert_serviceapialert"] == 2 ? "selected" : null; ?>>Enabled</option>
              <option value="1" <?= $settings["alert_serviceapialert"] == 1 ? "selected" : null; ?>>Disabled</option>
            </select>
          </div>
<hr>
          <div class="settings-emails__block">
            <div class="settings-emails__block-title">Authorized Information</div>
        <div class="settings-emails__block-body">
            <table>
                <thead>
                <tr>
                    <th class="settings-emails__th-email-name"></th>
                    <th class="settings-emails__th-email-count"></th>
                    <th class="settings-emails__th-actions"></th>
                </tr>
                </thead>
                <tbody>
                                    <tr class="settings-emails__row">
                        <td>
                            <div class="settings-emails__row-name"><?=$settings["admin_mail"]?></div>
                        </td>
                        <td>
                            <div class="settings-emails__row-emails-count">
<?php

$count = 0;
if($settings["alert_apibalance"] == 2 ){
    $count = $count+1;
}
if($settings["alert_orderfail"] == 2 ){
    $count = $count+1;
}
if($settings["alert_newmanuelservice"] == 2 ){
    $count = $count+1;
}
if($settings["alert_serviceapialert"] == 2 ){
    $count = $count+1;
}
if($settings["alert_adminlogin"] == 2 ){
    $count = $count+1;
}
if($settings["alert_newticket"] == 2 ){
    $count = $count+1;
}
if($settings["alert_newmessage"] == 2 ){
    $count = $count+1;
}
if($settings["alert_apimail"] == 2 ){
    $count = $count+1;
} 
if($settings["alert_welcomemail"] == 2 ){
    $count = $count+1;
} 

                            echo "$count Active notification"; ?>
                            </div>
                        </td>
                        <td class="settings-emails__td-actions">
                       <a href="javascript:;" onclick="showMe('gizlebeni');" class="btn btn-xs btn-default">
                       Edit                    </a>
                        </td>
                    </tr>
                   
                                </tbody>
            </table>
        </div>

</div>  

<div id="gizlebeni" class="row" style="display: none;">
            
             <div class="form-group col-md-6">
           <label class="control-label">Email Address to Receive Notification</label>
            <input type="text" class="form-control" name="admin_mail" value="<?=$settings["admin_mail"]?>">
            </div>
            <!---
            <div class="form-group col-md-6">
            <label class="control-label">Notification Phone Number</label>
            <input type="text" class="form-control" name="admin_telephone" value="<?=$settings["admin_telephone"]?>">
            </div>--->
			
             </div>

<!---
        <div class="row">
          <div class="col-md-12 form-group">
            <label class="control-label">Notification Form</label>
            <select class="form-control" name="alert_type">
              <option value="3" <?= $settings["alert_type"] == 3 ? "selected" : null; ?> >Email and SMS</option>
              <option value="2" <?= $settings["alert_type"] == 2 ? "selected" : null; ?>>Email</option>
              <option value="1" <?= $settings["alert_type"] == 1 ? "selected" : null; ?>>SMS</option>
            </select>
          </div>   
        <div class="form-group col-md-6">
            <label class="control-label">Password Renewal via SMS</label>
            <select class="form-control" name="resetsms">
              <option value="2" <?= $settings["resetpass_sms"] == 2 ? "selected" : null; ?> >Active</option>
              <option value="1" <?= $settings["resetpass_sms"] == 1 ? "selected" : null; ?>>Passive</option>
            </select>
          </div>
          <div class="form-group col-md-6">
            <label class="control-label">Password Renewal by Email</label>
            <select class="form-control" name="resetmail">
              <option value="2" <?= $settings["resetpass_email"] == 2 ? "selected" : null; ?> >Active</option>
              <option value="1" <?= $settings["resetpass_email"] == 1 ? "selected" : null; ?>>Passive</option>
            </select>
          </div>   

          <div class="col-md-12 help-block">
         <small>The most reliable form of notification is SMS.</small>
        </div>
        </div>
        <hr>
        <div class="row">
          <div class="col-md-3 form-group">
            <label class="control-label">SMS Provider</label>
            <select class="form-control" name="sms_provider">
              <option value="bizimsms" <?= $settings["sms_provider"] == "bizimsms" ? "selected" : null; ?> >Bizimsms</option>
              <option value="netgsm" <?= $settings["sms_provider"] == "netgsm" ? "selected" : null; ?> >NetGSM</option>
            </select>
          </div>
          <div class="form-group col-md-3">
            <label class="control-label">SMS Header</label>
            <input type="text" class="form-control" name="sms_title" value="<?=$settings["sms_title"]?>">
          </div>
          <div class="form-group col-md-3">
            <label class="control-label">Username</label>
            <input type="text" class="form-control" name="sms_user" value="<?=$settings["sms_user"]?>">
          </div>
          <div class="form-group col-md-3">
            <label class="control-label">password</label>
            <input type="text" class="form-control" name="sms_pass" value="<?=$settings["sms_pass"]?>"> 
          </div>
          <div class="col-md-12 help-block">
         <small><i class="fa fa-warning"></i> <code>Bizim SMS</code> Type your API Key in the password section for.</small><br>
         <small>Pay attention to Turkish characters when writing the SMS Title..</small>
         </div>
        </div>--->
        <hr>
        <div class="row">
          <div class="form-group col-md-6">
            <label class="control-label">Email</label>
            <input type="text" class="form-control" name="smtp_user" value="<?=$settings["smtp_user"]?>">
          </div>
          <div class="form-group col-md-6">
            <label class="control-label">E mail password</label>
            <input type="text" class="form-control" name="smtp_pass" value="<?=$settings["smtp_pass"]?>">
          </div>
          <div class="form-group col-md-6">
            <label class="control-label">SMTP Server</label>
            <input type="text" class="form-control" name="smtp_server" value="<?=$settings["smtp_server"]?>">
          </div>
          <div class="form-group col-md-3">
            <label class="control-label">SMTP Port</label>
            <input type="text" class="form-control" name="smtp_port" value="<?=$settings["smtp_port"]?>">
          </div>
          <div class="col-md-3 form-group">
            <label class="control-label">SMTP Protocol</label>
            <select class="form-control" name="smtp_protocol">
              <option value="0" <?= $settings["smtp_protocol"] == 0 ? "selected" : null; ?> >no</option>
              <option value="tls" <?= $settings["smtp_protocol"] == "tls" ? "selected" : null; ?>>TLS</option>
              <option value="ssl" <?= $settings["smtp_protocol"] == "ssl" ? "selected" : null; ?>>SSL</option>
            </select>
          </div> 
        </div>
   
        <hr>
        <button type="submit" class="btn btn-primary">Update</button>
      </form>

<script type="text/javascript">
// göster/gizle
function showMe(blockId) {
     if ( document.getElementById(blockId).style.display == 'none' ) {
          document.getElementById(blockId).style.display = ''; }
else if ( document.getElementById(blockId).style.display == '' ) {
          document.getElementById(blockId).style.display = 'none'; }
}
</script>