<!---------   
=== Theme Author : Evan Ahmed EMon
=== Theme Designed By: TWG
=== Contact Whatsapp: +8801864614704
 ----------->  

<div class="col-md-8">
  <div class="panel panel-default">
    <div class="panel-body">
      <form action="" method="post" enctype="multipart/form-data">
        <h4>Signup Form Settings</h4>

        <!-- Signup Page Toggle -->
        <div class="form-group">
          <?php 
            if($settings["register_page"] == "2"){
              $reg_active = "selected";
            } else {
              $reg_passive = "selected";
            }
          ?>
          <div class="form-group field-editgeneralform-skype_field required">
            <label class="control-label" for="editgeneralform-registration_page">
              Signup page
              <div class="tooltip5">
                <span class="fas fa-info-circle"></span>
                <span class="tooltiptext5">Allows Users to register</span>
              </div>
            </label>
            <select class="form-control" name="registration_page">
              <option value="2" <?= $reg_active ?>>Enabled</option>
              <option value="1" <?= $reg_passive ?>>Disabled</option>
            </select>
          </div>
        </div>

        <!-- Full Name Field -->
        <div class="form-group field-editgeneralform-skype_field required">
          <label class="control-label" for="editgeneralform-skype_field">
            Full Name
            <div class="tooltip5">
              <span class="fas fa-info-circle"></span>
              <span class="tooltiptext5">Name field on the Signup page</span>
            </div>
          </label>
          <select class="form-control" name="name_fileds">
            <option value="1" <?= $settings["name_fileds"] == 1 ? "selected" : null; ?>>Enabled</option>
            <option value="2" <?= $settings["name_fileds"] == 2 ? "selected" : null; ?>>Disabled</option>
          </select>
        </div>

        <!-- Phone Number (Skype) Field -->
        <div class="form-group field-editgeneralform-skype_field required">
          <label class="control-label" for="editgeneralform-skype_field">
            Phone no
            <div class="tooltip5">
              <span class="fas fa-info-circle"></span>
              <span class="tooltiptext5">Skype field on the Signup page</span>
            </div>
          </label>
          <select class="form-control" name="skype_area">
            <option value="2" <?= $settings["skype_area"] == 2 ? "selected" : null; ?>>Enable</option>
            <option value="1" <?= $settings["skype_area"] == 1 ? "selected" : null; ?>>Disable</option>
          </select>
        </div>

        <!-- WhatsApp Number Field -->
        <div class="form-group field-editgeneralform-whatsapp_field required">
          <label class="control-label" for="editgeneralform-whatsapp_field">
            WhatsApp No
            <div class="tooltip5">
              <span class="fas fa-info-circle"></span>
              <span class="tooltiptext5">WhatsApp field on the Signup page</span>
            </div>
          </label>
          <select class="form-control" name="whatsapp_field">
            <option value="1" <?= $settings["whatsapp_field"] == 1 ? "selected" : null; ?>>Enabled</option>
            <option value="2" <?= $settings["whatsapp_field"] == 2 ? "selected" : null; ?>>Disabled</option>
          </select>
        </div>

        <!-- Telegram ID Field -->
        <div class="form-group field-editgeneralform-telegram_field required">
          <label class="control-label" for="editgeneralform-telegram_field">
            Telegram ID
            <div class="tooltip5">
              <span class="fas fa-info-circle"></span>
              <span class="tooltiptext5">Telegram field on the Signup page</span>
            </div>
          </label>
          <select class="form-control" name="telegram_field">
            <option value="1" <?= $settings["telegram_field"] == 1 ? "selected" : null; ?>>Enabled</option>
            <option value="2" <?= $settings["telegram_field"] == 2 ? "selected" : null; ?>>Disabled</option>
          </select>
        </div>

        <!-- Website URL Field -->
        <div class="form-group field-editgeneralform-website_field required">
          <label class="control-label" for="editgeneralform-website_field">
            Website URL
            <div class="tooltip5">
              <span class="fas fa-info-circle"></span>
              <span class="tooltiptext5">Website field on the Signup page</span>
            </div>
          </label>
          <select class="form-control" name="website_field">
            <option value="1" <?= $settings["website_field"] == 1 ? "selected" : null; ?>>Enabled</option>
            <option value="2" <?= $settings["website_field"] == 2 ? "selected" : null; ?>>Disabled</option>
          </select>
        </div>


        <!-- Terms Checkbox Field -->
<div class="form-group field-editgeneralform-terms_checkbox required">
  <label class="control-label" for="editgeneralform-terms_checkbox">
    Terms Checkbox at Registration
    <div class="tooltip5">
      <span class="fas fa-info-circle"></span>
      <span class="tooltiptext5">Terms checkbox on the Signup page</span>
    </div>
  </label>
  <select class="form-control" name="terms_checkbox">
    <option value="2" <?= $settings["terms_checkbox"] == 2 ? "selected" : null; ?>>Enabled</option>
    <option value="1" <?= $settings["terms_checkbox"] == 1 ? "selected" : null; ?>>Disabled</option>
  </select>
</div>


        <!-- Email Confirmation -->
        <div class="form-group field-editgeneralform-skype_field required">
          <label class="control-label" for="editgeneralform-skype_field">
            Email Confirmation
            <div class="tooltip5">
              <span class="fas fa-info-circle"></span>
              <span class="tooltiptext5">(Enables mandatory email confirmation for the user after signing up)</span>
            </div>
          </label>
          <select class="form-control" name="email_confirmation">
            <option value="1" <?= $settings["email_confirmation"] == 1 ? "selected" : null; ?>>Enabled</option>
            <option value="2" <?= $settings["email_confirmation"] == 2 ? "selected" : null; ?>>Disabled</option>
          </select>
        </div>

          <!-- Account Status -->
          <div class="alert">
            <h4>Rank Status</h4>
<p class="alert help-block custom-alert">
  <small><i class="fas fa-info-circle"></i> Just enter the number to determine the amount that the member should spend on the rank. Example: 350</small>
</p>

<!-- CSS styles -->
<style>
  .custom-alert {
    background-color: rgba(255, 255, 255, 0.2);
    border-left: 4px solid #5bc0de;
    color: #333;
    padding: 15px;
    font-size: 14px;
    border-radius: 5px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
  }

  .custom-alert i {
    margin-right: 10px;
    color: #5bc0de;
  }

  .custom-alert small {
    font-style: italic;
    color: #555;
  }

  .custom-alert:hover {
    background-color: rgba(255, 255, 255, 0.3);
    transition: background-color 0.3s ease;
  }
</style>
<div class="form-group">
  <label for="" class="control-label">Bronze Member</label>
  <input type="text" class="form-control" name="bronz_statu" value="<?=$settings['bronz_statu']?>">
</div>

<div class="form-group">
  <label for="" class="control-label">Silver Member</label>
  <input type="text" class="form-control" name="silver_statu" value="<?=$settings['silver_statu']?>">
</div>

<div class="form-group">
  <label for="" class="control-label">Gold Member</label>
  <input type="text" class="form-control" name="gold_statu" value="<?=$settings['gold_statu']?>">
</div>

<div class="form-group">
  <label for="" class="control-label">Reseller</label>
  <input type="text" class="form-control" name="bayi_statu" value="<?=$settings['bayi_statu']?>">
</div>


        <!-- Submit Button -->
        <button type="submit" class="btn btn-primary">Update Settings</button>
      </form>
    </div>
  </div>
</div>
