<!---------   
=== Theme Author : Evan Ahmed EMon
=== Theme Designed By: TWG
=== Contact Whatsapp: +8801864614704
 ----------->  
<div class="container">
    <div class="row justify-content-center align-items-center" style="min-height: 100vh;">
        <div class="col-md-6 text-center">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="row align-items-center">
                        <div class="col-md-6 text-center">
                            <i class="fa fa-exclamation-triangle" style="font-size: 100px; color: red;"></i>
                        </div>
                        <div class="col-md-6">
                            <h2 style="font-size: 30px; color: #333; font-weight: bold; margin-bottom: 20px;">You are not authorized to access this page.</h2>
                            <p style="font-size: 18px; color: #555;">It seems like you don't have permission to view this page. Please contact the administrator if you believe this is an error.</p>
                        </div>
                    </div>
                    <a href="<?php echo site_url('admin'); ?>" class="btn btn-danger mt-3" style="font-size: 16px; padding: 10px 20px;">Go Back to Dashboard</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Optionally, you can add a background overlay -->
<style>
    .container {
        background-color: #f8f9fa; /* Light background for the container */
    }

    .panel {
        border: none;
        border-radius: 8px;
        box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1); /* Subtle shadow effect */
    }

    .panel-body {
        padding: 40px;
    }

    h2 {
        font-family: 'Arial', sans-serif;
        font-weight: bold;
        color: #333;
    }

    p {
        font-size: 18px;
        color: #555;
        line-height: 1.6;
    }

    .btn-danger {
        background-color: #e74c3c;
        border: none;
        padding: 12px 25px;
        font-size: 16px;
        text-transform: uppercase;
        border-radius: 5px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .btn-danger:hover {
        background-color: #c0392b;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    }

    .fa-exclamation-triangle {
        color: #e74c3c;
    }
</style>

