<!---------   
=== Theme Author : Evan Ahmed EMon
=== Theme Designed By: TWG
=== Contact Whatsapp: +8801864614704
 ----------->  
 
 <?php include 'header.php'; ?>

<style>
/* ── Responsive fixes for Referrals/Payouts admin page ── */
@media (max-width: 991px) {
    .container-fluid .row > .col-md-2,
    .container-fluid .row > .col-md-10 {
        width: 100%;
        float: none;
    }
    .nav-stacked.p-b {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
        margin-bottom: 14px;
    }
    .nav-stacked.p-b > li {
        flex: 1;
        text-align: center;
    }
    .nav-stacked.p-b > li > a {
        border-radius: 4px;
    }
}

@media (max-width: 767px) {
    .nav-tabs > li.pull-right.p-b {
        float: none !important;
        width: 100%;
        margin-bottom: 12px;
    }
    .nav-tabs > li.pull-right.p-b .form-inline {
        width: 100%;
    }
    .nav-tabs > li.pull-right.p-b .input-group {
        width: 100%;
        display: flex;
    }
    .nav-tabs > li.pull-right.p-b .form-control {
        flex: 1;
    }

    /* Hide default table header, render rows as cards */
    .order-table thead {
        display: none;
    }
    .order-table, 
    .order-table tbody, 
    .order-table tr, 
    .order-table td {
        display: block;
        width: 100% !important;
    }
    .order-table tr {
        background: #fff;
        border: 1px solid #e3e3e3;
        border-radius: 8px;
        margin-bottom: 14px;
        padding: 10px 12px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    .order-table td {
        border: none !important;
        border-bottom: 1px solid #f0f0f0 !important;
        padding: 8px 0 !important;
        display: flex;
        justify-content: space-between;
        align-items: center;
        text-align: right;
        word-break: break-word;
    }
    .order-table td:last-child {
        border-bottom: none !important;
    }
    .order-table td::before {
        content: attr(data-label);
        font-weight: 600;
        color: #555;
        text-align: left;
        padding-right: 10px;
        flex-shrink: 0;
    }
    .order-table td.service-block__action {
        justify-content: flex-end;
    }
    .order-table td.service-block__action .dropdown.pull-right {
        float: none !important;
        width: 100%;
    }
    .order-table td.service-block__action .dropdown-toggle {
        width: 100%;
    }
}
</style>

<div class="container-fluid">
<div class="row">
<div class="col-md-2">
<ul class="nav nav-pills nav-stacked p-b">
<li class=""><a href="/admin/referrals">Referrals</a></li>
<li class="active"><a href="/admin/payouts">Payouts</a></li>
</ul>
</div>
<div class="col-md-10">
<ul class="nav nav-tabs">
<li class="pull-right p-b">
<form class="form-inline" action="" method="GET">
<div class="input-group">
<input type="text" name="search" class="form-control" placeholder="Search">
<input type="hidden" name="type" value="referrals">
<span class="input-group-btn">
<button type="submit" class="btn btn-default"><span class="glyphicon glyphicon-search" aria-hidden="true"></span></button>
</span>
</div>
</form>
</li>
</ul>
                            <div class="table-responsive">
                            <table class="table order-table">
                                <thead>
                                    <tr>
                                        <th class="p-l">#</th>
                                        <th> Code</th>
                                        <th> Username </th>
                                        <th>Amount Requested</th>
                                        <th>Payout Status</th>
                                        <th>Payout Created At</th>
                                        <th>Payout Updated At</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <form id="changebulkForm" action="<?php echo site_url("admin/payouts") ?>" method="post">
                                    <tbody>
                                        <?php foreach ($referral_payouts as $referral_payout) : ?>
                                            <tr>
                                                <td data-label="#"><?php echo $referral_payout["r_p_id"] ?></td>
                                                <td data-label="Code"><?php echo $referral_payout["r_p_code"] ?></td>
                                                <td data-label="Username"><?php echo $referral_payout["username"] ?></td>
                                                <td data-label="Amount Requested"><?php echo $referral_payout["r_p_amount_requested"] ?></td>
                                                <td data-label="Payout Status"><?php if ($referral_payout["r_p_status"] == 0) {
                                                        echo "Pending";
                                                    } elseif (
                                                        $referral_payout["r_p_status"] == 1
                                                    ) {
                                                        echo "Disapproved ";
                                                    }elseif (
                                                        $referral_payout["r_p_status"] == 2
                                                    ){
                                                        echo "Approved ";
                                                    } else {
                                                        echo "Rejected ";
                                                    }
                                                       
                                                      ?></td>
                                                <td data-label="Created At"><?php echo $referral_payout["r_p_requested_at"] ?></td>
                                                <td data-label="Updated At"><?php echo $referral_payout["r_p_updated_at"] ?></td>


                                                <td class="service-block__action" data-label="Actions">
                                                    <div class="dropdown pull-right">
                                                        <button type="button" class="btn btn-primary btn-xs dropdown-toggle btn-xs-caret" data-toggle="dropdown">Action</button>
                                                        <ul class="dropdown-menu">

                                                            <?php if ($referral_payout["r_p_status"] == 0) : ?>
                                                              
                                                                    <li><a href="<?= site_url("admin/payouts?approve=" . $referral_payout["r_p_id"]) ?>">Approve</a></li>
                                                                    <li><a href="<?= site_url("admin/payouts?disapprove=" . $referral_payout["r_p_id"]) ?>">Disapprove</a></li>
                                                                    <li><a href="<?= site_url("admin/payouts?reject=" . $referral_payout["r_p_id"]) ?>">Reject</a></li>

                                                             
                                                            <?php else : ?>

                                                                <li><a href="javascript:void(0)">No options to use</a></li>
                                                            <?php endif; ?>

                                                        </ul>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                    <input type="hidden" name="bulkStatus" id="bulkStatus" value="0">
                                </form>
                            </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?php include 'footer.php'; ?>
