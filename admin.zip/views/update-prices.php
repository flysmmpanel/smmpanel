<!---------   
=== Theme Author : Evan Ahmed EMon
=== Theme Designed By: TWG
=== Contact Whatsapp: +8801864614704
 -----------> 
 
 <?php include 'header.php'; ?>
 
 <link rel="stylesheet" href="https://cdn.quilljs.com/1.3.6/quill.snow.css">
<link rel="stylesheet" href="https://cdn.rentalpanelbd.com/admin/css/fancyselect.css">
<link href="https://cdn.rentalpanelbd.com/admin/css/tom-select.bootstrap5.min.css" rel="stylesheet">
 
 <div class="modal fade" id="staticBackdropModal" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropModalLabel" aria-hidden="true">

   <div class="modal-dialog">
      <div class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            <h4 class="modal-title" id="modalTitle"></h4>
         </div>
         <div class="modal-body" id="modalBody"></div>
      </div>
   </div>
</div>

<div class="container-fluid margin-top-container">
   <div class="container">
      <div class="row">
         <div class="col-md-6 col-md-offset-3 increase-decrease-form ">
            <div class="panel panel-default">
            <div class="panel-heading">Update Prices</div>
<form action="admin/update-prices" method="POST">
<div class="panel-body">
                     <div class="form-group">
                        <label for="special_pricing_service_type" class="form-label">Services Type</label>
<select name="service_type" id="special_pricing_service_type">
<option value="all_services">All Services</option>
<option value="seller_services">Seller Services</option>
<option value="manual_services">Manual Services</option>
</select>
</div>

<div style="display:none;" id="special-pricing-seller-select-div" class="form-group">
<div class="mb-3" >
 <label for="select-seller" class="form-label">Sellers</label>
<select class="fsb-ignore multiple" name="sellers[]" id="select-seller" multiple autocomplete="off" data-placeholder="Select a seller...">
<?=$providers_option;?>
</select></div>
</div>


                     <div class="form-group">
                        <label class="form-label">Profit Percentage</label>
                        <div class="input-group">
                           <input type="number" name="profit-percent-value" id="profit-percent-value" class="form-control" placeholder="10" aria-label="Profit Percentage">
                           <span class="input-group-addon"><i class="glyphicon glyphicon-percent"></i></span>
                        </div>
                     </div>

                     <div class="form-group" id="action_type_div"></div>
                     <div class="form-group" id="services_display_div" style="display: none;">
                        <h5>Available Services</h5>
                        <ul id="services-list"></ul>
                     </div>
                  </div>
                  <div class="panel-footer">
                     <button type="submit" data-loading-text="Saving..." class="btn btn-primary">Save changes</button>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>



<script type="text/javascript" src="//code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
<script src="https://cdn.jsdelivr.net/gh/mdbassit/FancySelect@latest/dist/fancyselect.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/tom-select@2.2.2/dist/js/tom-select.complete.min.js"></script>

<script>
    $(document).ready(function() {
        // Show/Hide seller selection based on service type
        $("#special_pricing_service_type").change(function() {
            var val = $(this).val();
            var selector = $("#special-pricing-seller-select-div");
            if (val === "seller_services") {
                selector.show();
            } else {
                selector.hide();
                $("#services_display_div").hide(); // Hide services display if not selecting seller services
            }
        });

        // Show services based on selected sellers
        $("#select-seller").change(function() {
            var selectedSellers = $(this).val();
            $("#services-list").empty();

            if (selectedSellers.length > 0) {
                selectedSellers.forEach(function(seller) {
                    // Fetch services for the seller (replace this part with your actual fetching logic)
                    $("#services-list").append(`<li>Service for ${seller}</li>`); // Example of adding a service
                });
                $("#services_display_div").show();
            } else {
                $("#services_display_div").hide();
            }
        });

        // Update action type options based on profit percentage input
        $("#profit-percent-value").keyup(function() {
            var percent = $(this).val();
            if (percent) {
                var html = `<div class="mb-3"><label for="action_type" class="form-label">Action</label>
                            <select name="action_type" id="action_type">
                                <option value="set_profit">Set profit to ${percent}%</option>
                                <option value="increase_profit">Increase profit by ${percent}%</option>
                                <option value="decrease_profit">Decrease profit by ${percent}%</option>
                            </select></div>`;
                $("#action_type_div").html(html);
                FancySelect.init("#action_type");
            } else {
                $("#action_type_div").empty();
            }
        });

        // Handle form submission
        $("#updatePricesForm").submit(function(event) {
            event.preventDefault(); // Prevent the default form submission
            var formData = $(this).serialize(); // Serialize the form data

            $.ajax({
                type: "POST",
                url: $(this).attr('action'),
                data: formData,
                success: function(response) {
                    // Assuming the response contains a title and body
                    $("#modalTitle").text("Success");
                    $("#modalBody").html(response);
                    $("#staticBackdropModal").modal("show");
                },
                error: function(xhr, status, error) {
                    $("#modalTitle").text("Error");
                    $("#modalBody").html("An error occurred: " + error);
                    $("#staticBackdropModal").modal("show");
                }
            });
        });
    });
</script>

<?php include 'footer.php'; ?>


