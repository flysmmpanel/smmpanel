<!-- 
    ===========================
    Theme Author: qurban
    Theme Designed By: Mirxa 
    Contact WhatsApp: +923484262861
    ===========================
-->
<?php include 'header.php'; ?>

<?php
/* ===== DATE RANGE ===== */
$start_date = isset($_GET['start']) ? $_GET['start'] : date('Y-m-d', strtotime('-6 days'));
$end_date   = isset($_GET['end'])   ? $_GET['end']   : date('Y-m-d');

/* ===== ARRAYS ===== */
$labels = [];
$completed = [];
$canceled  = [];
$partial   = [];
$fail      = [];

$final_statuses = ['completed', 'canceled', 'partial', 'fail'];

/* ===== DATE LOOP ===== */
$period = new DatePeriod(
    new DateTime($start_date),
    new DateInterval('P1D'),
    (new DateTime($end_date))->modify('+1 day')
);

foreach($period as $day){
    $date = $day->format('Y-m-d');
    $labels[] = $date;

    foreach($final_statuses as $status){
        $stmt = $conn->prepare("
            SELECT COUNT(*) as total 
            FROM orders 
            WHERE DATE(order_create) = :date 
            AND order_status = :status
        ");
        $stmt->execute([
            'date'=>$date,
            'status'=>$status
        ]);
        ${$status}[] = (int)$stmt->fetch(PDO::FETCH_ASSOC)['total'];
    }
}

/* ===== LAST 12 MONTHS REVENUE ===== */
$revenue_labels = [];
$revenue_data   = [];

for($i = 11; $i >= 0; $i--){
    $month_start = date('Y-m-01', strtotime("-$i months"));
    $month_end   = date('Y-m-t',  strtotime("-$i months"));
    $month_label = date('M Y',    strtotime("-$i months"));

    $revenue_labels[] = $month_label;

    $rev_stmt = $conn->prepare("
        SELECT COALESCE(SUM(payment_amount), 0) as total
        FROM payments
        WHERE payment_create_date BETWEEN :start AND :end
        AND payment_status = 3
    ");
    $rev_stmt->execute([
        'start' => $month_start . ' 00:00:00',
        'end'   => $month_end   . ' 23:59:59'
    ]);
    $revenue_data[] = (float)$rev_stmt->fetch(PDO::FETCH_ASSOC)['total'];
}

/* ===== AJAX RESPONSE ===== */
if(isset($_GET['ajax']) && $_GET['ajax']==1){
    header('Content-Type: application/json');
    echo json_encode([
        'labels'=>$labels,
        'completed'=>$completed,
        'canceled'=>$canceled,
        'partial'=>$partial,
        'fail'=>$fail
    ]);
    exit;
}
?>

<style>
body {
    font-family: 'Segoe UI', Arial, sans-serif;
    background: #f0f4f8;
    margin: 0;
    padding: 20px;
}

.container-fluid {
    max-width: 1200px;
    margin: auto;
}

/* Card Style */
.card {
    background: #fff;
    border-radius: 14px;
    border: 1px solid #e3eaf3;
    box-shadow: none;
    margin-bottom: 20px;
    overflow: hidden;
    animation: pageFade 0.6s ease both;
}
.card a {
    text-decoration: none;
    color: inherit;
}
.card:hover {
    box-shadow: none;
}

/* Remove animated gradient border */
.card::before { display: none; }
.card > * { position: relative; z-index: 1; }

/* Card Body */
.card-body {
    padding: 20px;
}

/* Chart Wrapper */
.orders-analysis-section {
    background: #fff;
    padding: 25px 20px;
    border-radius: 14px;
    border: 1px solid #e3eaf3;
    box-shadow: none;
    margin-top: 30px;
    animation: pageFade 0.6s ease both;
}

.orders-analysis-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.orders-analysis-header h4 {
    color: #1565C0;
    font-size: 14px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.date-filter {
    display: flex;
    gap: 10px;
    align-items: center;
}

.date-filter input {
    padding: 6px 10px;
    border-radius: 8px;
    border: 1px solid #e3eaf3;
    font-size: 13px;
}

.date-filter button {
    padding: 6px 14px;
    background: #1565C0;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-weight: 600;
    font-size: 13px;
    color: #fff;
}

.chart-wrapper {
    position: relative;
    height: 400px;
    width: 100%;
}

/* Revenue Chart Section */
.revenue-history-section {
    background: #fff;
    padding: 25px 20px;
    border-radius: 14px;
    border: 1px solid #e3eaf3;
    box-shadow: none;
    margin-top: 30px;
    animation: pageFade 0.6s ease both;
}

.revenue-history-section h4 {
    color: #1565C0;
    font-size: 14px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 20px;
}

.revenue-chart-wrapper {
    position: relative;
    height: 400px;
    width: 100%;
}

/* Page fade animation */
@keyframes pageFade {
    from { opacity: 0; transform: translateY(12px); }
    to   { opacity: 1; transform: translateY(0); }
}
</style>

<style>
html, body {
    width: 100%;
    height: 100%;
    margin: 0;
    padding: 0;
    overflow-x: hidden;
}

/* Utilities */
.pt-4 { padding-top: 1.5rem !important; }
.px-4 { padding-right: 1.5rem !important; padding-left: 1.5rem !important; }
.g-4, .gy-4 { --bs-gutter-y: 1.5rem; }
.g-4, .gx-4 { --bs-gutter-x: 1.5rem; }
.rounded { border-radius: 5px !important; }
.p-4 { padding: 1.5rem !important; }
.align-items-center { align-items: center !important; }
.justify-content-between { justify-content: space-between !important; }
.d-flex { display: flex !important; }
.text-primary { color: #1565C0 !important; }
.ms-3 { margin-left: 1rem !important; }
.mb-2 { margin-bottom: .5rem !important; }
.mb-0 { margin-bottom: 0 !important; }

/* Statistics Card */
.satistics {
    margin: 5px;
    border-radius: 12px;
    box-shadow: none;
    border: 1px solid #e3eaf3;
    transition: all .2s;
    background: #1565C0;
}
.satistics { margin-bottom: 10px; }

/* Button Style */
.button-1 {
    background-color: #1565C0;
    border-radius: 8px;
    border-style: none;
    color: #fff;
    font-family: 'Segoe UI', Arial, sans-serif;
    font-size: 14px;
    font-weight: 600;
    height: 40px;
    padding: 10px 16px;
    text-align: center;
    cursor: pointer;
    outline: none;
    transition: background-color 0.2s ease;
}
.button-1:hover { background-color: #0D47A1; }

/* Flexbox */
.stretch-card { display: flex; align-items: stretch; justify-content: stretch; }
.grid-margin { margin-bottom: 1.875rem; }
.stretch-card > .card { width: 100%; min-width: 100%; }

/* Card base */
.card {
    position: relative;
    display: flex;
    flex-direction: column;
    min-width: 0;
    background: #fff;
    border-radius: 14px;
    border: 1px solid #e3eaf3;
    box-shadow: none;
}

/* Card Body */
.card-body { flex: 1 1 auto; padding: 1.25rem; }
.card .card-body { padding: 1.25rem; }

/* Icon */
.icon-card-primary .icon,
.icon-card-success .icon,
.icon-card-dark .icon,
.icon-card-info .icon {
    width: 30px;
    height: 30px;
    border-radius: 8px;
    background: rgba(255,255,255,0.25);
    text-align: center;
}
.icon i { font-size: 17px; line-height: 30px; text-align: center; color: white; }
.font-weight-medium { font-weight: 500; }
p { font-size: 1.4rem; margin-bottom: .5rem; line-height: 1.3rem; }

/* Margins */
.mt-3 { margin-top: 1rem !important; }
.flex-wrap { flex-wrap: wrap !important; }
.font-weight-normal { font-weight: 400 !important; }
.mr-2 { margin-right: 0.5rem !important; }
.mb-0, .my-0 { margin-bottom: 0 !important; }

/* Badges */
.badges { display: inline-block; padding: 0.25em 0.4em; font-size: 75%; font-weight: 700; line-height: 1; text-align: center; background-color: transparent; margin-top: 18px; border-radius: 0.25rem; }
.badge-pill { padding-right: 0.6em; padding-left: 0.6em; border-radius: 10rem; }
.badge { border-radius: 4px; font-size: 11px; padding: .475rem .5625rem; font-weight: normal; }

/* Icon Card Colors — all blue shades */
.icon-card-info      { background: #1E88E5 !important; color: #fff; }
.icon-card-primary   { background: #1565C0 !important; color: #fff; }
.icon-card-success   { background: #1976D2 !important; color: #fff; }
.icon-card-dark      { background: #0D47A1 !important; color: #fff; }
.icon-card-secondary { background: #42A5F5 !important; color: #fff; }
.icon-card-danger    { background: #1565C0 !important; color: #fff; }
.icon-card-bd        { background: #2196F3 !important; color: #fff; }
.icon-card-man       { background: #1976D2 !important; color: #fff; }
.icon-card-bgt       { background: #0288D1 !important; color: #fff; }
.icon-card-glow      { background: #1565C0 !important; color: #fff; }

/* NO animated border */
.card::before { display: none; }
.card > * { position: relative; z-index: 1; }
</style>


<div class="container-fluid">
<?php if ($admin["two_factor"] == 0) : ?>
    <div class="alert alert-danger" id="two-factor-alert" 
         style="position: relative; padding: 5px; background-color: #f8d7da; 
                border: 1px solid #f5c6cb; color: #721c24; border-radius: 5px; 
                display: flex; justify-content: space-between; align-items: center; 
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
        <div style="display: flex; align-items: center;">
            <strong><i class="fa fa-exclamation-circle" style="margin-right: 5px; font-size: 18px;"></i></strong>
            <span style="font-size: 14px; font-weight: bold;">
                2FACTOR AUTHENTICATION IS DISABLED! TURN ON FOR EXTRA SECURITY.
            </span>
        </div>
        <div style="display: flex; align-items: center;">
            <a class="btn btn-danger btn-xs" 
               href="<?php echo site_url('admin/activate-google-2fa') ?>" 
               style="font-size: 12px; color: white; text-decoration: none; margin-right: 10px; 
                      padding: 5px 10px; background-color: #dc3545; border-radius: 5px;">
                <i class="fa fa-shield-alt"></i> Enable Now
            </a>
            <span class="closebtn" onclick="document.getElementById('two-factor-alert').style.display='none';" 
                  style="font-size: 18px; cursor: pointer; color: #721c24;">&times;</span>
        </div>
    </div>
<?php endif; ?>

    <div class="row">
<!-- Users Card -->
<div class="col-12 col-sm-6 col-md-3 grid-margin stretch-card">
    <div class="card" style="background: linear-gradient(135deg, #1E3C72, #2A5298);">
        <a style="text-decoration:none;color:#fff;" href="admin/clients">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="icon mb-0 mb-md-2 mb-xl-0 mr-2">
                        <i class="fa fa-users"></i>
                    </div>
                    <p class="font-weight-medium mb-0">Clients</p>
                </div>
                <div class="d-flex align-items-center mt-3 flex-wrap">
                    <h3 class="font-weight-normal mb-0 mr-2"><?php echo countRow(["table"=>"clients"]) ?></h3>
                    <div class="badge badge-outline-light badge-pill mt-md-2 mt-xl-0">
                        <div class="d-flex align-items-baseline">
                            <?php 
                            $clients = $conn->prepare("SELECT * FROM clients");
                            $clients->execute();
                            $clients = $clients->fetchAll(PDO::FETCH_ASSOC);
                            $month = date('m');
                            $previous_month = date("m", strtotime('-1 month', strtotime(date('Y-m-d'))));
                            
                            $count_this_month = 0;
                            $count_previous_month = 0;
                            $today = date('Y-m-d');
                            $count_today_users = 0;

                            foreach ($clients as $client) {
                                $register_month = explode("-", explode(" ", $client["register_date"])[0])[1];
                                $register_date = explode(" ", $client["register_date"])[0];
                                
                                if ($register_month == $month) {
                                    $count_this_month++;
                                }
                                if ($register_month == $previous_month) {
                                    $count_previous_month++;
                                }
                                if ($register_date == $today) {
                                    $count_today_users++;
                                }
                            }

                            $show_users = $count_this_month - $count_previous_month;
                            $growth_users = ($show_users >= 0) ? 
                                '<span class="mb-0 mr-2">'.$count_today_users.'</span><i class="fas fa-arrow-up"></i>' :
                                '<span class="mb-0 mr-2">'.abs($count_today_users).'</span><i class="fas fa-arrow-down"></i>';
                            ?>
                            <?=$growth_users?>
                        </div>
                    </div>
                </div>
                <small class="font-weight-medium d-block mt-2">Total</small>
            
            </div>
        </a>
    </div>
</div>

        <!-- Active Services Card -->
        <div class="col-12 col-sm-6 col-md-3 grid-margin stretch-card">
            <div class="card icon-card-bd" style="background: linear-gradient(135deg, #0F2027, #203A43, #2C5364);">
                <a style="text-decoration:none;color:#ffffff;" href="/admin/services">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="icon mb-0 mb-md-2 mb-xl-0 mr-2">
                                <i class="fas fa-cogs"></i>
                            </div>
                            <p class="font-weight-medium mb-0">Total Active Services</p>
                        </div>
                        <div class="d-flex align-items-center mt-3 flex-wrap">
                            <h3 class="font-weight-normal mb-0 mr-2"><?php echo countRow(["table"=>"services"]) ?></h3>
                        </div>
                        <small class="font-weight-medium d-block mt-2">Total</small>
                    </div>
                </a>
            </div>
        </div>

        <!-- Undead Tickets Card -->
        <div class="col-12 col-sm-6 col-md-3 grid-margin stretch-card">
            <div class="card icon-card-man" style="background: linear-gradient(135deg, #DA4453, #89216B);">
                <a style="text-decoration:none;color:#ffffff;" href="/admin/tickets?search=unread">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="icon mb-0 mb-md-2 mb-xl-0 mr-2">
                                <i class="fas fa-ticket-alt"></i>
                            </div>
                            <p class="font-weight-medium mb-0">Undead Tickets</p>
                        </div>
                        <div class="d-flex align-items-center mt-3 flex-wrap">
                            <h3 class="font-weight-normal mb-0 mr-2"><?php echo countRow(["table"=>"tickets"]) ?></h3>
                        </div>
                        <small class="font-weight-medium d-block mt-2">Total</small>
                    </div>
                </a>
            </div>
        </div>

<div class="col-12 col-sm-6 col-md-3 grid-margin stretch-card">
    <div class="card" style="background: linear-gradient(135deg, #654EA3, #EAAFC8);">
        <a style="text-decoration:none;color:#ffffff;" href="/admin/appearance/themes">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="icon mb-0 mb-md-2 mb-xl-0 mr-2">
                        <i class="fas fa-paint-brush"></i>
                    </div>
                    <p class="font-weight-medium mb-0">Active Theme</p>
                </div>

                <div class="d-flex align-items-center mt-3 flex-wrap">
                    <h3 class="font-weight-normal mb-0">
                        <?php echo ucfirst($settings["site_theme"]); ?>
                    </h3>
                </div>

                <small class="font-weight-medium d-block mt-2">
                    Currently Activated
                </small>
            </div>
        </a>
    </div>
</div>

<div class="col-12 col-sm-6 col-md-3 grid-margin stretch-card">
    <div class="card" style="background: linear-gradient(135deg, #11998E, #0575E6);">
        <a style="text-decoration:none;color:#ffffff;" href="/admin/settings/providers">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="icon mb-0 mb-md-2 mb-xl-0 mr-2">
                        <i class="fas fa-network-wired"></i>
                    </div>
                    <p class="font-weight-medium mb-0">API Providers</p>
                </div>
                <div class="d-flex align-items-center mt-3 flex-wrap">
                    <h3 class="font-weight-normal mb-0">
                        <?php echo countRow(["table"=>"service_api"]); ?>
                    </h3>
                </div>
                <small class="font-weight-medium d-block mt-2">Total Connected</small>
            </div>
        </a>
    </div>
</div>

<!-- Orders Card -->
<div class="col-12 col-sm-6 col-md-3 grid-margin stretch-card">
    <div class="card" style="background: linear-gradient(135deg, #00B09B, #96C93D);">
        <a style="text-decoration:none;color:#ffffff;" href="/admin/orders">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="icon mb-0 mb-md-2 mb-xl-0 mr-2">
                        <i class="fas fa-shopping-bag"></i>
                    </div>
                    <p class="font-weight-medium mb-0">Orders</p>
                </div>
                <div class="d-flex align-items-center mt-3 flex-wrap">
                    <h3 class="font-weight-normal mb-0 mr-2"><?php echo countRow(["table"=>"orders"]) ?></h3>
                    <div class="badge badge-outline-light badge-pill mt-md-2 mt-xl-0">
                        <div class="d-flex align-items-baseline">
                            <span class="mr-2"></span>
                            <?php 
                            $orders = $conn->prepare("SELECT * FROM orders");
                            $orders->execute();
                            $orders = $orders->fetchAll(PDO::FETCH_ASSOC);
                            $count_this_month_orders = 0;
                            $count_previous_month_orders = 0;
                            $count_today_orders = 0;

                            foreach ($orders as $order) {
                                $order_month = explode("-", explode(" ", $order["order_create"])[0])[1];
                                $order_date = explode(" ", $order["order_create"])[0];

                                if ($order_month == $month) {
                                    $count_this_month_orders++;
                                }
                                if ($order_month == $previous_month) {
                                    $count_previous_month_orders++;
                                }
                                if ($order_date == $today) {
                                    $count_today_orders++;
                                }
                            }

                            $show_orders = $count_this_month_orders - $count_previous_month_orders;
                            $growth_orders = ($show_orders >= 0) ? 
                                '<span class="mb-0 mr-2">'. $count_today_orders .'</span><i class="fas fa-arrow-up"></i>' :
                                '<span class="mb-0 mr-2">'.abs($count_today_orders).'</span><i class="fas fa-arrow-down"></i>';
                           ?>
                            <?=$growth_orders?>
                        </div>
                    </div>
                </div>
                <small class="font-weight-medium d-block mt-2">Total</small>
        
            </div>
        </a>
    </div>
</div>

        <!-- Failed Orders Card -->
        <div class="col-12 col-sm-6 col-md-3 grid-margin stretch-card">
            <div class="card" style="background: linear-gradient(135deg, #CB2D3E, #EF473A);">
                <a style="text-decoration:none;color:#ffffff;" href="/admin/orders/1/fail">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="icon mb-0 mb-md-2 mb-xl-0 mr-2">
                                <i class="glyphicon glyphicon-remove"></i>
                            </div>
                            <p class="font-weight-medium mb-0">Failed Orders</p>
                        </div>
                        <div class="d-flex align-items-center mt-3 flex-wrap">
                            <h3 class="font-weight-normal mb-0 mr-2"><?php echo $failCount ?></h3>
                        </div>
                        <small class="font-weight-medium d-block mt-2">Total</small>
                    </div>
                </a>
            </div>
        </div>
       
        <div class="col-md-12 col-sm-6 col-md-3 grid-margin stretch-card">
            <div class="card icon-card-bgt" style="background: linear-gradient(135deg, #4568DC, #B06AB3);">
                <a style="text-decoration:none;color:#fff;" href="/admin/orders/1/all?mode=manuel">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="icon mb-0 mb-md-2 mb-xl-0 mr-2">
                                <i class="fas fa-headset"></i>
                            </div>
                            <p class="font-weight-medium mb-0">Manual Orders</p>
                        </div>
                        <div class="d-flex align-items-center mt-3 flex-wrap">
                            <h3 class="font-weight-normal mb-0 mr-2"><?php echo countRow(["table"=>"orders","where"=>["api_orderid"=>0] ]) ?></h3>
                        </div>
                        <small class="font-weight-medium d-block mt-2">Total</small>
                    </div>
                </a>
            </div>
        </div> 
        
        <div class="col-12 col-sm-6 col-md-3 grid-margin stretch-card">
            <div class="card" style="background: linear-gradient(135deg, #43C6AC, #191654);">
                <a style="text-decoration:none;color:#ffffff;" href="/admin/orders/1/all?mode=api">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="icon mr-2">
                                <i class="fas fa-plug"></i>
                            </div>
                            <p class="font-weight-medium mb-0">API Orders</p>
                        </div>

                        <div class="d-flex align-items-center mt-3 flex-wrap">
                            <h3 class="font-weight-normal mb-0">
                                <?php
                                $query = $conn->prepare("
                                    SELECT 
                                        COUNT(*) as total,
                                        SUM(CASE WHEN api_orderid = 0 THEN 1 ELSE 0 END) as manual
                                    FROM orders
                                ");
                                $query->execute();
                                $data = $query->fetch(PDO::FETCH_ASSOC);
                                echo $data["total"] - $data["manual"];
                                ?>
                            </h3>
                        </div>

                        <small class="font-weight-medium d-block mt-2">Total</small>
                    </div>
                </a>
            </div>
        </div>

        <div class="col-12 col-sm-6 col-md-3 grid-margin stretch-card">
            <div class="card" style="background: linear-gradient(135deg, #F7971E, #FFD200);">
                <a style="text-decoration:none;color:#ffffff;" href="/admin/orders/1/pending">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="icon mb-0 mb-md-2 mb-xl-0 mr-2">
                                <i class="fas fa-hourglass-half"></i>
                            </div>
                            <p class="font-weight-medium mb-0">Pending Orders</p>
                        </div>
                        <div class="d-flex align-items-center mt-3 flex-wrap">
                            <h3 class="font-weight-normal mb-0">
                                <?php echo countRow(["table"=>"orders","where"=>["order_status"=>"pending"]]); ?>
                            </h3>
                        </div>
                        <small class="font-weight-medium d-block mt-2">Total</small>
                    </div>
                </a>
            </div>
        </div>

        <div class="col-12 col-sm-6 col-md-3 grid-margin stretch-card">
            <div class="card" style="background: linear-gradient(135deg, #36D1DC, #5B86E5);">
                <a style="text-decoration:none;color:#ffffff;" href="/admin/orders/1/processing">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="icon mb-0 mb-md-2 mb-xl-0 mr-2">
                                <i class="fas fa-sync-alt"></i>
                            </div>
                            <p class="font-weight-medium mb-0">Processing Orders</p>
                        </div>

                        <div class="d-flex align-items-center mt-3 flex-wrap">
                            <h3 class="font-weight-normal mb-0">
                                <?php 
                                echo countRow([
                                    "table"=>"orders",
                                    "where"=>["order_status"=>"processing"]
                                ]); 
                                ?>
                            </h3>
                        </div>

                        <small class="font-weight-medium d-block mt-2">Total</small>
                    </div>
                </a>
            </div>
        </div>

        <div class="col-12 col-sm-6 col-md-3 grid-margin stretch-card">
            <div class="card" style="background: linear-gradient(135deg, #667EEA, #764BA2);">
                <a style="text-decoration:none;color:#ffffff;" href="/admin/orders/1/inprogress">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="icon mb-0 mb-md-2 mb-xl-0 mr-2">
                                <i class="fas fa-spinner"></i>
                            </div>
                            <p class="font-weight-medium mb-0">In Progress Orders</p>
                        </div>
                        <div class="d-flex align-items-center mt-3 flex-wrap">
                            <h3 class="font-weight-normal mb-0">
                                <?php echo countRow(["table"=>"orders","where"=>["order_status"=>"inprogress"]]); ?>
                            </h3>
                        </div>
                        <small class="font-weight-medium d-block mt-2">Total</small>
                    </div>
                </a>
            </div>
        </div>

        <div class="col-12 col-sm-6 col-md-3 grid-margin stretch-card">
            <div class="card" style="background: linear-gradient(135deg, #FF9966, #FF5E62);">
                <a style="text-decoration:none;color:#ffffff;" href="/admin/orders/1/partial">
                    <div class="card-body">
                        <div class="d-flex align-items-center mt-3 flex-wrap">
                            <div class="icon mb-0 mb-md-2 mb-xl-0 mr-2">
                                <i class="fas fa-adjust"></i>
                            </div>
                            <p class="font-weight-medium mb-0">Partial Orders</p>
                        </div>

                        <div class="mt-3">
                            <h3 class="font-weight-normal mb-0">
                                <?php 
                                echo countRow([
                                    "table"=>"orders",
                                    "where"=>["order_status"=>"partial"]
                                ]); 
                                ?>
                            </h3>
                        </div>

                        <small class="font-weight-medium d-block mt-2">Total</small>
                    </div>
                </a>
            </div>
        </div>

        <div class="col-12 col-sm-6 col-md-3 grid-margin stretch-card">
            <div class="card" style="background: linear-gradient(135deg, #8E2DE2, #4A00E0);">
                <a style="text-decoration:none;color:#ffffff;" href="/admin/orders/1/canceled">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="icon mb-0 mb-md-2 mb-xl-0 mr-2">
                                <i class="fas fa-times-circle"></i>
                            </div>
                            <p class="font-weight-medium mb-0">Canceled Orders</p>
                        </div>
                        <div class="d-flex align-items-center mt-3 flex-wrap">
                            <h3 class="font-weight-normal mb-0">
                                <?php echo countRow(["table"=>"orders","where"=>["order_status"=>"canceled"]]); ?>
                            </h3>
                        </div>
                        <small class="font-weight-medium d-block mt-2">Total</small>
                    </div>
                </a>
            </div>
        </div>

        <div class="col-12 col-sm-6 col-md-3 grid-margin stretch-card">
            <div class="card" style="background: linear-gradient(135deg, #11998E, #38EF7D);">
                <a style="text-decoration:none;color:#ffffff;" href="/admin/orders/1/completed">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="icon mb-0 mb-md-2 mb-xl-0 mr-2">
                                <i class="fas fa-check-circle"></i>
                            </div>
                            <p class="font-weight-medium mb-0">Completed Orders</p>
                        </div>

                        <div class="d-flex align-items-center mt-3 flex-wrap">
                            <h3 class="font-weight-normal mb-0">
                                <?php 
                                echo countRow([
                                    "table"=>"orders",
                                    "where"=>["order_status"=>"completed"]
                                ]); 
                                ?>
                            </h3>
                        </div>

                        <small class="font-weight-medium d-block mt-2">Total</small>
                    </div>
                </a>
            </div>
        </div>

<!-- Funds Added Today Card -->
<div class="col-12 col-sm-6 col-md-3 grid-margin stretch-card">
    <div class="card icon-card-dark" style="background: linear-gradient(135deg, #141E30, #243B55);">
        <div class="card-body">
            <div class="d-flex align-items-center">
                <div class="icon mb-0 mb-md-2 mb-xl-0 mr-2">
                    <i class="glyphicon glyphicon-rupee"></i>
                </div>
                <p class="font-weight-medium mb-0">Total Funds Added Today</p>
            </div>
            <div class="d-flex align-items-center mt-3 flex-wrap">
                <h3 class="font-weight-normal mb-0 mr-2">
                    <?php 
                        echo "PKR ";
                        $today_start = date('Y-m-d 00:00:00');
                        $today_end = date('Y-m-d 23:59:59');
                        $query = $conn->prepare("SELECT SUM(payment_amount) as total FROM payments 
                                                 WHERE payment_create_date BETWEEN :start AND :end 
                                                 AND payment_status = 3");
                        $query->execute(["start" => $today_start, "end" => $today_end]);
                        $result = $query->fetch(PDO::FETCH_ASSOC);
                        echo $result['total'] ? $result['total'] : 0;
                    ?>
                </h3>
            </div>
            <small class="font-weight-medium d-block mt-2">Total</small>
        </div>
    </div>
</div>
    </div>
    
    <div class="container-fluid">

    <!-- ORDERS ANALYSIS SECTION -->
    <div class="orders-analysis-section">
        <div class="orders-analysis-header">
            <h4>Orders Analysis</h4>
            <div class="date-filter">
                <input type="date" id="start-date" value="<?php echo $start_date; ?>">
                <span>to</span>
                <input type="date" id="end-date" value="<?php echo $end_date; ?>">
                <button id="apply-filter">Apply</button>
            </div>
        </div>

        <div class="chart-wrapper">
            <canvas id="ordersAnalysisChart"></canvas>
        </div>
    </div>

    <!-- LAST 12 MONTHS REVENUE SECTION -->
    <div class="revenue-history-section">
        <h4>Last 12 Months Revenue (PKR)</h4>
        <div class="revenue-chart-wrapper">
            <canvas id="revenueHistoryChart"></canvas>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function(){

    /* ===== ORDERS ANALYSIS CHART ===== */
    const ctx = document.getElementById('ordersAnalysisChart').getContext('2d');
    let ordersChart;

    function renderChart(data){
        if(ordersChart){
            ordersChart.destroy();
        }

        ordersChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.labels,
                datasets: [
                    { label:'Completed', data:data.completed, borderColor:'#11998E', fill:false, tension:0.3 },
                    { label:'Canceled',  data:data.canceled,  borderColor:'#8E2DE2', fill:false, tension:0.3 },
                    { label:'Partial',   data:data.partial,   borderColor:'#FF9966', fill:false, tension:0.3 },
                    { label:'Fail',      data:data.fail,      borderColor:'#CB2D3E', fill:false, tension:0.3 }
                ]
            },
            options:{
                responsive:true,
                maintainAspectRatio:false,
                plugins:{
                    legend:{ labels:{ color:'#333', font:{size:14} } }
                },
                scales:{
                    x:{ ticks:{ color:'#333' }, grid:{ color:'#eee' } },
                    y:{ ticks:{ color:'#333' }, beginAtZero:true, grid:{ color:'#eee' } }
                }
            }
        });
    }

    /* ===== INITIAL LOAD ===== */
    renderChart({
        labels: <?php echo json_encode($labels); ?>,
        completed: <?php echo json_encode($completed); ?>,
        canceled:  <?php echo json_encode($canceled); ?>,
        partial:   <?php echo json_encode($partial); ?>,
        fail:      <?php echo json_encode($fail); ?>
    });

    /* ===== FILTER BUTTON ===== */
    document.getElementById('apply-filter').addEventListener('click', function(){
        const start = document.getElementById('start-date').value;
        const end   = document.getElementById('end-date').value;

        if(!start || !end){
            alert("Select both dates");
            return;
        }

        fetch(window.location.pathname + `?start=${start}&end=${end}&ajax=1`)
        .then(res => res.json())
        .then(data => renderChart(data))
        .catch(err => console.log(err));
    });

    /* ===== LAST 12 MONTHS REVENUE BAR CHART ===== */
    const revenueLabels = <?php echo json_encode($revenue_labels); ?>;
    const revenueData   = <?php echo json_encode($revenue_data); ?>;

    const revenueCtx = document.getElementById('revenueHistoryChart').getContext('2d');

    new Chart(revenueCtx, {
        type: 'bar',
        data: {
            labels: revenueLabels,
            datasets: [{
                label: 'Revenue (PKR)',
                data: revenueData,
                backgroundColor: 'rgba(21, 101, 192, 0.75)',
                borderColor: '#1565C0',
                borderWidth: 1,
                borderRadius: 6,
                hoverBackgroundColor: 'rgba(21, 101, 192, 1)'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color: '#333', font: { size: 13 } }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const val = context.parsed.y;
                            return ' PKR ' + val.toLocaleString('en-PK', {minimumFractionDigits: 2, maximumFractionDigits: 2});
                        }
                    }
                }
            },
            scales: {
                x: {
                    ticks: { color: '#333', font: { size: 12 } },
                    grid:  { color: '#eee' }
                },
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#333',
                        font: { size: 12 },
                        callback: function(value) {
                            if(value >= 1000) return 'PKR ' + (value/1000).toFixed(0) + 'K';
                            return 'PKR ' + value;
                        }
                    },
                    grid: { color: '#eee' }
                }
            },
            onClick: function(event, elements) {
                if(elements.length > 0) {
                    const index = elements[0].index;
                    const month = revenueLabels[index];
                    const amount = revenueData[index];
                    alert('Month: ' + month + '\nRevenue: PKR ' + amount.toLocaleString('en-PK', {minimumFractionDigits: 2, maximumFractionDigits: 2}));
                }
            }
        }
    });

});
</script>

<?php include 'footer.php'; ?>