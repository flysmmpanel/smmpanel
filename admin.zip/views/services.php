<?php include 'header.php';?>

<style>
.btn-primary,.dropdown-item{cursor:pointer}
.btn-primary,.dropdown-item.ab,.dropdown-item.ab:hover{background-color:#007bff}
.btn-primary{color:#fff;border:none;padding:8.5px 20px;border-radius:1px}
.dropdown-togglel::after{content:"\25BC";margin-left:5px;font-size:10px}
.dropdown-me .dropdown-item{padding:8px 20px;color:#fff;text-decoration:none;display:block;margin:2px;border-radius:1px}
.dropdown-menu a:focus,a:hover{color:#fff;text-decoration:underline}
.dropdown-item.abc,.dropdown-item.abc:hover{background-color:#e54034}
.dropdown-item.archive-color,.dropdown-item.archive-color:hover{background-color:#f0ad4e}

/* ── Profit Badge ── */
.profit-badge {
    display:inline-block;
    font-size:10px;
    font-weight:700;
    padding:1px 5px;
    border-radius:3px;
    margin-left:4px;
    vertical-align:middle;
    white-space:nowrap;
}
.profit-badge.positive { background:#d4edda; color:#155724; }
.profit-badge.negative { background:#f8d7da; color:#721c24; }
.profit-badge.zero     { background:#fff3cd; color:#856404; }

/* ── Clean Services Toolbar ── */
.services-toolbar {
    display:flex;
    flex-wrap:wrap;
    align-items:center;
    gap:8px;
    padding:12px 0;
}
.services-toolbar .btn { margin:0; }
.services-toolbar .toolbar-search { flex:1 1 220px; max-width:320px; }
.services-toolbar .toolbar-search input {
    padding:6px 12px 6px 30px;
    background-image:url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="%23888" viewBox="0 0 16 16"><path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"/></svg>');
    background-repeat:no-repeat;
    background-position:10px center;
}
.services-toolbar .toolbar-spacer { flex:1 1 auto; }
.services-toolbar-more .dropdown-menu { min-width:260px; padding:6px 0; }
.services-toolbar-more .dropdown-menu > li > a,
.services-toolbar-more .dropdown-menu > li > div {
    padding:8px 16px;
    display:block;
    color:#333;
    cursor:pointer;
}
.services-toolbar-more .dropdown-menu > li > a:hover { background:#f5f5f5; text-decoration:none; }
.services-toolbar-more .dropdown-divider { height:1px; background:#eee; margin:4px 0; }
.services-toolbar-more .per-page-row {
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding:8px 16px;
}
.services-toolbar-more .per-page-row select { padding:2px 6px; }
.services-marquee { font-size:11px; color:#888; padding:6px 0 2px; }

/* ══════════════════════════════════════════════════════════════
   1. SOCIAL PLATFORM FILTER PILLS (ADMIN)
══════════════════════════════════════════════════════════════ */
.platform-filter-bar {
    display: flex;
    align-items: center;
    gap: 6px;
    overflow-x: auto;
    padding: 8px 2px 14px;
    margin-bottom: 8px;
    scrollbar-width: thin;
}
.platform-filter-bar::-webkit-scrollbar { height: 4px; }
.platform-filter-bar::-webkit-scrollbar-thumb { background: #cdd3e6; border-radius: 4px; }

.plat-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 14px;
    border-radius: 20px;
    background: #ffffff;
    border: 1px solid #dcdfe6;
    color: #4b5563;
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
    white-space: nowrap;
    transition: all .2s ease;
}
.plat-btn i { font-size: 13px; }
.plat-btn:hover {
    background: #eef2ff;
    border-color: #6366f1;
    color: #4338ca;
}
.plat-btn.active {
    background: #0D2F5C !important;
    border-color: #0D2F5C !important;
    color: #ffffff !important;
    box-shadow: 0 2px 8px rgba(13,47,92,0.25);
}
.plat-btn.active i { color: #fff !important; }

/* ══════════════════════════════════════════════════════════════
   2. SPREADSHEET-STYLE DOUBLE-CLICK INLINE EDITOR
══════════════════════════════════════════════════════════════ */
.editable-cell {
    display: inline-block;
    cursor: pointer;
    border-radius: 4px;
    padding: 2px 5px;
    transition: background .15s ease, box-shadow .15s ease;
}
.editable-cell:hover {
    background: #fff8e1;
    box-shadow: inset 0 0 0 1px #ffc107;
}
.editable-cell::after {
    content: " ✎";
    font-size: 9px;
    color: #9ca3af;
    opacity: 0;
    transition: opacity .15s ease;
}
.editable-cell:hover::after {
    opacity: 0.8;
}

.inline-edit-input {
    width: 100%;
    min-width: 60px;
    padding: 2px 6px;
    font-size: inherit;
    font-family: inherit;
    font-weight: inherit;
    color: #111827;
    background: #ffffff;
    border: 1.5px solid #0D2F5C !important;
    border-radius: 4px;
    box-shadow: 0 0 0 3px rgba(13,47,92,0.15);
    outline: none !important;
}

.inline-provider-select {
    background: #ffffff;
    border: 1px solid #d1d5db;
    color: #1f2937;
    font-weight: 700;
    transition: border-color .15s ease, box-shadow .15s ease;
}
.inline-provider-select:focus {
    border-color: #0D2F5C;
    box-shadow: 0 0 0 2px rgba(13,47,92,0.2);
    outline: none;
}

/* Floating Toast Notification */
.inline-toast-box {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 999999;
    display: flex;
    flex-direction: column;
    gap: 8px;
    pointer-events: none;
}
.inline-toast {
    display: flex;
    align-items: center;
    gap: 8px;
    background: #081b30;
    color: #ffffff;
    padding: 10px 18px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 700;
    box-shadow: 0 8px 24px rgba(0,0,0,0.25);
    border-left: 4px solid #28c76f;
    opacity: 0;
    transform: translateY(-10px);
    transition: all .25s cubic-bezier(0.16, 1, 0.3, 1);
}
.inline-toast.show {
    opacity: 1;
    transform: translateY(0);
}
.inline-toast.error {
    border-left-color: #ea5455;
    background: #7f1d1d;
}
</style>

<!-- Floating Live Toast Notification Container -->
<div class="inline-toast-box" id="toastContainer"></div>

<div class="container-fluid">

<!-- ══════════════════════════════════════════════════════════════
     SOCIAL PLATFORMS FILTER PILLS BAR
══════════════════════════════════════════════════════════════ -->
<div class="platform-filter-bar">
    <button class="plat-btn active" data-platform="all"><i class="fas fa-globe"></i> All Services</button>
    <button class="plat-btn" data-platform="instagram"><i class="fab fa-instagram" style="color:#E1306C;"></i> Instagram</button>
    <button class="plat-btn" data-platform="tiktok"><i class="fab fa-tiktok" style="color:#000000;"></i> TikTok</button>
    <button class="plat-btn" data-platform="youtube"><i class="fab fa-youtube" style="color:#FF0000;"></i> YouTube</button>
    <button class="plat-btn" data-platform="facebook"><i class="fab fa-facebook-f" style="color:#1877F2;"></i> Facebook</button>
    <button class="plat-btn" data-platform="telegram"><i class="fab fa-telegram-plane" style="color:#0088cc;"></i> Telegram</button>
    <button class="plat-btn" data-platform="twitter"><i class="fab fa-twitter" style="color:#1DA1F2;"></i> Twitter/X</button>
    <button class="plat-btn" data-platform="spotify"><i class="fab fa-spotify" style="color:#1DB954;"></i> Spotify</button>
    <button class="plat-btn" data-platform="snapchat"><i class="fab fa-snapchat-ghost" style="color:#FFFC00;"></i> Snapchat</button>
    <button class="plat-btn" data-platform="whatsapp"><i class="fab fa-whatsapp" style="color:#25D366;"></i> WhatsApp</button>
    <button class="plat-btn" data-platform="website"><i class="fas fa-chart-line" style="color:#6366f1;"></i> Website/SEO</button>
</div>

<div class="services-toolbar">

    <button class="btn btn-primary" data-toggle="modal" data-target="#modalDiv" data-action="new_service">
        <i class="fas fa-plus"></i> New Service
    </button>
    <button class="btn btn-default" data-toggle="modal" data-target="#modalDiv" data-action="new_subscriptions">
        New Subscription
    </button>
    <button class="btn btn-default" data-toggle="modal" data-target="#modalDiv" data-action="new_category">
        New Category
    </button>

    <div class="toolbar-spacer"></div>

    <div class="toolbar-search">
        <input class="form-control" placeholder="Search by name or ID" id="priceServices" type="text" value="">
    </div>

    <div class="dropdown services-toolbar-more">
        <button class="btn btn-default dropdown-toggle" type="button" id="moreActionsBtn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-ellipsis-v"></i> More
        </button>
        <ul class="dropdown-menu dropdown-menu-right" aria-labelledby="moreActionsBtn">

            <li><a data-toggle="modal" data-target="#modalDiv" data-action="assign_category">Assign categories</a></li>
            <li><a class="custom_method" data-title="Sync services from provider?" data-message="Are you sure? This action can't be reversed?" data-url="admin/services/sync_button_provider">Sync order status</a></li>
            <li><a data-toggle="modal" data-target="#modalDiv" data-action="sync_services">Sync Services Rate</a></li>
            <li><a data-toggle="modal" data-target="#modalDiv" data-action="ato_avg_time">Auto Average time</a></li>

            <li class="dropdown-divider"></li>

            <li><a class="custom_method" data-title="Are you want to fatch icons?" data-message="Are you sure? This action can't be reversed?" data-url="admin/services/auto_cat_icon">Auto Icon: Black Normal</a></li>
            <li><a class="custom_method" data-title="Are you want to fatch icons?" data-message="Are you sure? This action can't be reversed?" data-url="admin/services/auto_cat_icon_color">Auto Icon: Colourful</a></li>

            <li class="dropdown-divider"></li>

            <li><a class="custom_method" data-title="Rate sort by low to high?" data-message="Are you sure? This action can't be reversed?" data-url="admin/services/rate_low">Rate (low to high)</a></li>
            <li><a class="custom_method" data-title="Rate sort by high to low?" data-message="Are you sure? This action can't be reversed?" data-url="admin/services/rate_high">Rate (high to low)</a></li>

            <li class="dropdown-divider"></li>

            <li class="per-page-row">
                <span>Services per page</span>
                <select id="servicesPerPageSelect" class="form-control">
                    <option value="5"  <?php if ($to == 5)  echo 'selected'; ?>>5</option>
                    <option value="10" <?php if ($to == 10) echo 'selected'; ?>>10</option>
                    <option value="20" <?php if ($to == 20) echo 'selected'; ?>>20</option>
                    <option value="50" <?php if ($to == 50) echo 'selected'; ?>>50</option>
                    <option value="100"<?php if ($to == 100) echo 'selected'; ?>>100</option>
                </select>
            </li>

            <li class="dropdown-divider"></li>

            <li><a href="<?= site_url('admin/archived-services') ?>"><i class="fas fa-archive"></i> Archived Services</a></li>
            <li><a href="<?= site_url('admin/api-services') ?>"><i class="fas fa-plus-circle"></i> Import Services</a></li>

            <li class="dropdown-divider"></li>

            <li><a class="custom_method abc" data-title="Remove all empty categories?" data-message="Are you sure? This action can't be reversed?" data-url="admin/services/delete_all_empty_cat">Delete empty categories</a></li>
            <li><a class="custom_method abc" data-title="Remove all categories?" data-message="Are you sure? This action can't be reversed?" data-url="admin/services/delete_all_cat">Delete All categories</a></li>

        </ul>
    </div>

</div>

<div class="services-marquee">💡 <b>PRO TIP:</b> Change Provider directly via Dropdown! Double-click Name, Price, Min, Max, or API ID to edit instantly without reload!</div>

    <ul></ul>
    <div class="services-table">
        <div class="sticker-head">
            <table class="service-block__header" id="sticker">
                <thead>
<th class="checkAll-th service-block__checker null">
    <div class="checkAll-holder">
        <input type="checkbox" id="checkAll">
        <input type="hidden" id="checkAllText" value="order">
    </div>
    <div class="action-block">
        <ul class="action-list">
            <li><span class="countOrders"></span> Services Selected</li>
            <li>
                <div class="dropdown">
<button type="button" class="btn btn-default btn-xs dropdown-toggle btn-xs-caret" data-toggle="dropdown">batch operations<span class="caret"></span></button>
<ul class="dropdown-menu">
    <li>
        <a class="bulkorder" data-type="active">Enable Selected Services</a>
        <a class="bulkorder" data-type="deactive">Disable Selected Services</a>
        <a class="bulkorder" data-type="secret">Make Selected Services Secret</a>
        <a class="dcs-pointer assign-category" data-toggle="modal" data-target="#modalDiv" data-action="assign_categoryc" data-id="<?= implode(',', array_column($services, 'service_id')) ?>" >Assign category</a>
        <a class="bulkorder" data-type="desecret">Remove Selected from Secret Services</a>
        <a class="bulkorder" data-type="del_price">Delete Selected Services Custom Pricing</a>
        <a class="bulkorder" data-type="del_service">Delete Selected Services</a>
        <a class="bulkorder" data-type="archive-services" style="background:#f0ad4e;color:#fff;display:block;padding:5px 10px;border-radius:3px;margin:2px 0;cursor:pointer;">
            <i class="fas fa-archive"></i> Archive Selected Services
        </a>
        <a class="bulkorder" data-type="refill-active">Refill Enable Selected Services</a>
        <a class="bulkorder" data-type="refill-inactive">Refill Disable Selected Services</a>
        <a class="bulkorder" data-type="cancel-active">Cancel Enable Selected Services</a>
        <a class="bulkorder" data-type="cancel-inactive">Cancel Disable Selected Services</a>
    </li>
</ul>
                </div>
            </li>
        </ul>
    </div>
</th>
<th class="service-block__id">ID</th>
<th class="service-block__service">Service (Double-Click Name)</th>
<th>Service Type</th>
<th class="service-block__minorder">Refill</th>
<th class="service-block__minorder">Cancel</th>
<th class="service-block__provider" style="min-width: 140px;">
    <div class="dropdown">
        <button class="btn btn-th btn-default dropdown-toggle" data-active="<?=$_GET["id"]?>" type="button" id="serviceList" data-href="admin/orders/provider" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Provider <span class="caret"></span>
        </button>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenu1" id="serviceListContent" style="max-height: 275px; overflow:hidden; overflow-y: scroll"></ul>
    </div>
</th>
<th class="service-block__rate">Price ✎</th>
<th class="service-block__minorder">Min ✎</th>
<th class="service-block__minorder">Max ✎</th>
<th class="service-block__visibility">
    <div class="dropdown">
<button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true"> Status <span style="margin-left:8px;"class="caret"></span></button>
<ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
<li class="<?php if( !$_GET["getstatus"] ): echo "active"; endif; ?>"><a href="<?= site_url("admin/services") ?>">All (<?php echo countRow(["table"=>"services","where"=>["service_deleted"=>0]]) ?>)</a></li>
<li class="<?php if( $_GET["getstatus"] == "2" ): echo "active"; endif; ?>"><a href="<?= site_url("admin/services") ?>?getstatus=2">Enabled (<?php echo countRow(["table"=>"services","where"=>["service_deleted"=>0, "service_type"=>2]]) ?>)</a></li>
<li class="<?php if( $_GET["getstatus"] == "1" ): echo "active"; endif; ?>"><a href="<?= site_url("admin/services") ?>?getstatus=1">Disabled (<?php echo countRow(["table"=>"services","where"=>["service_deleted"=>0, "service_type"=>1]]) ?>)</a></li>
</ul></div>
</th>
<th class="service-block__action text-right"><span id="allServices" class="service-block__hide-all fa fa-compress"></span></th>
                </tr>
            </thead>
        </table>
    </div>

    <div class="service-block__body">
        <div class="service-block__body-scroll">
            <div style="width: 100%; height: 0px;"></div>

<form action="<?php echo site_url("admin/services/multi-action") ?>" method="post" id="changebulkForm">
<div style="" class="category-sortable">
<?php $c = 0; foreach ($serviceList as $category => $services): $c++; ?>
<div class="categories" data-id="<?=$services[0]["category_id"] ?>">
    <div class="<?php if ($services[0]["category_type"] == 1): echo 'grey'; endif; ?>  service-block__category ">
        <div class="service-block__category-title" class="categorySortable" data-category="<?=$category ?>" id="category-<?=$c ?>">
            <div class="service-block__drag handle">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><title>Drag-Handle</title><path d="M7 2c-1.104 0-2 .896-2 2s.896 2 2 2 2-.896 2-2-.896-2-2-2zm0 6c-1.104 0-2 .896-2 2s.896 2 2 2 2-.896 2-2-.896-2-2-2zm0 6c-1.104 0-2 .896-2 2s.896 2 2 2 2-.896 2-2-.896-2-2-2zm6-8c1.104 0 2-.896 2-2s-.896-2-2-2-2 .896-2 2 .896 2 2 2zm0 2c-1.104 0-2 .896-2 2s.896 2 2 2 2-.896 2-2-.896-2-2-2zm0 6c-1.104 0-2 .896-2 2s.896 2 2 2 2-.896 2-2-.896-2-2-2z"></path></svg>
            </div>
<?php if ($services[0]["category_secret"] == 1): echo '<small data-toggle="tooltip" data-placement="top" title="" data-original-title="gizli kategori"><i class="fa fa-lock"></i></small> '; endif; 

if($services[0]["category_type"] == 2){
echo '<span data-post="category_id='.$services[0]["category_id"].'" class="category-visibility category-visible"></span>';
} 
if($services[0]["category_type"] == 1){
echo '<span data-post="category_id='.$services[0]["category_id"].'" class="category-visibility category-invisible"></span>';
} 

$category_icon_array = json_decode($services[0]["category_icon"],true);
$category_icon_type = $category_icon_array["icon_type"];
if($category_icon_type == "image"){
$icon = "<img style=\"margin-right:10px;\" src=\"".$images[$category_icon_array["image_id"]][0]["link"]."\" class=\"img-responsive btn-group-vertical\">";
} elseif($category_icon_type == "icon"){
$icon = "<i style=\"margin-right:10px;font-size:18px;\" class=\"".$category_icon_array["icon_class"]."\" aria-hidden=\"true\"></i>";
} else {
    $icon = "";
}
echo '<span class="category-name">'.$icon.$category.'</span>'; ?>
<span style="margin-left:10px;margin-right:10px;font-weight:bold;">|</span>
<div class="dropdown-inline">
    <div class="dropdown btn-group">
        <button style="padding:3px 10px;" type="button" class="btn btn-default btn-xs dropdown-toggle btn-xs-caret" data-toggle="dropdown">Options <span class="caret"></span></button>
        <ul class="dropdown-menu">
            <li><a class="dcs-pointer" data-toggle="modal" data-target="#modalDiv" data-action="edit_category" data-id="<?= $services[0]["category_id"] ?>">Edit</a></li>
            <?php if ($services[0]["category_type"] == 1) : $type = "category-active";
            else : $type = "category-deactive";
            endif; ?>
            <li><a href="<?php echo site_url("admin/services/" . $type . "/" . $services[0]["category_id"]) ?>"><?php if ($services[0]["category_type"] == 1) : echo "Enable"; else : echo "Disable"; endif; ?></a></li>
            <li><a class="custom_method" data-title="Delete all services from category?" data-message="Are you sure want to delete all services from <?= $category ?>" data-url="<?= site_url("admin/services/del_category_services/" . $services[0]["category_id"]) ?>" data-action="del_category">Delete Services</a></li>
            <li><a  id="selectservices" data-id=" <?= $services[0]["category_id"] ?> " >Select Services</a></li>
            <li><a href="<?php echo site_url("admin/services/del_category/".$services[0]["category_id"]) ?>" data-action="del_category">Delete Category</a></li>
            <li><a class="custom_method" data-title="Sort this category?" data-message="Are you sure want to sort the category <?= $category ?> by price in ascending order" data-url="<?= site_url("admin/services/sort_by_price_asc/" . $services[0]["category_id"]) ?>" data-action="sort_by_price_asc" data-id=" <?= $services[0]["category_id"] ?> ">Sort by Price (Ascending)</a></li>
            <li><a class="custom_method" data-title="Sort this category?" data-message="Are you sure want to sort the category <?= $category ?> by price in descending order" data-url="<?= site_url("admin/services/sort_by_price_desc/" . $services[0]["category_id"]) ?>" data-action="sort_by_price_desc" data-id=" <?= $services[0]["category_id"] ?> ">Sort by Price (Descending)</a></li>
        </ul>
    </div>
</div>
<?php if (!empty($services[0]["service_id"])): ?>
    <div class="service-block__collapse-block">
        <div id="collapedAdd-<?=$c ?>" class="service-block__collapse-button" data-category="category-<?=$c ?>"></div>
    </div>
<?php endif; ?>
        </div>
        <div class="collapse in">
            <div class="service-block__packages">
                <table id="servicesTableList" class="Servicecategory-<?=$c ?>">
<tbody class="service-sortable">
    <div class="serviceSortable" id="Servicecategory-<?=$c ?>" data-id="category-<?=$c ?>">
        <?php for ($i = 0; $i < count($services); $i++): 
      if($services[$i]["service_deleted"] == 0):
        $api_detail = json_decode($services[$i]["api_detail"], true);
        
        // ── Profit % Calculation ──────────────────────────────────────────────
        $profit_html = '';
        if($services[$i]["service_api"] != 0 && !empty($api_detail["rate"])):
            $api_cost_converted = from_to(get_currencies_array("all"), $services[$i]["currency"], $settings["site_base_currency"], $api_detail["rate"]);
            if($api_cost_converted > 0):
                $profit_pct = (($services[$i]["service_price"] - $api_cost_converted) / $api_cost_converted) * 100;
                $profit_rounded = round($profit_pct, 1);
                if($profit_rounded > 0):
                    $profit_html = '<span class="profit-badge positive">+'.number_format($profit_rounded,1).'%</span>';
                elseif($profit_rounded < 0):
                    $profit_html = '<span class="profit-badge negative">'.number_format($profit_rounded,1).'%</span>';
                else:
                    $profit_html = '<span class="profit-badge zero">0%</span>';
                endif;
            endif;
        endif;
        ?>
        <tr id="serviceshowcategory-<?=$c ?>" class="ui-state-default <?php if ($services[$i]["service_type"] == 1): echo "grey"; endif; ?>" data-category="category-<?=$c ?>" data-id="service-<?php echo $services[$i]["service_id"] ?>" data-service="<?php echo $services[$i]["service_name"] ?>">
<?php if (!empty($services[0]["service_id"])): ?>
<td class="service-block__checker">
<?php if ($services[$i]["api_servicetype"] == 1): echo '<div class="service-block__danger"></div>'; endif; ?>
<span></span>
<div class="service-block__checkbox">
    <div class="service-block__drag handle">
        <svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><title>Drag-Handle</title><path d="M7 2c-1.104 0-2 .896-2 2s.896 2 2 2 2-.896 2-2-.896-2-2-2zm0 6c-1.104 0-2 .896-2 2s.896 2 2 2 2-.896 2-2-.896-2-2-2zm0 6c-1.104 0-2 .896-2 2s.896 2 2 2 2-.896 2-2-.896-2-2-2zm6-8c1.104 0 2-.896 2-2s-.896-2-2-2-2 .896-2 2 .896 2 2 2zm0 2c-1.104 0-2 .896-2 2s.896 2 2 2 2-.896 2-2-.896-2-2-2zm0 6c-1.104 0-2 .896-2 2s.896 2 2 2 2-.896 2-2-.896-2-2-2z"></path></svg></svg>
    </div>
    <input type="checkbox" class="selectOrder" name="service[<?php echo $services[$i]["service_id"] ?>]" value="1" style="border:1px solid #fff">
</div>
</td>

<td class="service-block__id"><?php echo $services[$i]["service_id"] ?></td>

<!-- Double-Click Editable Service Name -->
<td class="service-block__service">
    <?php if ($services[$i]["service_secret"] == 1): echo '<small data-toggle="tooltip" data-placement="top" title="" data-original-title="Secret Service"><i class="fa fa-lock"></i></small> '; endif; ?>
    <span class="editable-cell" data-id="<?php echo $services[$i]["service_id"] ?>" data-field="service_name" title="Double-click to edit name"><?php echo $services[$i]["service_name"]; ?></span>
</td>

<td width="10%"><?php echo servicePackageType($services[$i]["service_package"]); ?><?php if ($services[$i]["time"] != "Not enough data"): ?><div class="tooltip5">&nbsp;<i class="fas fa-clock"></i><span class="tooltiptext5"><?php echo $services[$i]["time"]; ?> </span></div><?php endif; ?><?php if ($services[$i]["show_refill"] == "true"): echo '<div class="tooltip5">&nbsp;<i class="fas fa-sync"></i></span><span class="tooltiptext5">Refill Button Enabled</span></div>'; endif; ?><?php if ($services[$i]["cancelbutton"] == 1): echo '<div class="tooltip5">&nbsp;<i class="fas fa-ban"></i></span><span class="tooltiptext5">Cancel Button Enabled</span></div>'; endif; ?></td>

<?php if ($services[$i]["show_refill"] == "true"): $type = "refill-deactive"; else : $type = "refill-active"; endif; ?>
<td class="service-block__minorder"><a href="<?php echo site_url("admin/services/".$type."/".$services[$i]["service_id"]) ?>"> <?php if ($services[$i]["show_refill"] == "false"): echo "Off"; else : echo "On"; endif; ?></a></td>

<?php if ($services[$i]["cancelbutton"] == 2): $type = "cancelbutton-active"; else : $type = "cancelbutton-deactive"; endif; ?>
<td class="service-block__minorder"><a href="<?php echo site_url("admin/services/".$type."/".$services[$i]["service_id"]) ?>"> <?php if ($services[$i]["cancelbutton"] == "2"): echo "Off"; else : echo "On"; endif; ?></a></td>

<!-- ── LIVE INLINE PROVIDER DROPDOWN & DOUBLE-CLICK API ID ── -->
<td class="service-block__provider" style="min-width: 140px;">
    <!-- Inline Provider Select Dropdown (Zero Reload AJAX) -->
    <select class="form-control input-sm inline-provider-select" data-id="<?php echo $services[$i]["service_id"] ?>" style="height:28px;padding:2px 6px;font-size:11.5px;font-weight:700;border-radius:4px;margin-bottom:4px;cursor:pointer;">
        <option value="0" <?php if($services[$i]["service_api"] == 0) echo 'selected'; ?>>Manual</option>
        <?php if(!empty($providersList)): foreach($providersList as $pItem): ?>
            <option value="<?php echo $pItem["id"] ?>" <?php if($services[$i]["service_api"] == $pItem["id"]) echo 'selected'; ?>>
                <?php echo htmlspecialchars($pItem["api_name"]) ?> (<?php echo $pItem["currency"] ?>)
            </option>
        <?php endforeach; endif; ?>
    </select>

    <!-- Double-Click Manual Provider Service ID -->
    <div style="font-size:11px;">
        <span class="text-muted" style="font-size:10px;">API ID: </span>
        <span class="editable-cell label label-api" data-id="<?php echo $services[$i]["service_id"] ?>" data-field="api_service" title="Double-click to edit Provider Service ID" style="cursor:pointer;font-size:11px;padding:2px 6px;">
            <?php echo !empty($services[$i]["api_service"]) ? $services[$i]["api_service"] : "0"; ?>
        </span>
    </div>
</td>

<!-- Double-Click Editable Price -->
<td class="service-block__rate">
<?php $api_price = $api_detail["rate"]; ?>
<div style="width:100px;<?php if (!$api_detail["rate"]): echo "Empty"; elseif ($services[$i]["service_api"] != 0 && from_to(get_currencies_array("all"), $settings["site_base_currency"], "INR", $services[$i]["service_price"]) > from_to(get_currencies_array("enabled"), $services[$i]["currency"], "INR", $api_price)): echo "color: #38E54D;"; elseif ($services[$i]["service_api"] != 0 && from_to(get_currencies_array("all"), $settings["site_base_currency"], "INR", $services[$i]["service_price"]) < from_to(get_currencies_array("all"), $services[$i]["currency"], "INR", $api_price)): echo "color: #D2001A;"; elseif($services[$i]["service_api"] != 0 && from_to(get_currencies_array("all"), $settings["site_base_currency"], "INR", $services[$i]["service_price"]) == from_to(get_currencies_array("all"), $services[$i]["currency"], "INR", $api_price)): echo "color: #FFB200;"; endif;?>">
    <span class="editable-cell" data-id="<?php echo $services[$i]["service_id"] ?>" data-field="service_price" title="Double-click to edit price">
        <?php echo $services[$i]["service_price"]; ?>
    </span>
    <?= $profit_html ?>
</div>
<div class="service-block__provider-value">
    <?php if ($services[$i]["service_api"] != 0 && $api_detail["rate"]):
    if ($settings["site_base_currency"] !== $services[$i]["currency"]) {
        echo "≈ ".format_amount_string($settings["site_base_currency"], from_to(get_currencies_array("all"), $services[$i]["currency"], $settings["site_base_currency"], $api_detail["rate"]));
    } elseif ($settings["site_base_currency"] == $services[$i]["currency"]) {
        echo format_amount_string($settings["site_base_currency"], from_to(get_currencies_array("all"), $services[$i]["currency"], $settings["site_base_currency"], $api_detail["rate"]));
    }
    endif; ?>
</div>
</td>

<!-- Double-Click Editable Min -->
<td class="service-block__minorder">
    <div>
        <span class="editable-cell" data-id="<?php echo $services[$i]["service_id"] ?>" data-field="service_min" title="Double-click to edit min"><?php echo $services[$i]["service_min"] ?></span>
    </div>
    <?php if ($services[$i]["service_api"] != 0): echo '<div class="service-block__provider-value">'.$api_detail["min"].'</div>'; endif; ?>
</td>

<!-- Double-Click Editable Max -->
<td class="service-block__minorder">
    <div>
        <span class="editable-cell" data-id="<?php echo $services[$i]["service_id"] ?>" data-field="service_max" title="Double-click to edit max"><?php echo $services[$i]["service_max"] ?></span>
    </div>
    <?php if ($services[$i]["service_api"] != 0): echo '<div class="service-block__provider-value">'.$api_detail["max"].'</div>'; endif; ?>
</td>

<td class="service-block__visibility"><?php if ($services[$i]["service_type"] == 1): echo "Disabled"; else : echo "Enabled"; endif; ?> <?php if ($services[$i]["api_servicetype"] == 1): echo '<span class="text-danger" title="Service provider removed service"><span class="fa fa-exclamation-circle"></span></span>'; endif; ?></td>

<td class="service-block__action">
<div class="dropdown pull-right">
    <button type="button" class="btn btn-default btn-xs dropdown-toggle btn-xs-caret" data-toggle="dropdown">Options <span class="caret"></span></button>
    <ul class="dropdown-menu">
        <li><a style="cursor:pointer;" data-toggle="modal" data-target="#modalDiv" data-action="edit_service" data-id="<?=$services[$i]["service_id"] ?>">Edit Service</a></li>
        <li><a style="cursor:pointer;" data-toggle="modal" data-target="#modalDiv" data-action="edit_service_name" data-id="<?=$services[$i]["service_id"] ?>">Edit Service Name</a></li>
        <li><a style="cursor:pointer;" data-toggle="modal" data-target="#modalDiv" data-action="edit_description" data-id="<?=$services[$i]["service_id"] ?>">Edit Description</a></li>
        <li><a style="cursor:pointer;" data-toggle="modal" data-target="#modalDiv" data-action="edit_time" data-id="<?=$services[$i]["service_id"] ?>">Edit Average Time</a></li>
        <?php if ($services[$i]["service_type"] == 1): $type = "service-active"; else : $type = "service-deactive"; endif; ?>
        <li><a href="<?php echo site_url("admin/services/".$type."/".$services[$i]["service_id"]) ?>">Service <?php if ($services[$i]["service_type"] == 1): echo "Activate"; else : echo "Deactivate"; endif; ?></a></li>
        <?php if ($services[$i]["show_refill"] == "true"): $type = "refill-deactive"; else : $type = "refill-active"; endif; ?>
        <li><a href="<?php echo site_url("admin/services/".$type."/".$services[$i]["service_id"]) ?>">Refill <?php if ($services[$i]["show_refill"] == "true"): echo "Deactivate"; else : echo "Activate"; endif; ?></a></li>
        <?php if ($services[$i]["cancelbutton"] == 2): $type = "cancelbutton-active"; else : $type = "cancelbutton-deactive"; endif; ?>
        <li><a href="<?php echo site_url("admin/services/".$type."/".$services[$i]["service_id"]) ?>">Cancel Button <?php if ($services[$i]["cancelbutton"] == 1): echo "Deactivate"; else : echo "Activate"; endif; ?></a></li>
        <li><a href="<?php echo site_url("admin/services/archive/".$services[$i]["service_id"]) ?>" style="color:#f0ad4e;font-weight:600;" onclick="return confirm('Archive this service? You can restore it from Archived Services page.')"><i class="fas fa-archive"></i> Archive Service</a></li>
        <li><a href="<?php echo site_url("admin/services/delete/".$services[$i]["service_id"]) ?>">Delete Service</a></li>
    </ul>
</div>
</td>
<?php endif; ?>
        </tr>
        <?php 
        endif;
        endfor; ?>
    </div>
</tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>

<?php
$services = $conn->prepare("SELECT * FROM services LEFT JOIN service_api ON service_api.id = services.service_api WHERE services.category_id=:c_id AND (services.archived IS NULL OR services.archived=0) ORDER BY services.service_line ASC ");
$services -> execute(array("c_id" => 0));
$services = $services->fetchAll(PDO::FETCH_ASSOC);
if ($services):
?>
<div class="service-block__category ">
    <div class="service-block__category-title" class="categorySortable" data-category="notcategory" id="category-0">
        Uncategorized
        <div class="service-block__collapse-block">
            <div id="collapedAdd-0" class="service-block__collapse-button" data-category="category-0"></div>
        </div>
    </div>
    <div class="collapse in">
        <div class="service-block__packages">
            <table id="servicesTableList" class="Servicecategory-0">
                <tbody class="service-sortable">
<div class="serviceSortable" id="Servicecategory-0" data-id="category-0">
    <?php foreach ($services as $service): $api_detail = json_decode($service["api_detail"], true); ?>
    <tr id="serviceshowcategory-0" class="ui-state-default <?php if ($service["service_type"] == 1): echo "grey"; endif; ?>" data-category="category-0" data-id="service-<?php echo $service["service_id"] ?>" data-service="<?php echo mb_convert_encoding($service["service_name"], "UTF-8", "UTF-8") ?>">
        <td class="service-block__checker">
<span></span>
<div class="service-block__checkbox">
<div class="service-block__drag handle">
    <svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><title>Drag-Handle</title><path d="M7 2c-1.104 0-2 .896-2 2s.896 2 2 2 2-.896 2-2-.896-2-2-2zm0 6c-1.104 0-2 .896-2 2s.896 2 2 2 2-.896 2-2-.896-2-2-2zm0 6c-1.104 0-2 .896-2 2s.896 2 2 2 2-.896 2-2-.896-2-2-2zm6-8c1.104 0 2-.896 2-2s-.896-2-2-2-2 .896-2 2 .896 2 2 2zm0 2c-1.104 0-2 .896-2 2s.896 2 2 2 2-.896 2-2-.896-2-2-2zm0 6c-1.104 0-2 .896-2 2s.896 2 2 2 2-.896 2-2-.896-2-2-2z"></path></svg></svg>
</div>
<input type="checkbox" class="selectOrder" name="service[<?php echo $service["service_id"] ?>]" value="1" style="border:1px solid #fff">
</div>
        </td>
        <td class="service-block__id"><?php echo $service["service_id"] ?></td>
        <td class="service-block__service">
            <?php if (mb_convert_encoding($service["service_secret"], "UTF-8", "UTF-8") == 1): echo '<small data-toggle="tooltip" data-placement="top" title="" data-original-title="Secret service"><i class="fa fa-lock"></i></small> '; endif; ?>
            <span class="editable-cell" data-id="<?php echo $service["service_id"] ?>" data-field="service_name"><?php echo mb_convert_encoding($service["service_name"], "UTF-8", "UTF-8"); ?></span>
        </td>
        <td class="service-block__type" nowrap=""><?php echo servicePackageType($service["service_package"]); ?></td>
        <td class="service-block__provider" style="min-width: 140px;">
            <select class="form-control input-sm inline-provider-select" data-id="<?php echo $service["service_id"] ?>" style="height:28px;padding:2px 6px;font-size:11.5px;font-weight:700;border-radius:4px;margin-bottom:4px;cursor:pointer;">
                <option value="0" <?php if($service["service_api"] == 0) echo 'selected'; ?>>Manual</option>
                <?php if(!empty($providersList)): foreach($providersList as $pItem): ?>
                    <option value="<?php echo $pItem["id"] ?>" <?php if($service["service_api"] == $pItem["id"]) echo 'selected'; ?>>
                        <?php echo htmlspecialchars($pItem["api_name"]) ?> (<?php echo $pItem["currency"] ?>)
                    </option>
                <?php endforeach; endif; ?>
            </select>
            <div style="font-size:11px;">
                <span class="text-muted" style="font-size:10px;">API ID: </span>
                <span class="editable-cell label label-api" data-id="<?php echo $service["service_id"] ?>" data-field="api_service" title="Double-click to edit Provider Service ID" style="cursor:pointer;font-size:11px;padding:2px 6px;">
                    <?php echo !empty($service["api_service"]) ? $service["api_service"] : "0"; ?>
                </span>
            </div>
        </td>
        <td class="service-block__rate">
            <span class="editable-cell" data-id="<?php echo $service["service_id"] ?>" data-field="service_price"><?php echo $service["service_price"] ?></span>
        </td>
        <td class="service-block__minorder">
            <span class="editable-cell" data-id="<?php echo $service["service_id"] ?>" data-field="service_min"><?php echo $service["service_min"] ?></span>
        </td>
        <td class="service-block__minorder">
            <span class="editable-cell" data-id="<?php echo $service["service_id"] ?>" data-field="service_max"><?php echo $service["service_max"] ?></span>
        </td>
        <td class="service-block__visibility"><?php if ($service["service_type"] == 1): echo "Deactive"; else : echo "Active"; endif; ?></td>
        <td class="service-block__action">
<div class="dropdown pull-right">
<button type="button" class="btn btn-default btn-xs dropdown-toggle btn-xs-caret" data-toggle="dropdown">Options <span class="caret"></span></button>
<ul class="dropdown-menu">
    <li><a style="cursor:pointer;" data-toggle="modal" data-target="#modalDiv" data-action="edit_service" data-id="<?=$service["service_id"] ?>">Edit Service</a></li>
    <li><a style="cursor:pointer;" data-toggle="modal" data-target="#modalDiv" data-action="edit_description" data-id="<?=$service["service_id"] ?>">Edit Description</a></li>
    <?php if ($service["service_type"] == 1): $type = "service-active"; else : $type = "service-deactive"; endif; ?>
    <li><a href="<?php echo site_url("admin/services/".$type."/".$service["service_id"]) ?>">Service <?php if ($service["service_type"] == 1): echo "Enable"; else : echo "Disable"; endif; ?></a></li>
    <li><a href="<?php echo site_url("admin/services/del_price/".$service["service_id"]) ?>">Delete Price</a></li>
    <li><a href="<?php echo site_url("admin/services/archive/".$service["service_id"]) ?>" style="color:#f0ad4e;font-weight:600;" onclick="return confirm('Archive this service?')"><i class="fas fa-archive"></i> Archive Service</a></li>
    <li><a href="<?php echo site_url("admin/services/delete/".$service["service_id"]) ?>">Delete Service</a></li>
</ul>
</div>
        </td>
    </tr>
    <?php endforeach; ?>
</div>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>
</div>

<input type="hidden" name="bulkStatus" id="bulkStatus" value="-1">
            </form>
        </div>
    </div>
    
</div>

<?php if( $paginationArr["count"] > 1 ): ?>
     <div class="row">
        <div class="col-sm-8">
  <nav>
 <ul class="pagination">
 <?php if( $paginationArr["current"] != 1 ): ?>
  <li class="prev"><a href="<?php echo site_url("admin/services/1".$search_link) ?>">&laquo;</a></li>
  <li class="prev"><a href="<?php echo site_url("admin/services/".$paginationArr["previous"].$search_link) ?>">&lsaquo;</a></li>
  <?php endif;
      for ($page=1; $page<=$pageCount; $page++):
        if( $page >= ($paginationArr['current']-9) and $page <= ($paginationArr['current']+9) ):
  ?>
  <li class="<?php if( $page == $paginationArr["current"] ): echo "active"; endif; ?> "><a href="<?php echo site_url("admin/services/".$page.$search_link) ?>"><?=$page?></a></li>
  <?php endif; endfor;
        if( $paginationArr["current"] != $paginationArr["count"] ):
  ?>
  <li class="next"><a href="<?php echo site_url("admin/services/".$paginationArr["next"].$search_link) ?>" data-page="1">&rsaquo;</a></li>
  <li class="next"><a href="<?php echo site_url("admin/services/".$paginationArr["count"].$search_link) ?>" data-page="1">&raquo;</a></li> 
  <?php endif; ?>
 </ul>
  </nav>
        </div>
     </div>
   <?php endif; ?>

    <div class="modal modal-center fade" id="confirmChange" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static">
        <div class="modal-dialog modal-dialog-center" role="document">
            <div class="modal-content">
                <div class="modal-body text-center">
<h4>Are you sure you want to update the status?</h4>
<div align="center">
    <a class="btn btn-primary" href="" id="confirmYes">Yes</a>
    <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
</div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'footer.php'; ?>

<!-- ══════════════════════════════════════════════════════════════
     LIVE SPREADSHEET-STYLE DOUBLE-CLICK & DROPDOWN INLINE AJAX SCRIPT
══════════════════════════════════════════════════════════════ -->
<script>
$(document).ready(function() {

    // ── Toast Notification ───────────────────────────────────────────────────
    function showToast(msg, isError) {
        var toast = $('<div class="inline-toast' + (isError ? ' error' : '') + '">' +
            '<i class="' + (isError ? 'fas fa-exclamation-circle' : 'fas fa-check-circle') + '"></i> ' +
            '<span>' + msg + '</span>' +
            '</div>');
        $('#toastContainer').append(toast);
        setTimeout(function() { toast.addClass('show'); }, 50);
        setTimeout(function() {
            toast.removeClass('show');
            setTimeout(function() { toast.remove(); }, 300);
        }, 2600);
    }

    // ── 1. Inline Provider Dropdown Change (Zero Reload AJAX) ────────────────
    $(document).on('change', '.inline-provider-select', function() {
        var select = $(this);
        var serviceId = select.attr('data-id');
        var newProviderId = select.val();
        var providerName = select.find('option:selected').text().trim();

        $.ajax({
            url: '<?= site_url("admin/services/inline-edit") ?>',
            type: 'POST',
            dataType: 'json',
            data: {
                service_id: serviceId,
                field: 'service_api',
                value: newProviderId
            },
            success: function(res) {
                if (res && res.success) {
                    showToast('Provider changed to: ' + providerName + ' ✅', false);
                } else {
                    showToast(res.message || 'Update failed! ❌', true);
                }
            },
            error: function() {
                showToast('Server connection error! ❌', true);
            }
        });
    });

    // ── 2. Double-Click to Edit Handler (Name, Price, Min, Max, API ID) ──────
    $(document).on('dblclick', '.editable-cell', function() {
        var cell = $(this);
        if (cell.find('input').length > 0) return;

        var currentVal = cell.text().trim();
        var serviceId  = cell.attr('data-id');
        var fieldName  = cell.attr('data-field');

        var input = $('<input type="text" class="inline-edit-input" value="' + currentVal.replace(/"/g, '&quot;') + '">');
        cell.html(input);
        input.focus().select();

        function saveInline() {
            var newVal = input.val().trim();
            if (newVal === currentVal) {
                cell.text(currentVal);
                return;
            }

            $.ajax({
                url: '<?= site_url("admin/services/inline-edit") ?>',
                type: 'POST',
                dataType: 'json',
                data: {
                    service_id: serviceId,
                    field: fieldName,
                    value: newVal
                },
                success: function(res) {
                    if (res && res.success) {
                        cell.text(newVal);
                        var cleanFieldName = fieldName.replace('service_', '').replace('api_', 'API ').toUpperCase();
                        showToast(cleanFieldName + ' updated to: ' + newVal + ' ✅', false);
                    } else {
                        cell.text(currentVal);
                        showToast(res.message || 'Update failed! ❌', true);
                    }
                },
                error: function() {
                    cell.text(currentVal);
                    showToast('Server connection error! ❌', true);
                }
            });
        }

        input.on('blur', function() {
            saveInline();
        });

        input.on('keydown', function(e) {
            if (e.which === 13) {
                e.preventDefault();
                input.off('blur');
                saveInline();
            } else if (e.which === 27) {
                e.preventDefault();
                input.off('blur');
                cell.text(currentVal);
            }
        });
    });

    // ── 3. Search Filter ─────────────────────────────────────────────────────
    $("#priceServices").on("keyup", function () {
        var q = $(this).val().toUpperCase().trim();
        $('[data-id^="service-"]').each(function () {
            var serviceId = $(this).find(".service-block__id").text().toUpperCase().trim();
            var serviceName = ($(this).attr("data-service") || "").toUpperCase();
            var categoryKey = $(this).attr("data-category");
            var match = (q === "") || serviceId.indexOf(q) > -1 || serviceName.indexOf(q) > -1;
            if (match) {
                $(this).show().attr("id", "serviceshow" + categoryKey);
            } else {
                $(this).hide().attr("id", "servicehide");
            }
        });
        $('[id^="Servicecategory-"]').each(function () {
            var catId = $(this).attr("data-id");
            if ($("#servicesTableList > tbody > tr#serviceshow" + catId).length === 0) {
                $("#" + catId).hide();
            } else {
                $("#" + catId).show();
            }
        });
    });

    // ── 4. Social Platform Tab Filter ─────────────────────────────────────────
    $(".plat-btn").on("click", function () {
        $(".plat-btn").removeClass("active");
        $(this).addClass("active");
        var plat = $(this).attr("data-platform").toLowerCase();

        if (plat === "all") {
            $(".categories").show();
            $('[data-id^="service-"]').show();
        } else {
            $(".categories").each(function () {
                var catTitle = $(this).find(".service-block__category-title").text().toLowerCase();
                if (catTitle.indexOf(plat) > -1) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        }
    });

    // ── 5. Per page select redirects ──────────────────────────────────────────
    $("#servicesPerPageSelect").on("change", function () {
        window.location.href = "<?= site_url('admin/services') ?>?getservices=" + $(this).val();
    });

    // ── 6. Assign category AJAX ───────────────────────────────────────────────
    $('.assign-category').click(function() {
        var selectedCheckboxes = $('input.selectOrder:checked');
        var selectedServiceIds = [];
        selectedCheckboxes.each(function() {
            var name = $(this).attr('name');
            var serviceId = name.match(/\[(\d+)\]/)[1]; 
            selectedServiceIds.push(serviceId);
        });
        $.ajax({
            url: 'ajax_data.php', type: 'POST',
            data: { service_ids: selectedServiceIds },
            success: function(response) {},
            error: function(xhr, status, error) {}
        });
    });

    // ── 7. Cancel only 1 order at a time ──────────────────────────────────────
    function checkCancelButton() {
        var checkedCount = $('input.selectOrder:checked').length;
        $('a.bulkorder[data-type="cancel-active"], a.bulkorder[data-type="cancel-inactive"]').each(function(){
            if(checkedCount > 1){
                $(this).addClass('disabled-bulk-cancel').css({
                    'opacity':'0.4',
                    'cursor':'not-allowed',
                    'pointer-events':'none'
                }).attr('title','You can only cancel 1 service at a time');
            } else {
                $(this).removeClass('disabled-bulk-cancel').css({
                    'opacity':'',
                    'cursor':'pointer',
                    'pointer-events':''
                }).removeAttr('title');
            }
        });
    }

    $('input.selectOrder, #checkAll').on('change', function(){
        checkCancelButton();
    });

    checkCancelButton();
});
</script>

<script>
$("#selectservices").click(function () {
    $('.selectOrder').not(this).prop('checked', true);
   var count = $('.selectOrder').filter(':checked').length;
   $('.countOrders').html(count);
   if( count > 0 ){
     $('.checkAll-th').addClass("show-action-menu");
   }else{
     $('.checkAll-th').removeClass("show-action-menu");
   }
});
</script>