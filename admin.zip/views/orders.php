<?php include 'header.php'; ?>
<style>
.orders-table {
  overflow-y: scroll;
  width: 100%;
}

/* === Status badges === */
.status-badge {
  padding: 4px 10px;
  border-radius: 20px;
  color: #fff;
  font-size: 11px;
  font-weight: 600;
  display: inline-block;
  white-space: nowrap;
  text-transform: uppercase;
  letter-spacing: 0.3px;
}
.status-pending     { background-color: #f59e0b; }
.status-inprogress  { background-color: #3b82f6; }
.status-processing  { background-color: #6366f1; }
.status-completed   { background-color: #22c55e; }
.status-partial     { background-color: #f97316; }
.status-canceled    { background-color: #ef4444; }
.status-fail        { background-color: #7f1d1d; }
.status-cronpending { background-color: #6b7280; }

/* === Row BG by status === */
tr.row-pending     { background-color: rgba(245,158,11,0.06) !important; }
tr.row-inprogress  { background-color: rgba(59,130,246,0.06) !important; }
tr.row-processing  { background-color: rgba(99,102,241,0.06) !important; }
tr.row-completed   { background-color: rgba(34,197,94,0.06) !important; }
tr.row-partial     { background-color: rgba(249,115,22,0.06) !important; }
tr.row-canceled    { background-color: rgba(239,68,68,0.06) !important; }
tr.row-fail        { background-color: rgba(127,29,29,0.06) !important; }
tr.row-cronpending { background-color: rgba(107,114,128,0.06) !important; }

/* === Left border by status === */
tr.row-pending     td:first-child { border-left: 3px solid #f59e0b; }
tr.row-inprogress  td:first-child { border-left: 3px solid #3b82f6; }
tr.row-processing  td:first-child { border-left: 3px solid #6366f1; }
tr.row-completed   td:first-child { border-left: 3px solid #22c55e; }
tr.row-partial     td:first-child { border-left: 3px solid #f97316; }
tr.row-canceled    td:first-child { border-left: 3px solid #ef4444; }
tr.row-fail        td:first-child { border-left: 3px solid #7f1d1d; }
tr.row-cronpending td:first-child { border-left: 3px solid #6b7280; }

/* === Time ago === */
.time-ago {
  display: block;
  font-size: 11px;
  color: #888;
  margin-top: 3px;
  white-space: nowrap;
}

/* === Cancel limit alert === */
#cancelLimitAlert { display: none; }

/* === Disabled bulk cancel button === */
.disabled-bulk {
  opacity: 0.4;
  pointer-events: none;
  cursor: not-allowed;
}
</style>

<div class="container-fluid">
  <?php if($success): ?>
    <div class="alert alert-success"><?php echo $successText; ?></div>
  <?php endif; ?>
  <?php if($error): ?>
    <div class="alert alert-danger"><?php echo $errorText; ?></div>
  <?php endif; ?>
  <div class="alert alert-danger" id="cancelLimitAlert">You can only cancel one order at a time.</div>

  <ul class="nav nav-tabs p-b">
    <li class="<?php if($status == "all"): echo "active"; endif; ?>"><a href="<?=site_url("admin/orders")?>">All Orders <span class="badge" style="background-color:#808080"><?php echo countRow(["table"=>"orders"]) ?></span></a></li>
    <li class="<?php if($status == "cronpending"): echo "active"; endif; ?>"><a href="<?=site_url("admin/orders/1/cronpending")?>">Awaiting <span class="badge" style="background-color:#808080"><?php if($cronpendingcount): echo $cronpendingcount; endif; ?></span></a></li>
    <li class="<?php if($status == "pending"): echo "active"; endif; ?>"><a href="<?=site_url("admin/orders/1/pending")?>">Pending <span class="badge" style="background-color:#f59e0b"><?php if($pendingcount): echo $pendingcount; endif; ?></span></a></li>
    <li class="<?php if($status == "processing"): echo "active"; endif; ?>"><a href="<?=site_url("admin/orders/1/processing")?>">Processing <span class="badge" style="background-color:#6366f1"><?php if($processingcount): echo $processingcount; endif; ?></span></a></li>
    <li class="<?php if($status == "inprogress"): echo "active"; endif; ?>"><a href="<?=site_url("admin/orders/1/inprogress")?>">Inprogress <span class="badge" style="background-color:#3b82f6"><?php if($inprogresscount): echo $inprogresscount; endif; ?></span></a></li>
    <li class="<?php if($status == "completed"): echo "active"; endif; ?>"><a href="<?=site_url("admin/orders/1/completed")?>">Completed <span class="badge" style="background-color:#22c55e"><?php if($completedcount): echo $completedcount; endif; ?></span></a></li>
    <li class="<?php if($status == "partial"): echo "active"; endif; ?>"><a href="<?=site_url("admin/orders/1/partial")?>">Partial <span class="badge" style="background-color:#f97316"><?php if($partialcount): echo $partialcount; endif; ?></span></a></li>
    <li class="<?php if($status == "canceled"): echo "active"; endif; ?>"><a href="<?=site_url("admin/orders/1/canceled")?>">Canceled <span class="badge" style="background-color:#ef4444"><?php if($canceledcount): echo $canceledcount; endif; ?></span></a></li>
    <li class="<?php if($status == "fail"): echo "active"; endif; ?>"><a href="<?=site_url("admin/orders/1/fail")?>">Fail <span class="badge" style="background-color:#7f1d1d"><?php if($failCount): echo $failCount; endif; ?></span></a></li>

    <li class="pull-right custom-search">
      <form class="form-inline" action="<?=site_url("admin/orders")?>" method="get">
        <div class="input-group">
          <input type="text" name="search" class="form-control" value="<?=$search_word?>" placeholder="Search (e.g. 303, 302, 118)">
          <span class="input-group-btn search-select-wrap">
            <select class="form-control search-select" name="search_type">
              <option value="order_id"    <?php if($search_where == "order_id"):    echo 'selected'; endif; ?>>Order ID</option>
              <option value="order_url"   <?php if($search_where == "order_url"):   echo 'selected'; endif; ?>>Order URL</option>
              <option value="username"    <?php if($search_where == "username"):    echo 'selected'; endif; ?>>Username</option>
              <option value="api_orderid" <?php if($search_where == "api_orderid"): echo 'selected'; endif; ?>>Provider Order ID</option>
            </select>
            <button type="submit" class="btn btn-default"><span class="fa fa-search" aria-hidden="true"></span></button>
          </span>
        </div>
      </form>
    </li>
  </ul>

  <div class="orders-table">
    <table class="table" id="dt">
      <thead>
        <tr>
          <th class="checkAll-th">
            <div class="checkAll-holder">
              <input type="checkbox" id="checkAll">
              <input type="hidden" id="checkAllText" value="order">
            </div>
            <div class="action-block">
              <ul class="action-list">
                <li><span class="countOrders"></span> Orders Selected</li>
                <li>
                  <div class="dropdown">
                    <button type="button" class="btn btn-default btn-xs dropdown-toggle btn-xs-caret" data-toggle="dropdown">Bulk Actions <span class="caret"></span></button>
                    <ul class="dropdown-menu">
                      <li>
                        <?php if($status == "fail"): ?>
                          <a class="bulkorder" data-type="resend">Resend</a>
                        <?php endif; ?>
                        <a class="bulkorder" data-type="pending">Pending</a>
                        <a class="bulkorder" data-type="inprogress">In Progress</a>
                        <a class="bulkorder" data-type="completed">Completed</a>
                        <a class="bulkorder" data-type="canceled" onclick="return handleCancelClick(event, this)">Cancel & Refund</a>
                        <a href="#" id="copyProviderIds">Copy Providers Order IDz</a>
                      </li>
                    </ul>
                  </div>
                </li>
              </ul>
            </div>
          </th>
          <th class="p-l">ID</th>
          <th>User</th>
          <th>Charge</th>
          <th>Profit</th>
          <th class="service-block__service">Link</th>
          <th>Seller</th>
          <th>Start</th>
          <th>Final Count</th>
          <th>Quantity</th>
          <th class="dropdown-th">
            <div class="dropdown">
              <button class="btn btn-th btn-default dropdown-toggle" data-active="<?=$_GET["service_id"]?>" type="button" id="serviceList" data-href="admin/orders/counter" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Service <span class="caret"></span>
              </button>
              <ul class="dropdown-menu" aria-labelledby="dropdownMenu1" id="serviceListContent" style="max-height:275px;overflow:hidden;overflow-y:scroll"></ul>
            </div>
          </th>
          <th>Status</th>
          <th>Remains</th>
          <th width="10%">Date</th>
          <th width="5%" class="dropdown-th">
            <div class="dropdown">
              <button class="btn btn-th btn-default dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Mode <span class="caret"></span>
              </button>
              <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                <li class="<?php if(!$_GET["mode"]): echo "active"; endif; ?>"><a href="<?=site_url("admin/orders/1/".$status)?>">All</a></li>
                <li class="<?php if($_GET["mode"] == "manuel"): echo "active"; endif; ?>"><a href="<?=site_url("admin/orders/1/".$status)?>?mode=manuel">Manual</a></li>
                <li class="<?php if($_GET["mode"] == "auto"): echo "active"; endif; ?>"><a href="<?=site_url("admin/orders/1/".$status)?>?mode=auto">API</a></li>
              </ul>
            </div>
          </th>
          <th></th>
        </tr>
      </thead>

      <form id="changebulkForm" action="<?php echo site_url("admin/orders/multi-action") ?>" method="post">
        <tbody>
          <?php foreach($orders as $order):
            $st = $order["order_status"];
            if($order["order_error"] != "-") $st = "fail";
            if($order["order_detail"] == "cronpending") $st = "cronpending";
            $rowClass = "row-" . $st;

            // ── Time ago ──
            $orderTime = strtotime($order["order_create"]);
            $diff      = time() - $orderTime;
            if ($diff < 60)           $timeAgo = $diff . "s ago";
            elseif ($diff < 3600)     $timeAgo = floor($diff/60) . "m ago";
            elseif ($diff < 86400)    $timeAgo = floor($diff/3600) . "h ago";
            elseif ($diff < 2592000)  $timeAgo = floor($diff/86400) . "d ago";
            elseif ($diff < 31536000) $timeAgo = floor($diff/2592000) . "mo ago";
            else                      $timeAgo = floor($diff/31536000) . "y ago";

            // ── Final Count ──
            $finalCount = intval($order["order_start"]) + intval($order["order_quantity"]);
          ?>
          <tr class="<?php echo $rowClass; ?>">
            <td><input type="checkbox" class="selectOrder" name="order[<?php echo $order["order_id"] ?>]" value="1" data-api-orderid="<?php echo $order["api_orderid"]; ?>" style="border:1px solid #fff"></td>
            <td class="p-l">
              <?php echo $order["order_id"] ?>
              <?php if($order["api_orderid"] != 0): echo '<div class="label label-api">'.$order["api_orderid"].'</div>'; endif; ?>
            </td>
            <td><?php echo $order["username"]; if($order["order_where"] == "api"): echo ' <span class="label label-api">API</span>'; endif; ?></td>
            <td class="service-block__minorder">
              <div style="width:85px;">
                <?php echo format_amount_string($settings["site_base_currency"], $order["order_charge"]); ?>
                <?php if($order["service_api"] != 0): echo '<div class="service-block__provider-value">'.format_amount_string($settings["site_base_currency"], $order["api_charge"]).'</div>'; endif; ?>
              </div>
            </td>
            <td>
              <div style="width:85px;"><?php echo format_amount_string($settings["site_base_currency"], $order["order_profit"]); ?></div>
            </td>
            <td class="service-block__service">
              <?php echo $order["order_url"];
              if(!empty($order["order_extras"]) && $order["order_extras"] != "[]"){
                echo ' <a href="#" class="btn btn-default btn-xs" data-toggle="modal" data-target="#modalDiv" data-action="order_comment" data-id="'.$order["order_id"].'">Yorumlar</a>';
              } ?>
              <a href="https://href.li/<?php echo $order["order_url"]; ?>" class="order-link" target="_blank">
                <span class="fa fa-external-link"></span>
              </a>
            </td>
            <td><?php echo GET_API_NAME_BY_ID($order["order_api"]); ?></td>
            <td><?php echo $order["order_start"]; ?></td>
            <td><?php echo $finalCount; ?></td>
            <td><?php echo $order["order_quantity"]; ?></td>
            <td width="30%"><span class="label-id"><?php echo $order["service_id"]; ?></span><?php echo $order["service_name"]; ?></td>
            <td>
              <?php
                $stClass = "status-" . $order["order_status"];
                if($order["order_error"] != "-") $stClass = "status-fail";
                if($order["order_detail"] == "cronpending") $stClass = "status-cronpending";
                echo '<span class="status-badge '.$stClass.'">'.orderStatu($order["order_status"], $order["order_error"], $order["order_detail"]).'</span>';
              ?>
            </td>
            <td><?php if($order["order_status"] == "completed" && substr($order["order_remains"], 0, 1) == "-"): echo "+".substr($order["order_remains"], 1); else: echo $order["order_remains"]; endif; ?></td>
            <td width="10%">
              <?php echo $order["order_create"]; ?>
              <span class="time-ago">⏱ <?php echo $timeAgo; ?></span>
            </td>
            <td width="5%"><?php if($order["api_service"] == 0): echo "Manual"; else: echo "Auto"; endif; ?></td>
            <td class="service-block__action">
              <div class="dropdown pull-right">
                <button type="button" class="btn btn-default btn-xs dropdown-toggle btn-xs-caret" data-toggle="dropdown">Options <span class="caret"></span></button>
                <ul class="dropdown-menu">
                  <?php if($order["order_error"] != "-" && $order["service_api"] != 0): ?>
                    <li><a href="#" data-toggle="modal" data-target="#modalDiv" data-action="order_errors" data-id="<?php echo $order["order_id"] ?>">Order Errors</a></li>
                    <li><a href="<?=site_url("admin/orders/order_resend/".$order["order_id"])?>">Resend Order</a></li>
                  <?php endif; ?>
                  <?php if($order["order_error"] == "-" && $order["service_api"] != 0): ?>
                    <li><a href="#" data-toggle="modal" data-target="#modalDiv" data-action="order_details" data-id="<?php echo $order["order_id"] ?>">Order Details</a></li>
                  <?php endif; ?>
                  <?php if($order["service_api"] == 0 || $order["order_error"] != "-"): ?>
                    <li><a href="#" data-toggle="modal" data-target="#modalDiv" data-action="order_orderurl" data-id="<?php echo $order["order_id"] ?>">Edit Order URL</a></li>
                  <?php endif; ?>
                  <li><a href="#" data-toggle="modal" data-target="#modalDiv" data-action="order_startcount" data-id="<?php echo $order["order_id"] ?>">Edit Start Count</a></li>
                  <?php if($order["order_status"] != "partial"): ?>
                    <li><a href="#" data-toggle="modal" data-target="#modalDiv" data-action="order_partial" data-id="<?php echo $order["order_id"] ?>">Mark Partial</a></li>
                  <?php endif; ?>
                  <?php if($order["refill"] == "0" || $order["refill"] == "2" || $order["status_order"] == "Completed"): ?>
                    <li><a href="#" data-toggle="modal" data-target="#confirmChange" data-href="<?=site_url("admin/orders/order_refill_activate/".$order["order_id"])?>">Activate Refill Button</a></li>
                  <?php endif; ?>
                  <li class="dropdown dropdown-submenu">
                    <a href="#" class="dropdown_menu">Update Order Status</a>
                    <ul class="dropdown-menu submenu_drop">
                      <?php if(in_array($order["order_status"], ["pending","completed","processing","partial","fail"])): ?>
                        <li><a href="#" data-toggle="modal" data-target="#confirmChange" data-href="<?=site_url("admin/orders/order_cancel/".$order["order_id"])?>">Cancel & Refund</a></li>
                      <?php endif; ?>
                      <?php if(in_array($order["order_status"], ["pending","inprogress","processing"])): ?>
                        <li><a href="#" data-toggle="modal" data-target="#confirmChange" data-href="<?=site_url("admin/orders/order_complete/".$order["order_id"])?>">Complete</a></li>
                      <?php endif; ?>
                      <?php if(in_array($order["order_status"], ["pending","processing"])): ?>
                        <li><a href="#" data-toggle="modal" data-target="#confirmChange" data-href="<?=site_url("admin/orders/order_inprogress/".$order["order_id"])?>">In Progress</a></li>
                      <?php endif; ?>
                    </ul>
                  </li>
                </ul>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
        <input type="hidden" name="bulkStatus" id="bulkStatus" value="0">
      </form>
    </table>
  </div>

  <?php if($paginationArr["count"] > 1): ?>
  <div class="row">
    <div class="col-sm-8">
      <nav>
        <ul class="pagination">
          <?php if($paginationArr["current"] != 1): ?>
            <li class="prev"><a href="<?php echo site_url("admin/orders/1/".$status.$search_link) ?>">&laquo;</a></li>
            <li class="prev"><a href="<?php echo site_url("admin/orders/".$paginationArr["previous"]."/".$status.$search_link) ?>">&lsaquo;</a></li>
          <?php endif;
          for ($page=1; $page<=$pageCount; $page++):
            if($page >= ($paginationArr['current']-9) and $page <= ($paginationArr['current']+9)): ?>
              <li class="<?php if($page == $paginationArr["current"]): echo "active"; endif; ?>">
                <a href="<?php echo site_url("admin/orders/".$page."/".$status.$search_link) ?>"><?=$page?></a>
              </li>
          <?php endif; endfor;
          if($paginationArr["current"] != $paginationArr["count"]): ?>
            <li class="next"><a href="<?php echo site_url("admin/orders/".$paginationArr["next"]."/".$status.$search_link) ?>" data-page="1">&rsaquo;</a></li>
            <li class="next"><a href="<?php echo site_url("admin/orders/".$paginationArr["count"]."/".$status.$search_link) ?>" data-page="1">&raquo;</a></li>
          <?php endif; ?>
        </ul>
      </nav>
    </div>
    <div class="col-sm-4 pagination-counters">
      <?php echo $count; ?> from within the order <?php echo $where+1 ?>'den <?php if($where+$to > $count): echo $count; else: echo $where+$to; endif; ?>'up to
    </div>
  </div>
  <?php endif; ?>
</div>

<div class="modal modal-center fade" id="confirmChange" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-backdrop="static">
  <div class="modal-dialog modal-dialog-center" role="document">
    <div class="modal-content">
      <div class="modal-body text-center">
        <h4>Are you sure you want to update the status?</h4>
        <div align="center">
          <a class="btn btn-primary" href="" id="confirmYes">Yes</a>
          <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
function handleCancelClick(e, el){
  var checkedCount = document.querySelectorAll('.selectOrder:checked').length;
  if(checkedCount > 1){
    e.preventDefault();
    e.stopImmediatePropagation();
    e.stopPropagation();
    showCancelLimitAlert();
    return false;
  }
  return true;
}

function showCancelLimitAlert(){
  var alertBox = document.getElementById('cancelLimitAlert');
  alertBox.style.display = 'block';
  alertBox.scrollIntoView({ behavior:'smooth', block:'center' });
  clearTimeout(window.__cancelAlertTimeout);
  window.__cancelAlertTimeout = setTimeout(function(){ alertBox.style.display = 'none'; }, 4000);
}

function updateCancelButtonState(){
  var checkedCount = document.querySelectorAll('.selectOrder:checked').length;
  var cancelBtn = document.querySelector('.bulkorder[data-type="canceled"]');
  if(cancelBtn){
    if(checkedCount > 1) cancelBtn.classList.add('disabled-bulk');
    else cancelBtn.classList.remove('disabled-bulk');
  }
}

document.addEventListener('DOMContentLoaded', function(){
  updateCancelButtonState();

  var ordersTable = document.querySelector('.orders-table');
  if(ordersTable) ordersTable.addEventListener('click', function(){ setTimeout(updateCancelButtonState, 50); });

  var checkAll = document.getElementById('checkAll');
  if(checkAll) checkAll.addEventListener('click', function(){ setTimeout(updateCancelButtonState, 50); });

  var copyBtn = document.getElementById('copyProviderIds');
  if(copyBtn){
    copyBtn.addEventListener('click', function(e){
      e.preventDefault();
      var checked = document.querySelectorAll('.selectOrder:checked');
      if(checked.length === 0){ alert("Please select at least one order first."); return; }
      var ids = [];
      checked.forEach(function(cb){
        var apiId = cb.getAttribute('data-api-orderid');
        if(apiId && apiId !== "0" && apiId !== "") ids.push(apiId);
      });
      if(ids.length === 0){ alert("No provider order IDs found for the selected orders."); return; }
      var text = ids.join(", ");
      if(navigator.clipboard && navigator.clipboard.writeText){
        navigator.clipboard.writeText(text).then(function(){
          var orig = copyBtn.textContent;
          copyBtn.textContent = "Copied!";
          setTimeout(function(){ copyBtn.textContent = orig; }, 1500);
        }).catch(function(){ fallbackCopy(text); });
      } else { fallbackCopy(text); }
    });
  }
});

function fallbackCopy(text){
  var temp = document.createElement('textarea');
  temp.value = text;
  document.body.appendChild(temp);
  temp.select();
  document.execCommand('copy');
  document.body.removeChild(temp);
  alert("Copied: " + text);
}
</script>

<?php include 'footer.php'; ?>