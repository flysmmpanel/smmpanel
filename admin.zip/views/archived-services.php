
<?php include 'header.php'; ?>

<style>
/* ── Archived Services Page Styles ───────────────────────────────────────── */
.archived-badge {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 700;
    background: #f0ad4e;
    color: #fff;
    margin-left: 6px;
}
.archived-date {
    font-size: 11px;
    color: #888;
    white-space: nowrap;
}
.btn-restore {
    background: #28a745;
    color: #fff !important;
    border: none;
    padding: 4px 10px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    display: inline-block;
}
.btn-restore:hover {
    background: #218838;
    color: #fff !important;
}
.btn-perm-delete {
    background: #dc3545;
    color: #fff !important;
    border: none;
    padding: 4px 10px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    display: inline-block;
    margin-left: 4px;
}
.btn-perm-delete:hover {
    background: #c82333;
    color: #fff !important;
}
.archived-search-bar {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 16px;
    flex-wrap: wrap;
}
.archived-search-bar input[type="text"] {
    padding: 6px 12px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 13px;
    min-width: 240px;
}
.archived-search-bar button {
    padding: 6px 16px;
    background: #007bff;
    color: #fff;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 13px;
}
.archived-search-bar button:hover {
    background: #0056b3;
}
.archived-header-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    margin-bottom: 14px;
    gap: 10px;
}
.archived-header-row h4 {
    margin: 0;
    font-size: 18px;
    font-weight: 700;
}
.archived-empty {
    text-align: center;
    padding: 60px 20px;
    color: #888;
    font-size: 15px;
}
.archived-empty i {
    font-size: 48px;
    display: block;
    margin-bottom: 14px;
    color: #ccc;
}
#archivedBulkBar {
    display: none;
    background: #f8f9fa;
    border: 1px solid #dee2e6;
    border-radius: 4px;
    padding: 8px 14px;
    margin-bottom: 10px;
    align-items: center;
    gap: 12px;
}
#archivedBulkBar.active {
    display: flex;
}
</style>

<div class="container-fluid">

    <?php if(!empty($success)): ?>
        <div class="alert alert-success alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <?= htmlspecialchars($successText) ?>
        </div>
    <?php endif; ?>
    <?php if(!empty($error)): ?>
        <div class="alert alert-danger alert-dismissible">
            <button type="button" class="close" data-dismiss="alert">&times;</button>
            <?= htmlspecialchars($errorText) ?>
        </div>
    <?php endif; ?>

    <div class="archived-header-row">
        <h4>
            <i class="fas fa-archive" style="color:#f0ad4e;margin-right:8px;"></i>
            Archived Services
            <span class="archived-badge"><?= $totalCount ?> Total</span>
        </h4>
        <a href="<?= site_url('admin/services') ?>" class="btn btn-default btn-sm">
            <i class="bi bi-arrow-left"></i> Back to Services
        </a>
    </div>

    <!-- Search -->
    <form method="GET" action="" class="archived-search-bar">
        <input type="text" name="search" placeholder="Search archived services..." value="<?= htmlspecialchars($search) ?>">
        <button type="submit"><i class="fa fa-search"></i> Search</button>
        <?php if(!empty($search)): ?>
            <a href="<?= site_url('admin/archived-services') ?>" class="btn btn-default btn-sm">Clear</a>
        <?php endif; ?>
    </form>

    <?php if(!empty($archivedServices)): ?>

    <!-- Bulk Restore Form -->
    <form id="archiveBulkForm" action="<?= site_url('admin/archived-services/bulk-restore') ?>" method="POST">
        
        <!-- Bulk Bar -->
        <div id="archivedBulkBar">
            <span id="archivedSelectedCount" style="font-weight:600;">0 selected</span>
            <button type="submit" class="btn-restore" onclick="return confirm('Restore all selected services?')">
                <i class="fas fa-undo"></i> Restore Selected
            </button>
            <a href="#" onclick="document.getElementById('archiveCheckAll').checked=false; updateArchivedBulkBar(); return false;" style="color:#888;font-size:12px;">Clear selection</a>
        </div>

        <div class="services-table">
            <div class="service-block__body">
                <table class="table table-bordered table-hover" style="background:#fff;">
                    <thead>
                        <tr>
                            <th style="width:36px;">
                                <input type="checkbox" id="archiveCheckAll" title="Select All">
                            </th>
                            <th>ID</th>
                            <th>Service Name</th>
                            <th>Category</th>
                            <th>Type</th>
                            <th>Provider</th>
                            <th>Price</th>
                            <th>Status</th>
                            <th>Archived On</th>
                            <th class="text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($archivedServices as $svc): ?>
                        <tr>
                            <td>
                                <input type="checkbox" class="archiveSelectRow" name="service[<?= $svc['service_id'] ?>]" value="1">
                            </td>
                            <td><?= (int)$svc['service_id'] ?></td>
                            <td>
                                <?php if($svc['service_secret'] == 1): ?>
                                    <small title="Secret Service"><i class="fa fa-lock"></i></small>
                                <?php endif; ?>
                                <?= htmlspecialchars($svc['service_name']) ?>
                            </td>
                            <td><?= htmlspecialchars($svc['category_name'] ?? '—') ?></td>
                            <td><?= servicePackageType($svc['service_package']) ?></td>
                            <td>
                                <?php if($svc['service_api'] != 0 && !empty($svc['api_name'])): ?>
                                    <?= htmlspecialchars($svc['api_name']) ?>
                                    <span class="label label-default" style="font-size:10px;"><?= htmlspecialchars($svc['currency'] ?? '') ?></span>
                                <?php else: ?>
                                    Manual
                                <?php endif; ?>
                            </td>
                            <td><?= format_amount_string($settings['site_base_currency'], $svc['service_price']) ?></td>
                            <td>
                                <?php if($svc['service_type'] == 1): ?>
                                    <span class="label label-danger">Disabled</span>
                                <?php else: ?>
                                    <span class="label label-success">Enabled</span>
                                <?php endif; ?>
                            </td>
                            <td class="archived-date">
                                <?= !empty($svc['archived_at']) ? date('d M Y, H:i', strtotime($svc['archived_at'])) : '—' ?>
                            </td>
                            <td class="text-right" style="white-space:nowrap;">
                                <a href="<?= site_url('admin/archived-services/restore/'.$svc['service_id']) ?>"
                                   class="btn-restore"
                                   onclick="return confirm('Restore service: <?= addslashes(htmlspecialchars($svc['service_name'])) ?>?')">
                                    <i class="fas fa-undo"></i> Restore
                                </a>
                                <a href="<?= site_url('admin/archived-services/permanent-delete/'.$svc['service_id']) ?>"
                                   class="btn-perm-delete"
                                   onclick="return confirm('PERMANENTLY DELETE this service? This cannot be undone.')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </form><!-- end bulk form -->

    <?php else: ?>
        <div class="archived-empty">
            <i class="fas fa-archive"></i>
            <?php if(!empty($search)): ?>
                No archived services found matching "<strong><?= htmlspecialchars($search) ?></strong>".
            <?php else: ?>
                No archived services. Archive services from the <a href="<?= site_url('admin/services') ?>">Manage Services</a> page.
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <!-- Pagination -->
    <?php if($paginationArr['count'] > 1): ?>
    <div class="row">
        <div class="col-sm-8">
            <nav>
                <ul class="pagination">
                    <?php if($paginationArr['current'] != 1): ?>
                        <li><a href="<?= site_url('admin/archived-services/1') ?><?= !empty($search) ? '?search='.urlencode($search) : '' ?>">&laquo;</a></li>
                        <li><a href="<?= site_url('admin/archived-services/'.$paginationArr['previous']) ?><?= !empty($search) ? '?search='.urlencode($search) : '' ?>">&lsaquo;</a></li>
                    <?php endif; ?>
                    <?php for($pg = 1; $pg <= $pageCount; $pg++): ?>
                        <?php if($pg >= ($paginationArr['current'] - 9) && $pg <= ($paginationArr['current'] + 9)): ?>
                        <li class="<?= ($pg == $paginationArr['current']) ? 'active' : '' ?>">
                            <a href="<?= site_url('admin/archived-services/'.$pg) ?><?= !empty($search) ? '?search='.urlencode($search) : '' ?>"><?= $pg ?></a>
                        </li>
                        <?php endif; ?>
                    <?php endfor; ?>
                    <?php if($paginationArr['current'] != $paginationArr['count']): ?>
                        <li><a href="<?= site_url('admin/archived-services/'.$paginationArr['next']) ?><?= !empty($search) ? '?search='.urlencode($search) : '' ?>">&rsaquo;</a></li>
                        <li><a href="<?= site_url('admin/archived-services/'.$paginationArr['count']) ?><?= !empty($search) ? '?search='.urlencode($search) : '' ?>">&raquo;</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </div>
    <?php endif; ?>

</div><!-- end container-fluid -->

<script>
// ── Bulk selection logic ──────────────────────────────────────────────────────
function updateArchivedBulkBar() {
    var checked = document.querySelectorAll('.archiveSelectRow:checked');
    var bar = document.getElementById('archivedBulkBar');
    var count = document.getElementById('archivedSelectedCount');
    if(checked.length > 0){
        bar.classList.add('active');
        count.textContent = checked.length + ' selected';
    } else {
        bar.classList.remove('active');
    }
}

document.getElementById('archiveCheckAll') && document.getElementById('archiveCheckAll').addEventListener('change', function(){
    var boxes = document.querySelectorAll('.archiveSelectRow');
    boxes.forEach(function(box){ box.checked = this.checked; }.bind(this));
    updateArchivedBulkBar();
});

document.querySelectorAll('.archiveSelectRow').forEach(function(box){
    box.addEventListener('change', updateArchivedBulkBar);
});
</script>

<?php include 'footer.php'; ?>
