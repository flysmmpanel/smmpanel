<?php
if(!defined("BASEPATH")){
    die("Direct access not permitted");
}

// Page title for Insights
$data["page_title"] = "Insights Dashboard";

// Load the insights view (stacked bar chart)
require admin_view("insights");
