<?php
if(!defined('BASEPATH')) {
   die('Direct access to the script is not allowed');
}

if ($admin["access"]["update-prices"] != 1):
header("Location:" . site_url("admin"));
exit();
endif;

$currencies_array = get_currencies_array("all");

// ==============================
// GET CATEGORIES
// ==============================
$categories = $conn->prepare("SELECT * FROM categories");
$categories->execute();
$categories = $categories->fetchAll(PDO::FETCH_ASSOC);

// ==============================
// GET SERVICES
// ==============================
$services = $conn->prepare("
SELECT 
    services.*, 
    service_api.provider_name, 
    service_api.api_name
FROM services
LEFT JOIN service_api 
ON service_api.id = services.service_api
");
$services->execute();
$services = $services->fetchAll(PDO::FETCH_ASSOC);


// ==============================
// POST LOGIC
// ==============================
if($_POST){

$category_ids = $_POST["category_ids"];
$service_ids  = $_POST["service_ids"];
$profit_percent = $_POST["profit_percent"];
$action_type = $_POST["action_type"];

// VALIDATION
if(empty($profit_percent) || !is_numeric($profit_percent)){
    error_exit("Invalid profit value.");
}

if(empty($action_type)){
    error_exit("Select action type.");
}

// ==============================
// BUILD QUERY
// ==============================
$query = "SELECT * FROM services WHERE 1=1";

// CATEGORY FILTER
if(!in_array("all", $category_ids)){
    $cat_ids = implode(",", array_map('intval', $category_ids));
    $query .= " AND category_id IN ($cat_ids)";
}

// SERVICE FILTER
if(!in_array("all", $service_ids)){
    $srv_ids = implode(",", array_map('intval', $service_ids));
    $query .= " AND service_id IN ($srv_ids)";
}

$stmt = $conn->prepare($query);
$stmt->execute();
$filtered_services = $stmt->fetchAll(PDO::FETCH_ASSOC);

if(!count($filtered_services)){
    error_exit("No services found.");
}

// ==============================
// UPDATE LOOP
// ==============================
foreach($filtered_services as $service){

$service_id = $service["service_id"];
$old_profit_percent = $service["price_profit"];
$service_api_detail = $service["api_detail"];

if(!empty($service_api_detail)){
    $api = json_decode($service_api_detail,true);
    $api_price = $api["rate"];
    $currency = $api["currency"];

    $base_price = from_to($currencies_array,$currency,$settings["site_base_currency"],$api_price);
} else {
    $base_price = $service["service_price"];
}

// ACTION LOGIC
if($action_type == "set_profit"){
    $new_profit = $profit_percent;
}
if($action_type == "increase_profit"){
    $new_profit = $old_profit_percent + $profit_percent;
}
if($action_type == "decrease_profit"){
    $new_profit = $old_profit_percent - $profit_percent;
}

// FINAL PRICE
$new_price = $base_price + ($base_price * ($new_profit/100));

// UPDATE
$update = $conn->prepare("UPDATE services SET service_price=:price, price_profit=:profit WHERE service_id=:id");
$update->execute([
    "price" => $new_price,
    "profit" => $new_profit,
    "id" => $service_id
]);

}

success_response_exit("Prices updated successfully 🚀");

}

require admin_view("price-update");