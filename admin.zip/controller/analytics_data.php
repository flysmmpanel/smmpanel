<?php
if(!defined("BASEPATH")){
    die("Direct access not permitted");
}

header('Content-Type: application/json');

$start = $_GET["start"] ?? date("Y-m-d", strtotime("-6 days"));
$end   = $_GET["end"] ?? date("Y-m-d");

// --- Orders Data ---
$orderQuery = $conn->prepare("
    SELECT 
        DATE(order_create) as date,
        SUM(order_status='completed') as completed,
        SUM(order_status='canceled') as canceled,
        SUM(order_status='partial') as partial
    FROM orders
    WHERE DATE(order_create) BETWEEN ? AND ?
    GROUP BY DATE(order_create)
");
$orderQuery->execute([$start, $end]);
$orderResults = $orderQuery->fetchAll(PDO::FETCH_ASSOC);

$labels = [];
$completed = [];
$canceled = [];
$partial = [];

$period = new DatePeriod(
    new DateTime($start),
    new DateInterval('P1D'),
    (new DateTime($end))->modify('+1 day')
);

foreach ($period as $dateObj) {
    $date = $dateObj->format("Y-m-d");
    $labels[] = $date;

    $found = false;
    foreach($orderResults as $row){
        if($row["date"] == $date){
            $completed[] = (int)$row["completed"];
            $canceled[]  = (int)$row["canceled"];
            $partial[]   = (int)$row["partial"];
            $found = true;
            break;
        }
    }

    if(!$found){
        $completed[] = 0;
        $canceled[]  = 0;
        $partial[]   = 0;
    }
}

// --- Funds Data (Added / Deducted) ---
$fundQuery = $conn->prepare("
    SELECT 
        DATE(payment_create_date) as date,
        SUM(CASE WHEN payment_amount > 0 THEN payment_amount ELSE 0 END) AS added,
        SUM(CASE WHEN payment_amount < 0 THEN payment_amount ELSE 0 END) AS deducted
    FROM payments
    WHERE payment_status = 3
      AND DATE(payment_create_date) BETWEEN ? AND ?
    GROUP BY DATE(payment_create_date)
");
$fundQuery->execute([$start, $end]);
$fundResults = $fundQuery->fetchAll(PDO::FETCH_ASSOC);

$addedFunds = [];
$deductedFunds = [];
$netFunds = [];

foreach ($period as $dateObj) {

    $date = $dateObj->format("Y-m-d");
    $found = false;

    foreach($fundResults as $row){
        if($row["date"] == $date){

            $added    = (float)$row["added"];
            $deducted = (float)$row["deducted"];

            $addedFunds[]    = $added;
            $deductedFunds[] = $deducted;

            // net per day
            $netFunds[] = $added + $deducted;

            $found = true;
            break;
        }
    }

    if(!$found){
        $addedFunds[]    = 0;
        $deductedFunds[] = 0;
        $netFunds[]      = 0;
    }
}

// ===============================
// --- CLIENTS DATA ---
// ===============================

$clientQuery = $conn->prepare("
    SELECT 
        DATE(register_date) as date,
        COUNT(*) as total_clients
    FROM clients
    WHERE DATE(register_date) BETWEEN ? AND ?
    GROUP BY DATE(register_date)
");
$clientQuery->execute([$start, $end]);
$clientResults = $clientQuery->fetchAll(PDO::FETCH_ASSOC);

$clientsData = [];

foreach ($period as $dateObj) {

    $date = $dateObj->format("Y-m-d");
    $found = false;

    foreach($clientResults as $row){
        if($row["date"] == $date){
            $clientsData[] = (int)$row["total_clients"];
            $found = true;
            break;
        }
    }

    if(!$found){
        $clientsData[] = 0;
    }
}


// ===============================
// --- CLIENTS SOURCE DATA ---
// ===============================

$clientSourceQuery = $conn->prepare("
    SELECT 
        DATE(register_date) as date,
        SUM(google_login_verified = 1) as google_users,
        SUM(google_login_verified = 0) as normal_users
    FROM clients
    WHERE DATE(register_date) BETWEEN ? AND ?
    GROUP BY DATE(register_date)
");
$clientSourceQuery->execute([$start, $end]);
$clientSourceResults = $clientSourceQuery->fetchAll(PDO::FETCH_ASSOC);

$googleUsers = [];
$normalUsers = [];

foreach ($period as $dateObj) {

    $date = $dateObj->format("Y-m-d");
    $found = false;

    foreach ($clientSourceResults as $row) {

        if ($row["date"] == $date) {

            $googleUsers[] = (int)$row["google_users"];
            $normalUsers[] = (int)$row["normal_users"];

            $found = true;
            break;
        }
    }

    if (!$found) {
        $googleUsers[] = 0;
        $normalUsers[] = 0;
    }
}

$totalClients = array_sum($googleUsers) + array_sum($normalUsers);
$totalGoogle  = array_sum($googleUsers);
$totalNormal  = array_sum($normalUsers);

$topSpendersQuery = $conn->prepare("
    SELECT 
        c.client_id,
        c.username,
        SUM(o.order_charge) AS total_spent
    FROM orders o
    JOIN clients c ON c.client_id = o.client_id
    WHERE DATE(o.order_create) BETWEEN ? AND ?
    GROUP BY c.client_id
    ORDER BY total_spent DESC
    LIMIT 10
");
$topSpendersQuery->execute([$start,$end]);
$topSpenders = $topSpendersQuery->fetchAll(PDO::FETCH_ASSOC);


$topDepositorsQuery = $conn->prepare("
    SELECT 
        c.client_id,
        c.username,
        SUM(p.payment_amount) AS total_deposit
    FROM payments p
    JOIN clients c ON c.client_id = p.client_id
    WHERE p.payment_status = 3
      AND p.payment_amount > 0
      AND DATE(p.payment_create_date) BETWEEN ? AND ?
    GROUP BY c.client_id
    ORDER BY total_deposit DESC
    LIMIT 10
");
$topDepositorsQuery->execute([$start,$end]);
$topDepositors = $topDepositorsQuery->fetchAll(PDO::FETCH_ASSOC);


$topServicesQuery = $conn->prepare("
    SELECT 
        s.service_id,
        s.service_name,
        SUM(o.order_charge) AS total_revenue
    FROM orders o
    JOIN services s ON s.service_id = o.service_id
    WHERE DATE(o.order_create) BETWEEN ? AND ?
    GROUP BY s.service_id
    ORDER BY total_revenue DESC
    LIMIT 10
");
$topServicesQuery->execute([$start,$end]);
$topServices = $topServicesQuery->fetchAll(PDO::FETCH_ASSOC);


// --- Return JSON ---
echo json_encode([
    "labels" => $labels,

    // Orders
    "completed" => $completed,
    "canceled"  => $canceled,
    "partial"   => $partial,

    // Funds
    "addedFunds"    => $addedFunds,
    "deductedFunds" => $deductedFunds,
    "netFunds"      => $netFunds,

    // Clients per day
    "googleUsers" => $googleUsers,
    "normalUsers" => $normalUsers,

    // Totals
    "totalClients" => $totalClients,
    "totalGoogle"  => $totalGoogle,
    "totalNormal"  => $totalNormal,

    // Top lists
    "topSpenders"   => $topSpenders,
    "topDepositors" => $topDepositors,
    "topServices"   => $topServices
]);