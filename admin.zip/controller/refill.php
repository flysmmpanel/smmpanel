<?php
if(!defined('BASEPATH')) {
   die('Direct access to the script is not allowed');
}
  if( $admin["access"]["refill"] != 1  ):
    header("Location:".site_url("admin"));
    exit();
  endif;

  $smmapi = new SMMApi();
  $fapi   = new socialsmedia_api();

  if( route(2) && is_numeric(route(2)) ):
      $page = route(2);
    else:
      $page = 1;
    endif;

  // ── Bulk action ────────────────────────────────────────────────────────
  if( route(2) == "multi-action" ):
      $orders = $_POST["order"];
      $action = $_POST["bulkStatus"];
      $allowed = ["Pending","Refilling","Completed","Rejected","Error"];
      if( in_array($action, $allowed) ):
          foreach ($orders as $id => $value):
              $update = $conn->prepare("UPDATE refill_status SET refill_status=:status WHERE id=:id ");
              $update->execute(["status"=>$action,"id"=>(int)$id]);
          endforeach;
      endif;
      header("Location:".site_url("admin/refill"));
      exit();
  endif;

  // ── Single status actions ──────────────────────────────────────────────
  if( route(2) == "refill_Pending" ):
      $id = route(3);
      $update = $conn->prepare("UPDATE refill_status SET refill_status=:status WHERE id=:id ");
      $update->execute(["status"=>"Pending","id"=>$id]);
      header("Location:".site_url("admin/refill"));
  elseif( route(2) == "refill_Error" ):
      $id = route(3);
      $update = $conn->prepare("UPDATE refill_status SET refill_status=:status WHERE id=:id ");
      $update->execute(["status"=>"Error","id"=>$id]);
      header("Location:".site_url("admin/refill"));
  elseif( route(2) == "refill_refilling" ):
      $id = route(3);
      $update = $conn->prepare("UPDATE refill_status SET refill_status=:status WHERE id=:id ");
      $update->execute(["status"=>"Refilling","id"=>$id]);
      header("Location:".site_url("admin/refill"));
  elseif( route(2) == "refill_complete" ):
      $id = route(3);
      $update = $conn->prepare("UPDATE refill_status SET refill_status=:status WHERE id=:id ");
      $update->execute(["status"=>"Completed","id"=>$id]);
      header("Location:".site_url("admin/refill"));
  elseif( route(2) == "refill_reject" ):
      $id = route(3);
      $update = $conn->prepare("UPDATE refill_status SET refill_status=:status WHERE id=:id ");
      $update->execute(["status"=>"Rejected","id"=>$id]);
      header("Location:".site_url("admin/refill"));
  endif;

  // ── Search / list ──────────────────────────────────────────────────────
  $search_where = '';
  $search_word  = '';
  $search_link  = '';
  $search       = '';

  if( $_GET["search_type"] == "refill_apiid" && $_GET["search"] ):
      $search_where = $_GET["search_type"];
      $search_word  = urldecode($_GET["search"]);
      $count        = $conn->prepare("SELECT COUNT(*) FROM refill_status WHERE refill_apiid LIKE :s");
      $count->execute(['s'=>"%$search_word%"]);
      $count        = (int)$count->fetchColumn();
      $search       = "WHERE refill_apiid LIKE '%".addslashes($search_word)."%'";
      $search_link  = "?search=".$search_word."&search_type=".$search_where;

      $to            = 25;
      $pageCount     = ceil($count/$to); if($page > $pageCount): $page = 1; endif;
      $where         = ($page*$to)-$to;
      $paginationArr = ["count"=>$pageCount,"current"=>$page,"next"=>$page+1,"previous"=>$page-1];
      $refills       = $conn->prepare("SELECT rs.*, c.username, c.email
          FROM refill_status rs
          INNER JOIN clients c ON c.client_id = rs.client_id
          WHERE rs.refill_apiid LIKE :s
          ORDER BY rs.id DESC LIMIT $where, $to");
      $refills->execute(['s'=>"%$search_word%"]);
      $refills = $refills->fetchAll(PDO::FETCH_ASSOC);

  elseif( $_GET["search_type"] == "order_id" && $_GET["search"] ):
      $search_where = $_GET["search_type"];
      $search_word  = urldecode($_GET["search"]);
      $count        = $conn->prepare("SELECT COUNT(*) FROM refill_status WHERE order_id = :s");
      $count->execute(['s'=>$search_word]);
      $count        = (int)$count->fetchColumn();
      $search       = "WHERE order_id = '".addslashes($search_word)."'";
      $search_link  = "?search=".$search_word."&search_type=".$search_where;

      $to            = 25;
      $pageCount     = ceil($count/$to); if($page > $pageCount): $page = 1; endif;
      $where         = ($page*$to)-$to;
      $paginationArr = ["count"=>$pageCount,"current"=>$page,"next"=>$page+1,"previous"=>$page-1];
      $refills       = $conn->prepare("SELECT rs.*, c.username, c.email
          FROM refill_status rs
          INNER JOIN clients c ON c.client_id = rs.client_id
          WHERE rs.order_id = :order_id
          ORDER BY rs.id DESC LIMIT $where, $to");
      $refills->execute(['order_id'=>$search_word]);
      $refills = $refills->fetchAll(PDO::FETCH_ASSOC);

  elseif( $_GET["search_type"] == "username" && $_GET["search"] ):
      $search_where = $_GET["search_type"];
      $search_word  = urldecode($_GET["search"]);
      $count        = $conn->prepare("SELECT COUNT(*) FROM refill_status rs INNER JOIN clients c ON c.client_id = rs.client_id WHERE c.username LIKE :s");
      $count->execute(['s'=>"%$search_word%"]);
      $count        = (int)$count->fetchColumn();
      $search_link  = "?search=".$search_word."&search_type=".$search_where;

      $to            = 25;
      $pageCount     = ceil($count/$to); if($page > $pageCount): $page = 1; endif;
      $where         = ($page*$to)-$to;
      $paginationArr = ["count"=>$pageCount,"current"=>$page,"next"=>$page+1,"previous"=>$page-1];
      $refills       = $conn->prepare("SELECT rs.*, c.username, c.email
          FROM refill_status rs
          INNER JOIN clients c ON c.client_id = rs.client_id
          WHERE c.username LIKE :s
          ORDER BY rs.id DESC LIMIT $where, $to");
      $refills->execute(['s'=>"%$search_word%"]);
      $refills = $refills->fetchAll(PDO::FETCH_ASSOC);

  elseif( $_GET["search_type"] == "status" && $_GET["search"] ):
      $search_where = $_GET["search_type"];
      $search_word  = urldecode($_GET["search"]);
      $allowed_statuses = ["Pending","Refilling","Completed","Rejected","Error"];
      if(!in_array($search_word, $allowed_statuses)) $search_word = 'Pending';
      $count        = $conn->prepare("SELECT COUNT(*) FROM refill_status WHERE refill_status = :s");
      $count->execute(['s'=>$search_word]);
      $count        = (int)$count->fetchColumn();
      $search_link  = "?search=".$search_word."&search_type=".$search_where;

      $to            = 25;
      $pageCount     = ceil($count/$to); if($page > $pageCount): $page = 1; endif;
      $where         = ($page*$to)-$to;
      $paginationArr = ["count"=>$pageCount,"current"=>$page,"next"=>$page+1,"previous"=>$page-1];
      $refills       = $conn->prepare("SELECT rs.*, c.username, c.email
          FROM refill_status rs
          INNER JOIN clients c ON c.client_id = rs.client_id
          WHERE rs.refill_status = :s
          ORDER BY rs.id DESC LIMIT $where, $to");
      $refills->execute(['s'=>$search_word]);
      $refills = $refills->fetchAll(PDO::FETCH_ASSOC);

  else:
      $count        = $conn->prepare("SELECT COUNT(*) FROM refill_status");
      $count->execute([]);
      $count        = (int)$count->fetchColumn();
      $to            = 25;
      $pageCount     = ceil($count/$to); if($page > $pageCount): $page = 1; endif;
      $where         = ($page*$to)-$to;
      $paginationArr = ["count"=>$pageCount,"current"=>$page,"next"=>$page+1,"previous"=>$page-1];
      $refills       = $conn->prepare("SELECT rs.*, c.username, c.email
          FROM refill_status rs
          INNER JOIN clients c ON c.client_id = rs.client_id
          ORDER BY rs.id DESC LIMIT $where, $to");
      $refills->execute([]);
      $refills = $refills->fetchAll(PDO::FETCH_ASSOC);
  endif;

 require admin_view('refill');
