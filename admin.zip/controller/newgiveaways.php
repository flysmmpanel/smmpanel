<?php
if(!defined('BASEPATH')) die('Direct access not allowed');

class NewGiveaways extends Controller {

    // Show all giveaways
    public function index() {
        $giveaways = $this->db->query("SELECT * FROM giveaways2 ORDER BY created_at DESC")->fetchAll();
        return view('admin/new_giveaways/index.twig', ['giveaways' => $giveaways]);
    }

    // Create new giveaway
    public function create($post) {
        $stmt = $this->db->prepare("INSERT INTO giveaways2 (title, description, badge, end_date) VALUES (?, ?, ?, ?)");
        $stmt->execute([$post['title'], $post['description'], $post['badge'], $post['end_date']]);
        header("Location: " . site_url("admin/newgiveaways"));
    }

    // Edit giveaway
    public function edit($id, $post) {
        $stmt = $this->db->prepare("UPDATE giveaways2 SET title=?, description=?, badge=?, end_date=?, status=? WHERE id=?");
        $stmt->execute([$post['title'], $post['description'], $post['badge'], $post['end_date'], $post['status'], $id]);
        header("Location: " . site_url("admin/newgiveaways"));
    }

    // Delete giveaway
    public function delete($id) {
        $this->db->query("DELETE FROM giveaways2 WHERE id=$id");
        $this->db->query("DELETE FROM giveaway_participants2 WHERE giveaway_id=$id");
        header("Location: " . site_url("admin/newgiveaways"));
    }

    // Announce winner
    public function announceWinner($giveaway_id, $user_id) {
        $stmt = $this->db->prepare("INSERT INTO giveaway_winners2 (giveaway_id, user_id) VALUES (?, ?)");
        $stmt->execute([$giveaway_id, $user_id]);
    }

    // Get participants
    public function participants($giveaway_id) {
        return $this->db->query("SELECT gp.*, u.username FROM giveaway_participants2 gp JOIN users u ON gp.user_id = u.id WHERE gp.giveaway_id=$giveaway_id")->fetchAll();
    }
}
