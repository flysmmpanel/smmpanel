<?php
if(!defined('BASEPATH')) {
   die('Direct access to the script is not allowed');
}

// Change access key later (for now allow all admins)
if( $admin["access"]["bulkc"] != 1  ):
    header("Location:".site_url("admin"));
    exit();
endif;

$title .= "Leaderboard Management";

// Temporary test data
$total_users = 125;
$total_participants = 45;

require admin_view('leaderboard');