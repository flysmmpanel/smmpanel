<?php

if(!defined('BASEPATH')) {
   die('Direct access to the script is not allowed');
}

// Reuse the services access permission
if( $admin["access"]["services"] != 1 ):
    header("Location:".site_url("admin"));
    exit();
endif;

if( $_SESSION["client"]["data"] ):
    $data = $_SESSION["client"]["data"];
    foreach ($data as $key => $value) {
        $$key = $value;
    }
    unset($_SESSION["client"]);
endif;

// ── Single Restore ────────────────────────────────────────────────────────────
if( route(2) == "restore" ):
    $id = intval(route(3));
    if($id):
        $restore = $conn->prepare("UPDATE services SET archived=0, archived_at=NULL WHERE service_id=:id AND archived=1");
        $restore->execute(array("id" => $id));
        if($restore):
            $_SESSION["client"]["data"]["success"]    = 1;
            $_SESSION["client"]["data"]["successText"]= "Service Restored Successfully";
        else:
            $_SESSION["client"]["data"]["error"]    = 1;
            $_SESSION["client"]["data"]["errorText"]= "Restore Failed";
        endif;
    endif;
    header("Location:".site_url("admin/archived-services"));
    exit();
endif;

// ── Bulk Restore ──────────────────────────────────────────────────────────────
if( route(2) == "bulk-restore" && $_POST ):
    $services = isset($_POST["service"]) ? $_POST["service"] : array();
    $i = 0;
    foreach($services as $id => $value):
        $restore = $conn->prepare("UPDATE services SET archived=0, archived_at=NULL WHERE service_id=:id AND archived=1");
        $restore->execute(array("id" => intval($id)));
        if($restore) $i++;
    endforeach;
    if($i > 0):
        $_SESSION["client"]["data"]["success"]    = 1;
        $_SESSION["client"]["data"]["successText"]= $i." Service(s) Restored Successfully";
    else:
        $_SESSION["client"]["data"]["error"]    = 1;
        $_SESSION["client"]["data"]["errorText"]= "No services were restored";
    endif;
    header("Location:".site_url("admin/archived-services"));
    exit();
endif;

// ── Permanent Delete ──────────────────────────────────────────────────────────
if( route(2) == "permanent-delete" ):
    $id = intval(route(3));
    if($id):
        $delete = $conn->prepare("DELETE FROM services WHERE service_id=:id AND archived=1");
        $delete->execute(array("id" => $id));
        if($delete):
            $_SESSION["client"]["data"]["success"]    = 1;
            $_SESSION["client"]["data"]["successText"]= "Service Permanently Deleted";
        else:
            $_SESSION["client"]["data"]["error"]    = 1;
            $_SESSION["client"]["data"]["errorText"]= "Delete Failed";
        endif;
    endif;
    header("Location:".site_url("admin/archived-services"));
    exit();
endif;

// ── List View ─────────────────────────────────────────────────────────────────
$search     = isset($_GET['search']) ? trim($_GET['search']) : '';
$searchParam = '%' . $search . '%';

// Pagination setup
$units = $conn->prepare("SELECT * FROM units_per_page WHERE page=:page");
$units->execute(array("page" => "services"));
$units = $units->fetch(PDO::FETCH_ASSOC);
$to = isset($units["unit"]) ? (int)$units["unit"] : 100;

if( !route(2) || !is_numeric(route(2)) ):
    $page = 1;
else:
    $page = (int)route(2);
endif;

// Count total archived services matching search
$countStmt = $conn->prepare(
    "SELECT COUNT(*) FROM services 
     LEFT JOIN service_api ON service_api.id = services.service_api 
     LEFT JOIN categories ON categories.category_id = services.category_id 
     WHERE services.archived = 1 AND services.service_name LIKE :search"
);
$countStmt->execute(array("search" => $searchParam));
$totalCount = (int)$countStmt->fetchColumn();

$pageCount = $to > 0 ? ceil($totalCount / $to) : 1;
if($page > $pageCount) $page = 1;
$offset = ($page * $to) - $to;

$paginationArr = array(
    "count"    => $pageCount,
    "current"  => $page,
    "next"     => $page + 1,
    "previous" => $page - 1
);

// Fetch archived services
$archivedServices = $conn->prepare(
    "SELECT services.*, 
            service_api.api_name, service_api.currency,
            categories.category_name 
     FROM services 
     LEFT JOIN service_api ON service_api.id = services.service_api 
     LEFT JOIN categories  ON categories.category_id = services.category_id 
     WHERE services.archived = 1 AND services.service_name LIKE :search 
     ORDER BY services.archived_at DESC, services.service_id DESC
     LIMIT :limit OFFSET :offset"
);
$archivedServices->bindValue(':search', $searchParam, PDO::PARAM_STR);
$archivedServices->bindValue(':limit',  $to,          PDO::PARAM_INT);
$archivedServices->bindValue(':offset', $offset,      PDO::PARAM_INT);
$archivedServices->execute();
$archivedServices = $archivedServices->fetchAll(PDO::FETCH_ASSOC);

require admin_view('archived-services');