<?php
/**
 * ZEX SMM - Auto Description Generator
 * Title se Start Time, Speed, Refill nikaal ke fixed template
 * (🔥 ✦ ⚠) wali description banata hai.
 *
 * SAVE THIS FILE AT: admin/includes/service_description_generator.php
 * Phir admin/services.php (controller) ke sabse upar require kar lena.
 */

if (!function_exists('zex_normalize_unicode')) {
    // Bold unicode (𝗦𝗽𝗲𝗲𝗱, 𝐑𝐞𝐟𝐢𝐥𝐥 etc) ko wapas normal ASCII text me convert karta hai
    // taake regex matching sahi se ho sake (matching ke liye use hota hai)
    function zex_normalize_unicode($str) {
        $result = '';
        $len = mb_strlen($str, 'UTF-8');
        for ($i = 0; $i < $len; $i++) {
            $char = mb_substr($str, $i, 1, 'UTF-8');
            $ord  = mb_ord($char, 'UTF-8');
            if ($ord >= 0x1D400 && $ord <= 0x1D419) { $result .= chr($ord - 0x1D400 + 65); }        // Bold A-Z
            elseif ($ord >= 0x1D41A && $ord <= 0x1D433) { $result .= chr($ord - 0x1D41A + 97); }    // Bold a-z
            elseif ($ord >= 0x1D5D4 && $ord <= 0x1D5ED) { $result .= chr($ord - 0x1D5D4 + 65); }    // Sans-Bold A-Z
            elseif ($ord >= 0x1D5EE && $ord <= 0x1D607) { $result .= chr($ord - 0x1D5EE + 97); }    // Sans-Bold a-z
            elseif ($ord >= 0x1D7CE && $ord <= 0x1D7D7) { $result .= chr($ord - 0x1D7CE + 48); }    // Bold 0-9
            elseif ($ord >= 0x1D7EC && $ord <= 0x1D7F5) { $result .= chr($ord - 0x1D7EC + 48); }    // Sans-Bold 0-9
            else { $result .= $char; }
        }
        return $result;
    }
}

if (!function_exists('zex_bold_unicode')) {
    // Normal text ko Refill wale style jaisa bold unicode bana deta hai (𝐍𝐨, 𝟑𝟎 𝐃𝐚𝐲𝐬, 𝐋𝐢𝐟𝐞𝐭𝐢𝐦𝐞 etc)
    function zex_bold_unicode($str) {
        // agar pehle se bold hai to touch mat karo
        if (preg_match('/[\x{1D400}-\x{1D7FF}]/u', $str)) {
            return $str;
        }
        $result = '';
        $len = mb_strlen($str, 'UTF-8');
        for ($i = 0; $i < $len; $i++) {
            $char = mb_substr($str, $i, 1, 'UTF-8');
            $ord  = mb_ord($char, 'UTF-8');
            if ($ord >= 65 && $ord <= 90) { $result .= mb_chr($ord - 65 + 0x1D400, 'UTF-8'); }      // A-Z
            elseif ($ord >= 97 && $ord <= 122) { $result .= mb_chr($ord - 97 + 0x1D41A, 'UTF-8'); } // a-z
            elseif ($ord >= 48 && $ord <= 57) { $result .= mb_chr($ord - 48 + 0x1D7CE, 'UTF-8'); }  // 0-9
            else { $result .= $char; }
        }
        return $result;
    }
}

if (!function_exists('zex_generate_description')) {
    /**
     * Main function - title se description generate karta hai
     * @param string $title service_name from DB
     * @return string fixed-template description
     */
    function zex_generate_description($title) {

        $clean_segments = array_map('trim', explode('|', zex_normalize_unicode($title)));
        $raw_segments   = array_map('trim', explode('|', $title));

        $start      = "0-1 Hour";
        $speed      = "Not Specified";
        $refill_val = "No";
        $drop_rate  = "No";
        $quality    = "100% Non-Drop";

        foreach ($clean_segments as $idx => $seg) {
            $raw = isset($raw_segments[$idx]) ? $raw_segments[$idx] : $seg;

            // ── Start Time ──────────────────────────────
            if (preg_match('/start\s*(?:time)?\s*:?\s*(.+)/i', $seg, $m)) {
                $start = trim($m[1]);
            }

            // ── Speed ────────────────────────────────────
            if (preg_match('/speed\s*:?\s*(.+)/i', $seg, $m)) {
                $speed = trim($m[1]);
            }

            // ── Refill ───────────────────────────────────
            if (preg_match('/no\s*[\-–]?\s*refill/i', $seg)) {
                $refill_val = "No";
            } elseif (preg_match('/refill\s*:?\s*(.+)/i', $seg, $m)) {
                $refill_val = trim(str_replace(array('♻️', '✅', '🔥', '⚡', '️'), '', $m[1]));
                // agar original me already bold tha to wahi bold value use karo
                if (preg_match('/refill\s*:?\s*(.+)/iu', $raw, $mb)) {
                    $candidate = trim(str_replace(array('♻️', '✅', '🔥', '⚡', '️'), '', $mb[1]));
                    if (preg_match('/[\x{1D400}-\x{1D7FF}]/u', $candidate)) {
                        $refill_val = $candidate;
                    }
                }
            } elseif (preg_match('/lifetime/i', $seg)) {
                $refill_val = "Lifetime";
            }

            // ── Drop Rate hints ──────────────────────────
            if (preg_match('/non[\-\s]?drop/i', $seg)) {
                $drop_rate = "No";
            } elseif (preg_match('/drop\s*[\-–]?\s*100%/i', $seg)) {
                $drop_rate = "Yes (High Drop)";
            }

            // ── Quality hints ────────────────────────────
            if (preg_match('/real|hq|high\s*quality|old\s*account/i', $seg)
                && !preg_match('/speed|start|refill/i', $seg)) {
                $quality = trim($seg);
            }
        }

        // Speed ko clean karo - agar time unit missing hai to "Per Day" add kardo
        if (!preg_match('/day|hour|min/i', $speed)) {
            $speed .= " Per Day";
        }
        $speed = preg_replace('/\s*\/\s*day/i', ' Per Day', $speed);
        $speed = preg_replace('/\s*\/\s*hour/i', ' Per Hour', $speed);

        $refill_bold = zex_bold_unicode($refill_val);

        $description  = "🔥 Read Service Description Before Use\n\n";
        $description .= "✦ Start Time: " . $start . "\n";
        $description .= "✦ Speed: " . $speed . "\n";
        $description .= "✦ 𝐑𝐞𝐟𝐢𝐥𝐥 : " . $refill_bold . "\n";
        $description .= "✦ Drop Rate: " . $drop_rate . "\n";
        $description .= "✦ Quality: " . $quality . "\n\n";
        $description .= "⚠ Important Notes:\n";
        $description .= "➤ Private Account = No Delivery\n";
        $description .= "➤ Don't Place Multiple Orders on same link\n";
        $description .= "➤ Refill Normal 24 to 48 Hour\n";
        $description .= "➤ Link Must Be Public & Correct";

        return $description;
    }
}