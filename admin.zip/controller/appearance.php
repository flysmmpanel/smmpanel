<?php
if (!defined('BASEPATH')) {
  die('Direct access to the script is not allowed');
}
if ($admin["access"]["appearance"] != 1) {
  header("Location:" . site_url("admin"));
  exit();
}

if (!route(2)):
  $route[2] = "themes";
endif;





if (isset($_POST['add_theme'])) {
    // রেনডম থিম নাম তৈরি করুন
    $random_string = strtoupper(bin2hex(random_bytes(4))); // ৮টি হেক্স ক্যারেক্টার (৪ বাইট)
    $theme_name = 'New Theme -' . $random_string; // থিমের নাম
    $theme_dirname = strtolower($random_string); // থিমের ডিরেক্টরি নাম

    // পূর্বের থিম থেকে Twig ফাইল কপি করুন
    $default_theme_dir = 'app/views/custom'; // পূর্বের থিমের ডিরেক্টরি
    $new_theme_dir = "app/views/{$theme_dirname}";

    // নতুন থিমের ডিরেক্টরিতে ফোল্ডার তৈরি করুন, যদি এটি ইতিমধ্যে না থাকে
    if (!file_exists($new_theme_dir)) {
        mkdir($new_theme_dir);
    }

    // simplify থিমের সব Twig ফাইল কপি করুন
    $twig_files = glob("{$default_theme_dir}/*.twig"); // simplify থিমের সমস্ত .twig ফাইল পাওয়া যাবে
    
    if (!$twig_files) {
        echo "No .twig files found in {$default_theme_dir}";
    } else {
        foreach ($twig_files as $file) {
            $destination_file = "{$new_theme_dir}/" . basename($file);
            $copy_status = copy($file, $destination_file); // ফাইল কপি করুন
            if (!$copy_status) {
                echo "Failed to copy: {$file} to {$destination_file}";
            }
        }
    }

    // ডাটাবেসে নতুন থিম যোগ করুন
    $insert = $conn->prepare("INSERT INTO themes (theme_name, theme_dirname, last_modified) VALUES (?, ?, NOW())");
    $insert->execute([$theme_name, $theme_dirname]);

    // থিম অ্যাড হওয়ার পর সাইটে রিডিরেক্ট করুন
    header("Location: " . site_url("admin/appearance/themes"));
    exit;
}




if ($_SESSION["client"]["data"]):
  $data = $_SESSION["client"]["data"];
  foreach ($data as $key => $value) {
    $$key = $value;
  }
  unset($_SESSION["client"]);
endif;

$menuList = [
  "Themes" => "themes",
  "New Year" => "new_year",
  "Pages" => "pages",
  "Announcement" => "news",
  "SEO Settings" => "meta",
  "Blogs" => "blog",
  "Menu" => "menu",
  "Languages" => "language",
  "Integrations" => "integrations",
  "Whatsapp & Telegram Button" =>"whatsapp-telegram",
  "Uploaded Images" => "files"
];

if (!array_search(route(2), $menuList)):
  header("Location:" . site_url("admin/appearance"));


  elseif( route(2) == "pages" ):
    $access = $admin["access"]["pages"];
      if( $access ):
        if( route(3) == "edit" ):
          if( $_POST ):
            $id = route(4);
            foreach ($_POST as $key => $value) {
              $$key = $value;
            }
              if( $content == "<br>" ): $content = ""; endif;
            if( !countRow(["table"=>"pages","where"=>["page_get"=>$id]]) ):
              $error    = 1;
              $icon     = "error";
              $errorText= "Lütfen geçerli ödeme methodu seçin";
            else:
              $update = $conn->prepare("UPDATE pages SET last_modified=:last_modified,  page_content=:content, seo_title=:title, seo_keywords=:keywords, seo_description=:description WHERE page_get=:id ");
              $update->execute(array("id"=>$id,"content"=>$content, "title"=>$seo_title,"description"=>$seo_description,"keywords"=>$seo_keywords,"last_modified"=>date('Y-m-d h:i:s')  ));
                if( $update ):
                  $success    = 1;
                  $successText= "Success";
                else:
                  $error    = 1;
                  $errorText= "Failed";
                endif;
            endif;
          endif;
          $page = $conn->prepare("SELECT * FROM pages WHERE page_get=:get ");
          $page->execute(array("get"=>route(4)));
          $page = $page->fetch(PDO::FETCH_ASSOC); if( !$page ): header("Location:".site_url("admin/appearance/pages")); endif;
elseif( route(3) == "type" ):
          $id     = $_GET["id"];
          $type   = $_GET["type"]; if( $type == "off" ): $type = 2; elseif( $type == "on" ): $type = 1; endif;
          $update = $conn->prepare("UPDATE pages SET page_status=:type WHERE page_id=:id ");
          $update->execute(array("id"=>$id,"type"=>$type));
            if( $update ):
                  $success    = 1;
                  $successText= "Success";
                else:
                  $error    = 1;
                  $errorText= "Failed";
                endif;
elseif( route(3) == "delete" ):
$id = route(4);
$delete = $conn->prepare("DELETE FROM pages WHERE page_id=:id ");
           $delete =   $delete->execute(array("id"=>$id));
         if( $delete ):
            header("Location:".site_url("admin/appearance/pages"));
            $_SESSION["client"]["data"]["success"]    = 1;
            $_SESSION["client"]["data"]["successText"]= "Success";
          else: 
$_SESSION["client"]["data"]["error"]    = 1;
            $_SESSION["client"]["data"]["errorText"]= "Failed ";
            endif;
elseif( route(3) == "create" ):
                  if( $_POST ):
            $id = route(4);
            foreach ($_POST as $key => $value) {
              $$key = $value;
            }
$code = $pageget;
if (countRow(["table" => "pages", "where" => ["page_get" => $pageget ]])):
        
    else:
                $html = "";
                file_put_contents('app/controller/'.$code.'.php', $html);
                
$insert = $conn->prepare("INSERT INTO pages SET last_modified=:last_modified,   page_content=:content, seo_title=:title, seo_keywords=:keywords, seo_description=:description, page_get=:get , page_name=:name");
            $insert = $insert->execute(array("content"=>$content, "title"=>$seo_title,"description"=>$seo_description,"keywords"=>$seo_keywords,"get"=>$pageget,"name"=>$name 
 ,"last_modified"=>"0000-00-00 00:00:00" ));


$themes = $conn->prepare("SELECT * FROM themes ");
          $themes->execute(array());
          $themes = $themes->fetchAll(PDO::FETCH_ASSOC);
foreach( $themes as $theme ):

$fn       = "app/views/".$theme["theme_dirname"]."/$pageget.twig";
              $codeType = "twig";
              $dir      = "HTML";
            $text = $_POST["code"];
            $text = str_replace("&lt;","<",$text);
            $text = str_replace("&gt;",">",$text);
            $text = str_replace("&quot;",'"',$text);
            $updated_file   = fopen($fn,"w");
            fwrite($updated_file, $text);
            fclose($updated_file);
$text = $theme["newpage"];
file_put_contents($fn, $text );
endforeach;
if( $insert):
                  $success    = 1;
                  $successText= "Success";
header("Location:".site_url("admin/appearance/pages"));
                else:
                  $error    = 1;
                  $errorText= "Failed";
               



endif; 
           endif; 
           

endif; 
           
          
        elseif( !route(3) ):
          $pageList = $conn->prepare("SELECT * FROM pages ");
          $pageList->execute(array());
          $pageList = $pageList->fetchAll(PDO::FETCH_ASSOC);
        else:
          header("Location:".site_url("admin/appearance/pages"));
        endif;
      endif;
    if( route(5) ): header("Location:".site_url("admin/appearance/pages")); endif;
  
  
  
elseif (route(2) == "menu"):
  $access = $admin["access"]["menu"];

  if ($access):
    $menus = $conn->prepare("SELECT * FROM menus ORDER BY menu_line ");
    $menus->execute(array());
    $menus = $menus->fetchAll(PDO::FETCH_ASSOC);
    if (route(3) == "add_internal" && $_POST):
      foreach ($_POST as $key => $value) {
        $$key = $value;
      }
      $language   = $conn->prepare("SELECT * FROM languages WHERE default_language=:default");
        $language->execute(array("default"=>1));
        $language   = $language->fetch(PDO::FETCH_ASSOC);
      $multiName = $_POST["menu_name"];
      $menu_name = $multiName[$language["language_code"]];
      $multiMenuName = json_encode($multiName);
      
      if (empty($menu_name)):
        $error = 1;
        $errorText = "Name cannot be empty";
        $icon = "error";
      elseif (empty($slug)):
        $error = 1;
        $errorText = "Slug Cannot be empty";
        $icon = "error";

      else:
        $active = preg_replace("(/)", "", $slug);
        $row = $conn->query("SELECT * FROM menus ORDER BY menu_line DESC LIMIT 1 ")->fetch(PDO::FETCH_ASSOC);
        $conn->beginTransaction();
        if ($slug == "/neworder"):
          $insert = $conn->prepare("INSERT INTO menus SET name=:name,menu_name_lang=:lang, active=:active,  slug=:url, menu_line=:line, visible=:visible, icon=:icon ");
          $insert = $insert->execute(array("name" => $menu_name,"lang" => $multiMenuName, "active" => "neworder", "url" => "/", "visible" => "Internal", "icon" => $icon, "line" => ($row["menu_line"] + 1)));
        elseif ($slug == "/login"):
          $insert = $conn->prepare("INSERT INTO menus SET name=:name, menu_name_lang=:lang, active=:active,  slug=:url, menu_line=:line, visible=:visible, icon=:icon ");
          $insert = $insert->execute(array("name" => $menu_name,"lang" => $multiMenuName, "active" => "login", "url" => "/", "visible" => "External", "icon" => $icon, "line" => ($row["menu_line"] + 1)));
        else:
          $insert = $conn->prepare("INSERT INTO menus SET name=:name, menu_name_lang=:lang, active=:active,  slug=:url, menu_line=:line, visible=:visible, icon=:icon ");
          $insert = $insert->execute(array("name" => $menu_name,"lang" => $multiMenuName, "active" => $active, "url" => $slug, "visible" => $visible, "icon" => $icon, "line" => ($row["menu_line"] + 1)));
        endif;
        if ($insert):
          $conn->commit();
          $referrer = site_url("admin/appearance/menu");
          $error = 1;
          $errorText = "Success";
          $icon = "success";
        else:
          $conn->rollBack();
          $error = 1;
          $errorText = "Failed";
          $icon = "error";
        endif;
      endif;
      echo json_encode(["t" => "error", "m" => $errorText, "s" => $icon, "r" => $referrer, "time" => 1]);
      exit();
    elseif (route(3) == "delete"):
      $id = route(4);
      $delete = $conn->prepare("DELETE FROM menus WHERE id=:id ");
      $delete = $delete->execute(array("id" => $id));
      if ($delete):
        header("Location:" . site_url("admin/appearance/menu"));
        $_SESSION["client"]["data"]["success"] = 1;
        $_SESSION["client"]["data"]["successText"] = "Success";
      else:
        $_SESSION["client"]["data"]["error"] = 1;
        $_SESSION["client"]["data"]["errorText"] = "Failed ";
      endif;


    elseif (route(3) == "edit_menu" && $_POST):
      foreach ($_POST as $key => $value) {
        $$key = $value;
      }
      $language   = $conn->prepare("SELECT * FROM languages WHERE default_language=:default");
        $language->execute(array("default"=>1));
        $language   = $language->fetch(PDO::FETCH_ASSOC);
      $multiName = $_POST["menu_name"];
      $menu_name = $multiName[$language["language_code"]];
      $multiMenuName = json_encode($multiName);
      $id = route(4);
      if (empty($menu_name)):
        $error = 1;
        $errorText = "Name cannot be empty";
        $icon = "error";
      elseif (empty($slug)):
        $error = 1;
        $errorText = "Slug Cannot be empty";
        $icon = "error";
      else:
        $conn->beginTransaction();
        $update = $conn->prepare("UPDATE menus SET name=:name,menu_name_lang=:lang, icon=:icon, slug=:slug WHERE id=:id ");
        $update = $update->execute(array("name" => $menu_name,"lang" => $multiMenuName, "icon" => $icon, "slug" => $slug, "id" => $id));
        if ($update):
          $conn->commit();
          $referrer = site_url("admin/appearance/menu");
          $error = 1;
          $errorText = "Success";
          $icon = "success";
        else:
          $conn->rollBack();
          $error = 1;
          $errorText = "Failed";
          $icon = "error";
        endif;
      endif;
      echo json_encode(["t" => "error", "m" => $errorText, "s" => $icon, "r" => $referrer, "time" => 1]);
      exit();
    endif;

  endif;
elseif (route(2) == "integrations"):
  $access = $admin["access"]["inte"];
  if ($access):

    if (route(3) == "edit" && $_POST):
      foreach ($_POST as $key => $value) {
        $$key = $value;
      }

      $conn->beginTransaction();
      $update = $conn->prepare("UPDATE integrations SET code=:code, visibility=:visibility WHERE id=:id ");
      $update = $update->execute(array("code" => $code, "visibility" => $visibility, "id" => route(4)));

      if ($code == ""):
        $update2 = $conn->prepare("UPDATE integrations SET status=:status WHERE id=:id ");
        $update2 = $update2->execute(array("status" => 1, "id" => route(4)));
      endif;

      if ($update):
        $conn->commit();
        $referrer = site_url("admin/appearance/integrations");
        $error = 1;
        $errorText = "Operation successful";
        $icon = "success";
      else:
        $conn->rollBack();
        $error = 1;
        $errorText = "Operation failed";
        $icon = "error";
      endif;

      echo json_encode(["t" => "error", "m" => $errorText, "s" => $icon, "r" => $referrer, "time" => 1]);
      exit();
    endif;

    if (route(3) == "seo" && $_POST):
      foreach ($_POST as $key => $value) {
        $$key = $value;
      }

      $conn->beginTransaction();
      $update = $conn->prepare("UPDATE settings SET site_title=:title, site_keywords=:site_keywords, site_description=:site_description WHERE id=:id ");
      $update = $update->execute(array("title" => $title, "site_keywords" => $keywords, "site_description" => $description, "id" => '1'));


      if ($update):
        $conn->commit();
        $referrer = site_url("admin/appearance/integrations");
        $error = 1;
        $errorText = "Operation successful";
        $icon = "success";
      else:
        $conn->rollBack();
        $error = 1;
        $errorText = "Operation failed";
        $icon = "error";
      endif;

      echo json_encode(["t" => "error", "m" => $errorText, "s" => $icon, "r" => $referrer, "time" => 1]);
      exit();
    endif;

    if (route(3) == "google" && $_POST):
      foreach ($_POST as $key => $value) {
        $$key = $value;
      }

      $conn->beginTransaction();
      $update = $conn->prepare("UPDATE settings SET recaptcha_key=:key, recaptcha_secret=:secret WHERE id=:id ");
      $update = $update->execute(array("key" => $pwd, "secret" => $secret, "id" => 1));

      if ($update):
        $conn->commit();
        $referrer = site_url("admin/appearance/integrations");
        $error = 1;
        $errorText = "Operation successful";
        $icon = "success";
      else:
        $conn->rollBack();
        $error = 1;
        $errorText = "Operation failed";
        $icon = "error";
      endif;




      echo json_encode(["t" => "error", "m" => $errorText, "s" => $icon, "r" => $referrer, "time" => 1]);
      exit();
    endif;

    $active = $conn->prepare("SELECT * FROM integrations WHERE status=:status");
    $active->execute(array("status" => "2"));
    $active = $active->fetchAll(PDO::FETCH_ASSOC);

    $other = $conn->prepare("SELECT * FROM integrations WHERE status=:status");
    $other->execute(array("status" => "1"));
    $other = $other->fetchAll(PDO::FETCH_ASSOC);

    if (route(3) == "enabled") {
      $update = $conn->prepare("UPDATE integrations SET status=:status WHERE id=:id ");
      $update = $update->execute(array("status" => 2, "id" => route(4)));
      header("Location:" . site_url("admin/appearance/integrations"));
    }

    if (route(3) == "enabledg") {
      $update = $conn->prepare("UPDATE settings SET recaptcha=:recaptcha WHERE id=:id ");
      $update = $update->execute(array("recaptcha" => 2, "id" => 1));

      $update = $conn->prepare("UPDATE integrations SET status=:status WHERE id=:id ");
      $update = $update->execute(array("status" => 2, "id" => route(4)));
      header("Location:" . site_url("admin/appearance/integrations"));
    }

    if (route(3) == "disabled") {
      $update = $conn->prepare("UPDATE integrations SET status=:status WHERE id=:id ");
      $update = $update->execute(array("status" => 1, "id" => route(4)));
      header("Location:" . site_url("admin/appearance/integrations"));
    }

    if (route(3) == "disabled") {
      $update = $conn->prepare("UPDATE integrations SET status=:status WHERE id=:id ");
      $update = $update->execute(array("status" => 1, "id" => route(4)));
      header("Location:" . site_url("admin/appearance/integrations"));
    }


    if (route(3) == "disabledg") {
      $update = $conn->prepare("UPDATE settings SET recaptcha=:recaptcha WHERE id=:id ");
      $update = $update->execute(array("recaptcha" => 1, "id" => 1));

      $update = $conn->prepare("UPDATE integrations SET status=:status WHERE id=:id ");
      $update = $update->execute(array("status" => 1, "id" => 13));
      header("Location:" . site_url("admin/appearance/integrations"));
    }
  endif;





elseif (route(2) == "news"):

  $access = $admin["access"]["news"];

  if ($access):
    if (route(3) == "new" && $_POST):
      foreach ($_POST as $key => $value) {
        $$key = $value;
      }
      $language   = $conn->prepare("SELECT * FROM languages WHERE default_language=:default");
        $language->execute(array("default"=>1));
        $language   = $language->fetch(PDO::FETCH_ASSOC);
      $announcement_title = $_POST["announcement_title"][$language["language_code"]];
      
      $announcement_title_lang = $_POST["announcement_title"];
      $announcement_title_lang = json_encode($announcement_title_lang);
      
      $announcement_content = $_POST["announcement_content"][$language["language_code"]];
      
      $announcement_content_lang = $_POST["announcement_content"];
      
      $announcement_content_lang = json_encode($announcement_content_lang);

      if (empty($icon)):
        $error = 1;
        $errorText = "Choose icon.";
        $icon = "error";
      elseif (empty($announcement_title)):
        $error = 1;
        $errorText = "Announcement name cannot be empty";
        $icon = "error";
      elseif (empty($announcement_content)):
        $error = 1;
        $errorText = "Announcement content cannot be empty";
        $icon = "error";
      else:

        $conn->beginTransaction();
        $insert = $conn->prepare("INSERT INTO news SET news_icon=:icon, news_title=:title,
        news_title_lang=:news_title_lang,
        news_content_lang=:news_content_lang,
        news_content=:content, news_date=:date ");
$insert = $insert->execute(array(
    "icon" => $icon,
    "title" => $announcement_title,
    "news_title_lang" => $announcement_title_lang,
    "news_content_lang" => $announcement_content_lang,
    "content" => $announcement_content,
    "date" => date("Y-m-d H:i:s")));
        if ($insert):
          $conn->commit();
          $referrer = site_url("admin/appearance/news");
          $error = 1;
          $errorText = "Successful";
          $icon = "success";
        else:
          $conn->rollBack();
          $error = 1;
          $errorText = "Unsuccessful";
          $icon = "error";
        endif;
      endif;
      echo json_encode(["t" => "error", "m" => $errorText, "s" => $icon, "r" => $referrer, "time" => 1]);
      exit();
    elseif (route(3) == "edit" && $_POST):
      foreach ($_POST as $key => $value) {
        $$key = $value;
      }
      $id = route(4);
      
      $language   = $conn->prepare("SELECT * FROM languages WHERE default_language=:default");

        $language->execute(array("default"=>1));

        $language   = $language->fetch(PDO::FETCH_ASSOC);
      $announcement_title = $_POST["announcement_title"][$language["language_code"]];
      
      $announcement_title_lang = $_POST["announcement_title"];
      $announcement_title_lang = json_encode($announcement_title_lang);
      
      $announcement_content = $_POST["announcement_content"][$language["language_code"]];
      
      $announcement_content_lang = $_POST["announcement_content"];
      
      $announcement_content_lang = json_encode($announcement_content_lang);

      if (empty($icon)):
        $error = 1;
        $errorText = "Choose icon.";
        $icon = "error";
      elseif (empty($announcement_title)):
        $error = 1;
        $errorText = "Announcement name cannot be empty";
        $icon = "error";
      elseif (empty($announcement_content)):
        $error = 1;
        $errorText = "Announcement content cannot be empty";
        $icon = "error";
      else:

        $conn->beginTransaction();
        $update = $conn->prepare("UPDATE news SET news_icon=:icon, news_title=:title,
        news_title_lang=:news_title_lang,
        news_content_lang=:news_content_lang,
        news_content=:content WHERE id=:id ");
$update = $update->execute(array(
    "icon" => $icon,
    "title" => $announcement_title,
    "news_title_lang" => $announcement_title_lang,
    "news_content_lang" => $announcement_content_lang,
    "content" => $announcement_content,
    "id" => $id));
        if ($update):
          $conn->commit();
          $referrer = site_url("admin/appearance/news");
          $error = 1;
          $errorText = "Successful";
          $icon = "success";
        else:
          $conn->rollBack();
          $error = 1;
          $errorText = "Unsuccessful";
          $icon = "error";
        endif;
      endif;
      echo json_encode(["t" => "error", "m" => $errorText, "s" => $icon, "r" => $referrer, "time" => 1]);
      exit();
    elseif (route(3) == "delete"):
      $id = route(4);
      if (!countRow(["table" => "news", "where" => ["id" => $id]])):
        $error = 1;
        $icon = "error";
        $errorText = "Please select valid announcement";
      else:
        $delete = $conn->prepare("DELETE FROM news WHERE id=:id ");
        $delete->execute(array("id" => $id));
        if ($delete):
          $error = 1;
          $icon = "success";
          $errorText = "Successful";
          $referrer = site_url("admin/appearance/news");
        else:
          $error = 1;
          $icon = "error";
          $errorText = "Unsuccessful";
        endif;
      endif;
      echo json_encode(["t" => "error", "m" => $errorText, "s" => $icon, "r" => $referrer, "time" => 0]);
      exit();
    elseif (!route(3)):
      $newsList = $conn->prepare("SELECT * FROM news ");
      $newsList->execute(array());
      $newsList = $newsList->fetchAll(PDO::FETCH_ASSOC);
    else:
      header("Location:" . site_url("admin/appearance/news"));

    endif;
  endif;

  if (route(5)):
    header("Location:" . site_url("admin/appearance/news"));
  endif;

elseif (route(2) == "language"):
  $access = $admin["access"]["language"];
  if ($access):
    $languageList = $conn->prepare("SELECT * FROM languages");
    $languageList->execute(array());
    $languageList = $languageList->fetchAll(PDO::FETCH_ASSOC);
    if (route(3) && route(3) != "new" && !countRow(["table" => "languages", "where" => ["language_code" => route(3)]])):
      header("Location:" . site_url("admin/appearance/language"));
    elseif (route(3) == "new"):
      include 'app/language/default.php';
    else:
      $language = $conn->prepare("SELECT * FROM languages WHERE language_code=:code");
      $language->execute(array("code" => route(3)));
      $language = $language->fetch(PDO::FETCH_ASSOC);
      include 'app/language/' . route(3) . '.php';
    endif;
    if ($_POST && route(3) != "new" && countRow(["table" => "languages", "where" => ["language_code" => route(3)]])):
      $html = '<?php ' . PHP_EOL . PHP_EOL;
      $html .= '$languageArray= [';
      foreach ($_POST["Language"] as $key => $value):
        $html .= ' "' . $key . '" => "' . $value . '", ' . PHP_EOL;
      endforeach;
      $html .= '];';
      file_put_contents('app/language/' . route(3) . '.php', $html);
      header("Location:" . site_url("admin/appearance/language/" . route(3)));
    elseif (route(3) == "new" && $_POST):
      $name = $_POST["language"];
      $code = $_POST["languagecode"];
      if (countRow(["table" => "languages", "where" => ["language_code" => $code]])):
        $error = 1;
        $errorText = "This language code is already in use.";
      else:
        $insert = $conn->prepare("INSERT INTO languages SET language_name=:name, language_code=:code ");
        $insert->execute(array("name" => $name, "code" => $code));
        if ($insert):
          $html = '<?php ' . PHP_EOL . PHP_EOL;
          $html .= '$languageArray= [';
          foreach ($_POST["Language"] as $key => $value):
            $html .= ' "' . $key . '" => "' . $value . '", ' . PHP_EOL;
          endforeach;
          $html .= '];';
          file_put_contents('app/language/' . $code . '.php', $html);
          header("Location:" . site_url("admin/appearance/language/"));
        endif;
      endif;
    
// Set Default Language Logic
elseif (isset($_GET["lang-default"]) && isset($_GET["lang-id"])):
    // First, set all languages to inactive (0)
    $update = $conn->prepare("UPDATE languages SET default_language = 0");
    $update->execute();

    // Then, set the selected language as default (2)
    $update = $conn->prepare("UPDATE languages SET default_language = 2 WHERE language_code = :code");
    $update->execute(array("code" => $_GET["lang-id"]));
    header("Location:" . site_url("admin/appearance/language"));

    // Delete Language Logic
    elseif (isset($_GET["lang-delete"]) && isset($_GET["lang-id"])):
      $delete = $conn->prepare("DELETE FROM languages WHERE language_code = :code");
      $delete->execute(array("code" => $_GET["lang-id"]));
      header("Location:" . site_url("admin/appearance/language"));


    elseif ($_GET["lang-type"] && $_GET["lang-id"]):
      if (countRow(["table" => "languages", "where" => ["language_type" => "2"]]) > 1 && $_GET["lang-type"] == 1):
        $update = $conn->prepare("UPDATE languages SET language_type = :type WHERE language_code = :code ");
        $update->execute(array("code" => $_GET["lang-id"], "type" => $_GET["lang-type"]));
      elseif ($_GET["lang-type"] == 2):
        $update = $conn->prepare("UPDATE languages SET language_type = :type WHERE language_code = :code ");
        $update->execute(array("code" => $_GET["lang-id"], "type" => $_GET["lang-type"]));
      endif;
      header("Location:" . site_url("admin/appearance/language"));
    endif;
  endif;
  
  
  
elseif (route(2) == "themes"):
  $access = $admin["access"]["themes"];
  if ($access):
    if (route(3) == "eternity-settings") {
      $check_if_column_exists = $conn->prepare("SELECT summary_card_background_color FROM settings WHERE id=1");
      $check_if_column_exists->execute();
      $check_if_column_exists = $check_if_column_exists->fetch(PDO::FETCH_ASSOC);
      if (is_array($check_if_column_exists) && count($check_if_column_exists)) {

      } else {
        $create_column = $conn->prepare("ALTER TABLE settings ADD summary_card_background_color varchar(100) DEFAULT 'theme_colour' AFTER downloaded_category_icons");
        $create_column->execute();
      }

      if (route(4) == "theme_colour") {
        $update_column = $conn->prepare("UPDATE settings SET summary_card_background_color=:colour WHERE id=1");
        $update_column->execute(
          array(
            "colour" => "theme_colour"
          )
        );
      } elseif (route(4) == "fixed_colour") {
        $update_column = $conn->prepare("UPDATE settings SET summary_card_background_color=:colour WHERE id=1");
        $update_column->execute(
          array(
            "colour" => "fixed_colour"
          )
        );
      } else {
        header("Location:" . site_url("admin/appearance/themes"));
        exit();
      }

    }

    $theme = $conn->prepare("SELECT * FROM themes WHERE id=:id");
    $theme->execute(array("id" => route(4)));
    $theme = $theme->fetch(PDO::FETCH_ASSOC);
    if (route(3) == "active" && countRow(["table" => "themes", "where" => ["theme_dirname" => $theme["theme_dirname"]]])):
      $update = $conn->prepare("UPDATE settings SET site_theme=:theme WHERE id=:id ");
      $update->execute(array("id" => 1, "theme" => $theme["theme_dirname"]));
      $update = $conn->prepare("UPDATE settings SET site_theme_alt=:site_theme_alt WHERE id=:id ");
      if ($theme["theme_dirname"] == "Simplify") {
        $update->execute(
          array(
            "id" => 1,
            "site_theme_alt" => "Grapes"
          )
        );
      } elseif ($theme["theme_dirname"] == "Eternity") {
        $update->execute(
          array(
            "id" => 1,
            "site_theme_alt" => "pink"
          )
        );
      } elseif ($theme["theme_dirname"] == "pitchy") {
        $update->execute(
          array(

            "id" => 1,

            "site_theme_alt" => "green"
          )
        );
      }

      header("Location:" . site_url("admin/appearance/themes"));
    elseif (route(3) && countRow(["table" => "themes", "where" => ["id" => route(3)]])):
      $lyt = $_GET["file"];
      $theme = $conn->prepare("SELECT * FROM themes WHERE id=:id");
      $theme->execute(array("id" => route(3)));
      $theme = $theme->fetch(PDO::FETCH_ASSOC);
      if (substr($lyt, -3) == "css") {
        $fn = "public/" . $theme["theme_dirname"] . "/" . $lyt;
        $codeType = "css";
        $dir = "CSS";
      } elseif (substr($lyt, -2) == "js") {
        $fn = "public/" . $theme["theme_dirname"] . "/" . $lyt;
        $codeType = "js";
        $dir = "JS";
      } elseif (substr($lyt, -4) == "twig") {
        $fn = "app/views/" . $theme["theme_dirname"] . "/" . $lyt;
        $codeType = "twig";
        $dir = "HTML";
      }
      if ($_POST):
        $text = $_POST["code"];




        $text = str_replace("&lt;", "<", $text);
        $text = str_replace("&gt;", ">", $text);
        $text = str_replace("&quot;", '"', $text);
        $updated_file = fopen($fn, "w");
        fwrite($updated_file, $text);
        fclose($updated_file);
        $update = $conn->prepare("UPDATE themes SET last_modified=:theme WHERE id=:id ");
        $update->execute(array("id" => route(3), "theme" => date('Y-m-d h:i:s')));

        header("Location:" . site_url("admin/appearance/themes/" . $theme["id"] . "?file=" . $lyt));
      endif;


elseif (route(3) == "delete" && route(4)):
      $theme_id = route(4); // ডিলিট করার জন্য থিমের ID

      // ডাটাবেস থেকে থিমের তথ্য বের করুন
      $query = $conn->prepare("SELECT theme_dirname FROM themes WHERE id = ?");
      $query->execute([$theme_id]);
      $theme = $query->fetch();

      if ($theme):
        $theme_dirname = $theme['theme_dirname'];

        // থিমের ডিরেক্টরি মুছে ফেলুন
        $theme_path = "app/views/{$theme_dirname}";
        if (is_dir($theme_path)) {
          // হেল্পার ফাংশন ভিতরে
          function delete_directory($dir) {
            if (!is_dir($dir)) {
              return false;
            }

            $files = array_diff(scandir($dir), ['.', '..']);
            foreach ($files as $file) {
              $file_path = "$dir/$file";
              is_dir($file_path) ? delete_directory($file_path) : unlink($file_path);
            }

            return rmdir($dir);
          }

          delete_directory($theme_path);
        }

        // ডাটাবেস থেকে থিম মুছে ফেলুন
        $delete = $conn->prepare("DELETE FROM themes WHERE id = ?");
        $delete->execute([$theme_id]);

        $_SESSION["client"]["data"]["success"] = 1;
        $_SESSION["client"]["data"]["successText"] = "Theme deleted successfully.";
      else:
        $_SESSION["client"]["data"]["error"] = 1;
        $_SESSION["client"]["data"]["errorText"] = "Theme not found.";
      endif;

      header("Location:" . site_url("admin/appearance/themes"));
      


   elseif (route(3) && !countRow(["table" => "themes", "where" => ["id" => route(3)]])):
      header("Location:" . site_url("admin/appearance/themes"));
    else:
      $themes = $conn->prepare("SELECT * FROM themes");
      $themes->execute(array());
      $themes = $themes->fetchAll(PDO::FETCH_ASSOC);
      if ($_POST):
        foreach ($_POST as $key => $value) {
          $$key = $value;
        }

        $update = $conn->prepare("UPDATE settings SET 
			
			site_theme_alt=:site_theme_alt
			 WHERE id=:id ");
        $update->execute(
          array(
            "id" => 1,
            "site_theme_alt" => $site_theme_alt
          )
        );

        $referrer = site_url("admin/appearance/themes");
        $icon = "success";
        $error = 1;
        $errorText = "Success";

        header("Location:" . site_url("admin/appearance/themes"));
        echo json_encode(["t" => "error", "m" => $errorText, "s" => $icon, "r" => $referrer, "time" => 1]);

        if ($update):
          header("Location:" . site_url("admin/appearance/themes"));
          $_SESSION["client"]["data"]["success"] = 1;
          $_SESSION["client"]["data"]["successText"] = "Successful";
        else:
          $errorText = "Failed";
          $error = 1;

        endif;
        
      endif;
    endif;


  endif;


elseif (route(2) == "meta"):

  $access = $admin["access"]["meta"];

  if ($access):

    if ($_POST):
      foreach ($_POST as $key => $value) {
        $$key = $value;
      }
      $conn->beginTransaction();
      $update = $conn->prepare("UPDATE settings SET 
			site_seo=:seo,
			site_title=:title,
			site_keywords=:keys,
			site_description=:desc,
			google_verification=:google_verification,
			meta_logo=:meta_logo
			WHERE id=:id ");
      $update = $update->execute(
        array(
          "id" => 1,
          "seo" => $seo,
          "title" => $title,
          "keys" => $keywords,
          "desc" => $description,
          "google_verification" => $google_verification,
          "meta_logo" => $metalogo,
        )
      );
      if ($update):
        $conn->commit();
        header("Location:" . site_url("admin/appearance/meta"));
        $_SESSION["client"]["data"]["success"] = 1;
        $_SESSION["client"]["data"]["successText"] = "Success";
      else:
        $conn->rollBack();
        $error = 1;
        $errorText = "Failed";
      endif;
    endif;
  endif;

  if (route(3)):
    header("Location:" . site_url("admin/appearance/alert"));
  endif;


elseif (route(2) == "blog"):
  $access = $admin["access"]["blog"];

  if ($access):
    $id = route(4);

    $bloge = $conn->prepare("SELECT * FROM blogs WHERE id=:id ");
    $bloge->execute(array("id" => $id));
    $bloge = $bloge->fetch(PDO::FETCH_ASSOC);

    $blogs = $conn->prepare("SELECT * FROM blogs ");
    $blogs->execute(array());
    $blogs = $blogs->fetchAll(PDO::FETCH_ASSOC);

    if (route(3) == "new" && $_POST):
      foreach ($_POST as $key => $value) {
        $$key = $value;
      }

      if (empty($title)):
        header("Location:" . site_url("admin/appearance/blog/new"));
        $_SESSION["client"]["data"]["error"] = 1;
        $_SESSION["client"]["data"]["errorText"] = "Blog title cannot be empty";
      elseif (empty($content)):
        header("Location:" . site_url("admin/appearance/blog/new"));
        $_SESSION["client"]["data"]["error"] = 1;
        $_SESSION["client"]["data"]["errorText"] = "Blog content cannot be empty";
      elseif (empty($url)):
        header("Location:" . site_url("admin/appearance/blog/new"));
        $_SESSION["client"]["data"]["error"] = 1;
        $_SESSION["client"]["data"]["errorText"] = "Blog url cannot be empty";
      else:
        $conn->beginTransaction();


        $insert = $conn->prepare("INSERT INTO blogs SET title=:title , status=:status , content=:content , image_file=:link, published_at=:published_at , blog_get=:get ");
        $insert = $insert->execute(array("title" => $title, "status" => $status, "get" => $blogurl, "content" => $content, "link" => $url, "published_at" => date('Y-m-d h:i:s')));
        if ($insert):
          $conn->commit();
          header("Location:" . site_url("admin/appearance/blog"));
          $_SESSION["client"]["data"]["success"] = 1;
          $_SESSION["client"]["data"]["successText"] = "Success";
        else:
          $conn->rollBack();
          $_SESSION["client"]["data"]["error"] = 1;
          $_SESSION["client"]["data"]["errorText"] = "Failed ";
        endif;
      endif;
    elseif (route(3) == "delete"):
      $id = route(4);
      $delete = $conn->prepare("DELETE FROM blogs WHERE id=:id ");
      $delete = $delete->execute(array("id" => $id));
      if ($delete):
        header("Location:" . site_url("admin/appearance/blog"));
        $_SESSION["client"]["data"]["success"] = 1;
        $_SESSION["client"]["data"]["successText"] = "Success";
      else:
        $_SESSION["client"]["data"]["error"] = 1;
        $_SESSION["client"]["data"]["errorText"] = "Failed ";
      endif;


    elseif (route(3) == "edit"):
      if ($_POST):
        $id = route(4);
        foreach ($_POST as $key => $value) {
          $$key = $value;
        }

        if ($content == "<br>"):
          $content = "";
        endif;
        if ($url == "<br>"):
          $content = "";
        endif;
        if (empty($url)):
          header("Location:" . site_url("admin/appearance/blog/edit/$id"));
          $_SESSION["client"]["data"]["error"] = 1;
          $_SESSION["client"]["data"]["errorText"] = "Blog title cannot be empty";
        elseif (empty($title)):
          header("Location:" . site_url("admin/appearance/blog/edit/$id"));
          $_SESSION["client"]["data"]["error"] = 1;
          $_SESSION["client"]["data"]["errorText"] = "Blog title cannot be empty";
        elseif (empty($content)):
          header("Location:" . site_url("admin/appearance/blog/edit/$id"));
          $_SESSION["client"]["data"]["error"] = 1;
          $_SESSION["client"]["data"]["errorText"] = "Blog content cannot be empty";
        else:


          $update = $conn->prepare("UPDATE blogs SET title=:title , blog_get=:get , status=:status  , updated_at=:at , image_file=:link , content=:content WHERE id=:id ");
          $update->execute(array("id" => $id, "title" => $title, "link" => $url, "get" => $blogurl, "status" => $status, "at" => date('Y-m-d h:i:s'), "content" => $content));

          if ($update):
            header("Location:" . site_url("admin/appearance/blog"));
            $_SESSION["client"]["data"]["success"] = 1;
            $_SESSION["client"]["data"]["successText"] = "Success";
          else:
            $_SESSION["client"]["data"]["error"] = 1;
            $_SESSION["client"]["data"]["errorText"] = "Failed ";
          endif;
        endif;

      endif;



    endif;



    if (route(5)):
      header("Location:" . site_url("admin/appearance/blog"));
    endif;
  endif;



elseif (route(2) == "files"):

  $access = $admin["access"]["files"];

  if ($access):
    if ($_FILES["logo"]):
      // শুধুমাত্র নির্ধারিত ফরম্যাটের চেক
      if ($_FILES["logo"] && ($_FILES["logo"]["type"] == "image/jpeg" || $_FILES["logo"]["type"] == "image/jpg" || $_FILES["logo"]["type"] == "image/png" || $_FILES["logo"]["type"] == "image/gif")):
        $logo_name = $_FILES["logo"]["name"];
        
        // PHP কোড থাকা চেক
        if (strpos($logo_name, "php") !== false) {
          exit;
        }

        // লোগোর সাইজ বের করা (KB তে)
        $logo_size = round($_FILES["logo"]["size"] / 1024, 2); // সাইজ KB তে
        
        // লোগোর নতুন নাম তৈরি করা (১৬ অক্ষর, নম্বর, ছোট ও বড় হাতের অক্ষর মিশ্রিত)
        $logo_newname = "img/files/" . substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"), 0, 16) . ".png";
        
        // লোগো আপলোড করা
        $upload_logo = move_uploaded_file($_FILES["logo"]["tmp_name"], $logo_newname);

        // আপলোড URL তৈরি করা
        $url = site_url($logo_newname);

        // ডাটাবেজে সংরক্ষণ
        $insert = $conn->prepare("INSERT INTO files SET link=:link, size=:size, date=:date");
        $insert = $insert->execute(array(
          "link" => $url,
          "size" => $logo_size, // সাইজ সংরক্ষণ
          "date" => date("Y-m-d H:i:s")
        ));
      endif;

    endif;

    // ফাইল লিস্ট দেখানো
    $fileList = $conn->prepare("SELECT * FROM files ORDER BY date DESC ");
    $fileList->execute(array());
    $fileList = $fileList->fetchAll(PDO::FETCH_ASSOC);

    // ফাইল ডিলিট ফিচার
    if (route(3) == "delete"):
      $id = route(4);

      if (countRow(["table" => "files", "where" => ["id" => $id]])):
        $delete = $conn->prepare("DELETE FROM files WHERE id=:id ");
        $delete->execute(array("id" => $id));
      endif;

      header("Location:" . site_url("admin/appearance/files"));
      exit();
    endif;

  endif;
endif;


      
      
      if( route(2) == "whatsapp-telegram" ):
   $access = $admin["access"]["pages"];

      if( $access ):
        if( $_POST ):
          $conn->beginTransaction();
          $update = $conn->prepare("UPDATE settings SET 
          whatsappbutton=:whatsappbutton,
          whatsappnumber=:whatsappnumber,
          whatsappcolour=:whatsappcolour,
          whatsappposition=:whatsappposition,
          telegrambutton=:telegrambutton,
          telegramusername=:telegramusername,
          telegramposition=:telegramposition,
          theme_bg_img=:psw_img
           WHERE id=:id ");
          $update = $update->execute(array("id"=>1,
          "whatsappbutton" => $_POST['whatsappbutton'],
          "whatsappnumber" => $_POST['whatsappnumber'],
          "whatsappcolour" => $_POST['whatsappcolour'],
          "whatsappposition" => $_POST['whatsappposition'],
          "telegrambutton" => $_POST['telegrambutton'],
          "telegramusername" => $_POST['telegramusername'],
          "telegramposition" => $_POST['telegramposition'],
          "psw_img" => $_POST['psw_img']));
          if( $update ):
            $conn->commit();
            header("Location:".site_url("admin/appearance/whatsapp-telegram"));
            $_SESSION["client"]["data"]["success"]    = 1;
            $_SESSION["client"]["data"]["successText"]= "Success";
          else:
            $conn->rollBack();
            $error    = 1;
            $errorText= "Failed";
          endif;
        endif;
      endif;  endif;
      




if (route(2) == "new_year"):

  $access = $admin["access"]["new_year"];


  if ($access):
    if ($_POST):
      foreach ($_POST as $key => $value) {
        $$key = $value;
      }
      $conn->beginTransaction();
      $update = $conn->prepare("UPDATE decoration SET 
          fire_works=:fire_works,
          snowflakes=:snowflakes,
          garlands=:garlands,snow_colour=:snow_colour,
          toys=:toys,
          toy_a=:toy_a,
          toy_b=:toy_b,
          toy_c=:toy_c,
          toy_d=:toy_d,
          toy_e=:toy_e,
          toy_f=:toy_f,
          toy_g=:toy_g,
          toy_h=:toy_h,
          toy_i=:toy_i,
          toy_j=:toy_j,
          toy_k=:toy_k,
          toy_l=:toy_l,
          toy_size=:toy_size,
          toy_quantity=:toy_quantity,
          toy_speed=:toy_speed,
          toy_launch=:toy_launch,
          fire_speed=:fire_speed,
          fire_size=:fire_size,
          gar_style=:gar_style,
          gar_shape=:gar_shape,
          snow_speed=:snow_speed,
          snowflakes=:snowflakes,
          snow_fall=:snow_fall
          WHERE id=:id ");
      $update = $update->execute(
        array(
          "id" => 1,
          "snow_fall" => $snow_fall,
          "snow_colour" => $snow_color,
          "garlands" => $garlands,
          "fire_works" => $fire_works,
          "fire_speed" => $fire_speed,
          "fire_size" => $fire_size,
          "gar_style" => $gar_style,
          "gar_shape" => $gar_shape,
          "snow_speed" => $snow_speed,
          "snowflakes" => $snowflakes,
          "toys" => $toys,
          "toy_a" => $toy_a,
          "toy_b" => $toy_b,
          "toy_c" => $toy_c,
          "toy_d" => $toy_d,
          "toy_e" => $toy_e,
          "toy_f" => $toy_f,
          "toy_g" => $toy_g,
          "toy_h" => $toy_h,
          "toy_i" => $toy_i,
          "toy_j" => $toy_j,
          "toy_k" => $toy_k,
          "toy_l" => $toy_l,
          "toy_size" => $toy_size,
          "toy_quantity" => $toy_quantity,
          "toy_speed" => $toy_speed,
          "toy_launch" => $toy_launch
        )
      );
      if ($update):
        $conn->commit();
        header("Location:" . site_url("admin/appearance/new_year"));
        $_SESSION["client"]["data"]["success"] = 1;
        $_SESSION["client"]["data"]["successText"] = "Success";
      else:
        $conn->rollBack();
        $error = 1;
        $errorText = "Failed";
      endif;
    endif;
  endif;
endif;

require admin_view('appearance');