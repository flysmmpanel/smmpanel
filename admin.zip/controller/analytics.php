<?php
if(!defined("BASEPATH")){
    die("Direct access not permitted");
}

$data["page_title"] = "Analytics Dashboard";

require admin_view("analytics");
