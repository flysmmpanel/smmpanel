<?php
define('PATH', realpath('.'));
define('SUBFOLDER', false);
define('URL', 'https://zexsmm.com' );
define('STYLESHEETS_URL', '//zexsmm.com' );
date_default_timezone_set('Asia/Dhaka');

 

error_reporting(0);
return [
  'db' => [
    'name'    =>  'u348658193_zex' ,
    'host'    =>  'localhost',
    'user'    =>  'u348658193_zexsmm' ,
    'pass'    =>  'a2+L?bxe2Q' ,
    'charset' =>  'utf8mb4'
  ]
];

?>