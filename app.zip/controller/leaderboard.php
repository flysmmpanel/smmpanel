<?php
if(!defined('BASEPATH')) {
    die('Direct access not allowed');
}

$title .= "Leaderboard";

if($user["client_type"] == 1){
    header("Location:".site_url('logout'));
    exit;
}

// Temporary test data
$top_users = [
    ["username" => "Ali", "points" => 1200],
    ["username" => "Ahmed", "points" => 980],
    ["username" => "Usman", "points" => 750],
];
