<?php
if(!defined('BASEPATH')) die('Direct access not allowed');

class NewGiveaways extends Controller {

    // Show active giveaways
    public function index() {
        $giveaways = $this->db->query("SELECT * FROM giveaways2 WHERE status='active' ORDER BY end_date ASC")->fetchAll();
        return view('app/new_giveaways.twig', ['giveaways' => $giveaways]);
    }

    // Join a giveaway
    public function join($giveaway_id, $user_id) {
        $exists = $this->db->query("SELECT * FROM giveaway_participants2 WHERE giveaway_id=$giveaway_id AND user_id=$user_id")->fetch();
        if(!$exists) {
            $stmt = $this->db->prepare("INSERT INTO giveaway_participants2 (giveaway_id, user_id) VALUES (?, ?)");
            $stmt->execute([$giveaway_id, $user_id]);
        }
        header("Location: " . site_url("app/newgiveaways"));
    }
}
