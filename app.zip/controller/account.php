<?php
if(!defined('BASEPATH')) {
   die('Direct access to the script is not allowed');
}
if( $panel["panel_status"] == "suspended" ): include 'app/views/frozen.twig';exit(); endif;
if( $panel["panel_status"] == "frozen" ): include 'app/views/frozen.twig';exit(); endif;
$title .= $languageArray["account.title"];

if( $_SESSION["msmbilisim_userlogin"] != 1  || $user["client_type"] == 1  ){
  header("Location:".site_url('logout'));
}
if(route(1) == "change_currency"){
  
$rate_key = $_POST["rate_key"];
$rate_sym = $_POST["sym"];

$currencies = $conn->prepare("SELECT * FROM currencies WHERE is_enable=1");
$currencies->execute();
$currencies = $currencies->fetchAll(PDO::FETCH_ASSOC);
$currencies = array_group_by($currencies,"currency_code");

if(array_key_exists($rate_key,$currencies) && $settings["site_currency_converter"] == "1"){
 $update = $conn->prepare("UPDATE clients SET currency_type=:currency_type WHERE client_id=:id ");
 $update = $update->execute(array("id"=>$user["client_id"],"currency_type"=>$rate_key));

$resp = array(
"success" => true,
"message" => "Success"
);

setcookie("currency_hash",get_currency_hash_by_code($rate_key),strtotime('+28 days'),'/',null,null,true);
}
else {
header("Location:".site_url(''));
}
 } elseif( route(1) == "newapikey" ){
    $conn->beginTransaction();
    $insert= $conn->prepare("INSERT INTO client_report SET client_id=:c_id, action=:action, report_ip=:ip, report_date=:date ");
    $insert= $insert->execute(array("c_id"=>$user["client_id"],"action"=>"API Key changed","ip"=>GetIP(),"date"=>date("Y-m-d H:i:s") ));
    $apikey = CreateApiKey(["email"=>$user["email"],"username"=>$user["username"]]);
    // $update = $conn->prepare("UPDATE clients SET apikey=:key WHERE client_id=:id ");
    $update = $conn->prepare("
  UPDATE clients 
  SET apikey=:key, apikey_created_at = NOW() 
  WHERE client_id=:id
");
    $update = $update->execute(array("id"=>$user["client_id"],"key"=>$apikey ));
    
    if( $update ):
if ($settings["alert_apimail"] == "2") {
    $htmlContent = '
    <html>
        <head>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    line-height: 1.6;
                    color: #333;
                    background-color: #f3f3f3;
                    margin: 0;
                    padding: 0;
                }
                .container {
                    max-width: 600px;
                    margin: 20px auto;
                    padding: 20px;
                    border: 1px solid #ddd;
                    border-radius: 8px;
                    background-color: #ffffff;
                    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                }
                .header {
                    background-color: #4CAF50;
                    color: white;
                    padding: 20px;
                    text-align: center;
                    border-radius: 8px 8px 0 0;
                    font-size: 24px;
                }
                .content {
                    padding: 20px;
                    font-size: 16px;
                    color: #555;
                }
                .content p {
                    margin: 10px 0;
                }
                .footer {
                    margin-top: 20px;
                    padding: 10px;
                    text-align: center;
                    font-size: 12px;
                    color: #999;
                    border-top: 1px solid #ddd;
                }
                .button {
                    display: inline-block;
                    margin: 20px 0;
                    padding: 10px 20px;
                    background-color: #4CAF50;
                    color: white;
                    text-decoration: none;
                    border-radius: 4px;
                    font-size: 16px;
                }
                .button:hover {
                    background-color: #45a049;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    ' . htmlspecialchars($settings["site_name"]) . '
                </div>
                <div class="content">
                    <p>Dear ' . htmlspecialchars($user["username"]) . ',</p>
                    <p>We wanted to inform you that your API key has been successfully changed.</p>
                    <p>If this action was performed by you, no further action is needed. However, if you did not initiate this change, please <strong>update your account password</strong> and <strong>regenerate your API key</strong> immediately to secure your account.</p>
                    <p>For any further assistance, feel free to contact our support team.</p>
                    <a href="' . htmlspecialchars($settings["support_url"]) . '" class="button">Contact Support</a>
                    <p>Thank you for using our service!</p>
                    <p>Best regards,</p>
                    <p>The ' . htmlspecialchars($settings["site_name"]) . ' Team</p>
                </div>
                <div class="footer">
                    &copy; ' . date("Y") . ' ' . htmlspecialchars($settings["site_name"]) . '. All rights reserved.
                </div>
            </div>
        </body>
    </html>';

    $site_name = $settings["site_name"];
    $to = $user["email"];
    $from = $settings["smtp_user"];
    $fromName = $settings["site_title"];
    $subject = "API Key Changed";
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8" . "\r\n";
    $headers .= 'From: ' . $fromName . '<' . $from . '>' . "\r\n";

    if (mail($to, $subject, $htmlContent, $headers)) {
        // Email sent successfully
    } else {
        // Email sending failed
    }
}
$conn->commit();
$success = 1;
$successText = "API key has been generated: $apikey";
else:
$conn->rollBack();
$error = 1;
$errorText = "API key has not changed, Try again later!";
endif;
  
}elseif( route(1) == "change_lang" && $_POST ){
    $lang     = $_POST["lang"];
    $update = $conn->prepare("UPDATE clients SET lang=:lang WHERE client_id=:id ");
    $update = $update->execute(array("id"=>$user["client_id"],"lang"=>$lang ));
    header("Location:".site_url('account'));
}elseif( route(1) == "currency" && $_POST ){
$conn->beginTransaction();
    $currency    = $_POST["currency"];
    $update = $conn->prepare("UPDATE clients SET currency=:type WHERE client_id=:id ");
    $update = $update->execute(array("id"=>$user["client_id"],"type"=>$currency ));
    
    header("Location:".site_url('account'));
}elseif( route(1) == "timezone" && $_POST ){


    $timezone = $_POST["timezone"]; 
    $timezone = doubleval($timezone);
    $update   = $conn->prepare("UPDATE clients SET timezone=:timezone WHERE client_id=:id ");
    $update   = $update->execute(array("id"=>$user["client_id"],"timezone"=>$timezone ));
    header("Location:".site_url('account'));
// }elseif( route(0) == "account" && $_POST ){
}elseif( route(0) == "account" && !route(1) && $_POST ){

  $pass     = $_POST["current_password"];
  $new_pass = $_POST["password"];
  $new_again= $_POST["confirm_password"];

  if( !userdata_check('password',md5($pass) ) ){
    $error    = 1;
    $errorText= $languageArray["error.account.password.notmach"];
  }elseif( strlen($new_pass) < 8 ){
    $error    = 1;
    $errorText= $languageArray["error.account.password.length"];
  }elseif( $new_pass != $new_again ){
    $error    = 1;
    $errorText= $languageArray["error.account.passwords.notmach"];
  }else{
    $conn->beginTransaction();
      $insert= $conn->prepare("INSERT INTO client_report SET client_id=:c_id, action=:action, report_ip=:ip, report_date=:date ");
      $insert= $insert->execute(array("c_id"=>$user["client_id"],"action"=>"User password has been changed","ip"=>GetIP(),"date"=>date("Y-m-d H:i:s") ));
      $update = $conn->prepare("UPDATE clients SET password=:pass WHERE client_id=:id ");
      $update = $update->execute(array("id"=>$user["client_id"],"pass"=>md5($new_pass) ));
        if( $update && $insert ):
          $_SESSION["msmbilisim_userpass"]       = md5($new_pass);
          

          $conn->commit();
          $success    = 1;
          $successText= $languageArray["error.account.password.success"];

        else:
          $conn->rollBack();
          $error    = 1;
          $errorText= $languageArray["error.account.password.fail"];
        endif;
  }

}

elseif( route(1) == "change-email" && $_POST ){
    $newemail = $_POST["newemail"];
    $current_pass = $_POST["current_password_for_email"];

    if (empty($newemail) || !filter_var($newemail, FILTER_VALIDATE_EMAIL)) {
        $error = 1;
        $errorText = "Please enter a valid email address.";
    } elseif (userdata_check("email", $newemail)) {
        $error = 1;
        $errorText = "This email is already registered with another account.";
    } elseif (md5($current_pass) != $user["password"]) {
        $error = 1;
        $errorText = "Incorrect current password.";
    } else {
        // Naye email ko base64 encode kar rahe hain taake URL mein bhej saken
        $encoded_email = base64_encode($newemail);
        // Activation link: confirm_email controller mein 'verify-change' handle karega
        $confirm_url = site_url()."confirm_email/verify-change/".$user['apikey']."?mail=".$encoded_email;
        
        $site_name = $settings["site_name"];
        $subject = "Confirm Your New Email Address";
        
        $htmlContent = "
            <div style='font-family: Arial, sans-serif; padding: 20px; border: 1px solid #eee; border-radius: 10px;'>
                <h2>Email Change Request</h2>
                <p>Hello <b>" . $user['username'] . "</b>,</p>
                <p>We received a request to change your account email to: <b>$newemail</b></p>
                <p>To complete this change, please click the button below:</p>
                <a href='$confirm_url' style='background: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;'>Confirm New Email</a>
                <p>If you did not request this, please ignore this email. Your current email will remain active.</p>
                <p>Best regards,<br>$site_name Team</p>
            </div>";

        $from = $settings["smtp_user"];
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type: text/html; charset=UTF-8" . "\r\n";
        $headers .= "From: $site_name <$from>" . "\r\n";

        if (mail($newemail, $subject, $htmlContent, $headers)) {
            $success = 1;
            $successText = "A confirmation link has been sent to <b>$newemail</b>. Please check your inbox.";
        } else {
            $error = 1;
            $errorText = "Failed to send confirmation email. Please contact support.";
        }
    }
}

// ✅ API Key Created Date Fetch
$row = $conn->prepare("SELECT apikey_created_at FROM clients WHERE client_id=:id");
$row->execute(["id"=>$user["client_id"]]);
$data = $row->fetch(PDO::FETCH_ASSOC);

$created_at = $data["apikey_created_at"];

// Optional formatting (recommended)
if($created_at){
    $created_at = date("d M Y, h:i A", strtotime($created_at));
}

