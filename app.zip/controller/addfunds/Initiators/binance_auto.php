<?php
if (!defined('ADDFUNDS')) {
    http_response_code(404);
    die();
}

function GetBinanceData($params,$endpoint,$api_key,$secret_key){

$query_string = http_build_query($params);
$query_string = str_replace('+',' ', $query_string);

$signature = hash_hmac('sha256', $query_string, $secret_key);
$params['signature'] = $signature; 


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $endpoint . '?' . http_build_query($params));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'X-MBX-APIKEY: ' . $api_key,
]);


$response = curl_exec($ch);

if (curl_errno($ch)) {
    echo 'Error: ' . curl_error($ch);
    exit;
}


curl_close($ch);

$data = json_decode($response, true);

return $data;
    
}


function search_tid($tid,$data){

     foreach ( $data as $d){
         if($d['orderId'] === $tid){
             return $d;
         }
     }
     return false;
 }


$api_key = $methodExtras["api_key"];
$secret_key = $methodExtras["secret_key"];


$binance_tid = htmlspecialchars(trim($_POST["BinanceTransactionId"]));
if(!is_numeric($binance_tid)){
    errorExit('Invalid Binance ID');
}
if (empty($binance_tid)) {
    errorExit("The Transaction ID cannot be empty.");
}

if (
    !countRow([
        'table' => 'payments',
        'where' => [
            'payment_extra' => $binance_tid,
            "payment_status" => 3,
            "payment_delivery" => 2
        ]
    ])
) {


    $txnid_to_check = $binance_tid;
    
$amount = $paymentAmount;
$endpoint = 'https://api3.binance.com/sapi/v1/pay/transactions';

$params = [
    'timestamp' => time() * 1000,
    'status' => '1',
    'startTime' => (time() - 604800) * 1000, // 7 days ago
    'endTime' => time() * 1000, // Current time
];

 
 $data = GetBinanceData($params,$endpoint,$api_key,$secret_key);
 
$data = $data['data'];

$data = search_tid($txnid_to_check,$data);

if($data==false){
   errorExit('No order Found with This Order ID');
}else{
    if($data['currency'] != 'USDT'){
       errorExit('You Paid Amount in Wrong Currency. Kindly Pay only in USDT'); 
    }
    if($data['orderId']== $txnid_to_check){
       if($amount == $data['amount']){
           
    $insert = $conn->prepare(
        "INSERT INTO payments SET
    client_id=:client_id,
    payment_amount=:amount,
    payment_method=:method,
    payment_mode=:mode,
    payment_create_date=:date,
    payment_ip=:ip,
    payment_extra=:extra"
    );
    $insert->execute([
        "client_id" => $user["client_id"],
        "amount" => $paymentAmount,
        "method" => $methodId,
        "mode" => "Automatic",
        "date" => date("Y.m.d H:i:s"),
        "ip" => GetIP(),
        "extra" => $binance_tid
    ]);

    $paymentId = $conn->lastInsertId();
    
    $paidAmount = floatval($paymentAmount);
        if($paymentFee > 0){
          $fee = ($paidAmount * ($paymentFee / 100));
          $paidAmount = $paidAmount - $fee;
        }
        if($paymentBonusStartAmount != 0 && $paidAmount > $paymentBonusStartAmount){
            $bonus = $paidAmount * ($paymentBonus / 100);
            $paidAmount = $paidAmount + $bonus;
        }       

        $paidAmount = from_to($currencies_array, $methodCurrency, $settings["site_base_currency"], $paidAmount);

        $update = $conn->prepare('UPDATE payments SET 
        client_balance=:balance, 
        payment_amount=:payment_amount, 
        payment_status=:status, 
        payment_delivery=:delivery WHERE payment_id=:id');
        $update->execute(
            [
                'balance' => $user['balance'],
                "payment_amount" => $paidAmount,
                'status' => 3,
                'delivery' => 2,
                'id' => $paymentId
            ]
        );
        $updateBalance = $conn->prepare("UPDATE clients SET balance=:balance WHERE client_id=:id");
        $updateBalance->execute([
            "balance" => $user["balance"] + $paidAmount,
            "id" => $user["client_id"]
        ]);

        $redirectForm .= '<script type="text/javascript">window.location.rel1oad();</script>';

        $response["success"] = true;
        $response["message"] = "The transaction ID is verified and the money has been added to your account.";
        $response["content"] = $redirectForm;
           
       }else{
          errorExit('Amount was Not Matched. Kindly Resubmit with Correct Amount');
       }
    }else{
        errorExit('Transaction Details Not found');
    }
}


} else {
    errorExit("This Transaction ID is already used.");
}
?>