<?php
if (!defined('ADDFUNDS')) {
    http_response_code(404);
    die();
}

$email = $methodExtras["email"];
$password = $methodExtras["password"];
$senderEmail = $methodExtras["senderEmail"];
$mailserver = $methodExtras['mailserver'] ?? 'imap.gmail.com'; // ✅ dynamic

$EasypaisaTransactionId = htmlspecialchars(trim($_POST["EasypaisaTransactionId"]));

if (empty($EasypaisaTransactionId)) {
    errorExit("The Transaction ID cannot be empty.");
}

if (
    !countRow([
        'table' => 'payments',
        'where' => [
            'payment_extra' => $EasypaisaTransactionId,
            "payment_status" => 3,
            "payment_delivery" => 2
        ]
    ])
) {

    $hostname = '{' . $mailserver . ':993/imap/ssl/novalidate-cert}'; // ✅ dynamic
    $inbox = imap_open($hostname, $email, $password) or die('Cannot connect to Gmail: ' . imap_last_error());

    // ✅ Trx ID se search
    $emails = imap_search($inbox, 'TEXT "' . $EasypaisaTransactionId . '"', SE_FREE, "UTF-8");

    $transaction = array();

    // ✅ null check
    if ($emails && count($emails) > 0) {
        rsort($emails); // latest pehle
        foreach ($emails as $email_id) {
            $header = imap_headerinfo($inbox, $email_id);
            $sender = $header->from[0]->mailbox . "@" . $header->from[0]->host;
            $body = imap_fetchbody($inbox, $email_id, 1);

            // ✅ Trx ID match karo
            if (!preg_match('/Trx ID\s+' . preg_quote($EasypaisaTransactionId, '/') . '/i', $body)) {
                continue;
            }

            // ✅ Amount extract - "You have Received Rs 2208"
            if (preg_match('/You have Received Rs\s*([0-9,]+(\.[0-9]+)?)/i', $body, $amt_match)) {
                $amount = str_replace(',', '', $amt_match[1]);
            } else {
                continue;
            }

            // ✅ Sender check
            if ($sender != $senderEmail) {
                continue;
            }

            $transaction["amount"] = $amount;
            $transaction["sender"] = $sender;
            $transaction["tid"] = $EasypaisaTransactionId;
            break;
        }
    }

    imap_close($inbox);

    // ✅ proper undefined check
    if (empty($transaction) || !isset($transaction["tid"])) {
        errorExit("This Transaction ID was not found, please try again later.");
    }

    // ✅ amount match
    if (floatval($transaction["amount"]) != floatval($paymentAmount)) {
        errorExit("The amount you entered seems to be invalid.");
    }

    $insert = $conn->prepare(
        "INSERT INTO payments SET
        client_id=:client_id,
        payment_amount=:amount,
        payment_method=:method,
        payment_mode=:mode,
        payment_create_date=:date,
        payment_ip=:ip,
        payment_extra=:extra"
    );
    $insert->execute([
        "client_id" => $user["client_id"],
        "amount" => $paymentAmount,
        "method" => $methodId,
        "mode" => "Automatic",
        "date" => date("Y.m.d H:i:s"),
        "ip" => GetIP(),
        "extra" => $EasypaisaTransactionId
    ]);

    $paymentId = $conn->lastInsertId();

    $paidAmount = floatval($paymentAmount);
    if ($paymentFee > 0) {
        $fee = ($paidAmount * ($paymentFee / 100));
        $paidAmount = $paidAmount - $fee;
    }
    if ($paymentBonusStartAmount != 0 && $paidAmount > $paymentBonusStartAmount) {
        $bonus = $paidAmount * ($paymentBonus / 100);
        $paidAmount = $paidAmount + $bonus;
    }

    $paidAmount = from_to($currencies_array, $methodCurrency, $settings["site_base_currency"], $paidAmount);

    $update = $conn->prepare('UPDATE payments SET 
        client_balance=:balance, 
        payment_amount=:payment_amount, 
        payment_status=:status, 
        payment_delivery=:delivery WHERE payment_id=:id');
    $update->execute([
        'balance' => $user['balance'],
        "payment_amount" => $paidAmount,
        'status' => 3,
        'delivery' => 2,
        'id' => $paymentId
    ]);

    $updateBalance = $conn->prepare("UPDATE clients SET balance=:balance WHERE client_id=:id");
    $updateBalance->execute([
        "balance" => $user["balance"] + $paidAmount,
        "id" => $user["client_id"]
    ]);

    $redirectForm .= '<script type="text/javascript">window.location.reload();</script>'; // ✅ typo fix

    $response["success"] = true;
    $response["message"] = "The transaction ID is verified and the money has been added to your account.";
    $response["content"] = $redirectForm;

} else {
    errorExit("This Transaction ID is already used.");
}
?>