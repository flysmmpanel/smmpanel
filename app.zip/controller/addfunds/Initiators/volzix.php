<?php

/*

 * - by DEV IMON
 

 */

function volzix_init_payment($merchant_mid, $secret_key, array $payload)
{
    $timestamp   = $payload["timestamp"];
    $amount      = $payload["amount"]; // formatted to 2 decimals
    $currency    = $payload["currency"];
    $web_id      = $payload["web_id"];
    $payer_email = $payload["payer_email"];

    $signing_string = $merchant_mid . "|" . $amount . "|" . $currency . "|" . $web_id . "|" . $payer_email . "|" . $timestamp;
    $signature = hash_hmac("sha256", $signing_string, $secret_key);

    $request_body = [
        "merchant_mid" => $merchant_mid,
        "amount"       => $amount,
        "currency"     => $currency,
        "payer_email"  => $payer_email,
        "web_id"       => $web_id,
        "return"       => $payload["return_url"],
        "timestamp"    => $timestamp,
        "signature"    => $signature
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://volzix.com/auth/");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($request_body));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);

    $result    = curl_exec($ch);
    $curl_err  = curl_error($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($result === false) {
        return ["ok" => false, "error" => $curl_err ?: "cURL error"];
    }

    $resp = json_decode($result, true);
    if (!is_array($resp)) {
        return ["ok" => false, "error" => "Invalid JSON response", "raw" => $result];
    }

    if (($resp["status"] ?? "") !== "ok" || empty($resp["payment_url"]) || empty($resp["flow_id"])) {
        return [
            "ok"        => false,
            "error"     => $resp["message"] ?? "Volzix init failed",
            "resp"      => $resp,
            "http_code" => $http_code
        ];
    }

    return [
        "ok"          => true,
        "payment_url" => $resp["payment_url"],
        "flow_id"     => $resp["flow_id"],
        "resp"        => $resp
    ];
}

// --- Credentials ---
$merchant_mid = $methodExtras["merchant_mid"] ?? "";
$secret_key   = $methodExtras["secret_key"] ?? "";

if (!$merchant_mid || !$secret_key) {
    errorExit("Volzix is not configured. Please contact the administrator.");
}

// --- Generate unique merchant reference (web_id) ---
$basket_id = rand(11111111, 99999999) . time();

// Amount entered by user is in method currency
$gateway_amount = number_format((float)$paymentAmount, 2, ".", "");
$currency       = $methodCurrency ?: "PKR";

// Store platform amount in site base currency
$internal_amount = from_to($currencies_array, $methodCurrency, $settings["site_base_currency"], $paymentAmount);

// Return URL
$return_url = site_url("volzix_return") . "?web_id=" . urlencode($basket_id);

// Prefer actual user email
$payer_email = $user["email"] ?? ($user["client_email"] ?? "customer@example.com");

// Init request
$init = volzix_init_payment($merchant_mid, $secret_key, [
    "amount"      => $gateway_amount,
    "currency"    => $currency,
    "web_id"      => (string)$basket_id,
    "payer_email" => (string)$payer_email,
    "return_url"  => $return_url,
    "timestamp"   => time()
]);

if (!$init["ok"]) {
    error_log("Volzix init failed: " . json_encode([
        "http_code" => $init["http_code"] ?? null,
        "error"     => $init["error"] ?? null,
        "resp"      => $init["resp"] ?? null,
    ]));
    errorExit("Something went wrong while initiating payment.");
}

$flow_id     = $init["flow_id"];
$payment_url = $init["payment_url"];

// --- Save payment as pending ---
$insert = $conn->prepare(
    "INSERT INTO payments SET
        client_id=:client_id,
        client_balance=:balance,
        payment_amount=:amount,
        payment_method=:method,
        payment_status=:status,
        payment_mode=:mode,
        payment_create_date=:date,
        payment_ip=:ip,
        payment_extra=:extra,
        t_id=:t_id,
        trx_id=:trx_id"
);

$extra = json_encode([
    "web_id"         => (string)$basket_id,
    "flow_id"        => (string)$flow_id,
    "gateway_amount" => $gateway_amount,
    "currency"       => $currency
]);

$insert->execute([
    "client_id" => $user["client_id"],
    "balance"   => $user["balance"],
    "amount"    => $internal_amount,
    "method"    => $methodId,
    "status"    => 1,
    "mode"      => "Automatic",
    "date"      => date("Y.m.d H:i:s"),
    "ip"        => GetIP(),
    "extra"     => $extra,
    "t_id"      => (string)$basket_id,
    "trx_id"    => (string)$flow_id,
]);

$redirectForm = '<script type="text/javascript">window.location = "' . $payment_url . '";</script>';

$response["success"] = true;
$response["message"] = "Your payment has been initiated and you will now be redirected to the payment gateway." . $redirectForm;
$response["content"] = $redirectForm;
?>
