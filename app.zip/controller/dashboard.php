<?php
if(!defined('BASEPATH')) {
    die('Direct access not allowed');
}

$title .= isset($languageArray["dashboard.title"]) && !empty($languageArray["dashboard.title"])
    ? $languageArray["dashboard.title"]
    : "Dashboard";

if($user["client_type"] == 1){
    header("Location:".site_url('logout'));
    exit;
}

/* ================= FUNCTIONS ================= */
$twig->addFunction(new \Twig\TwigFunction('getOrderCount', function($clientId) use ($db) {
    return countRow(["table"=>"orders","where"=>["client_id"=>$clientId]]);
}));

/* ================= BASE VALUE ================= */
$spent_base = (float) $user["spent"];

/* ================= CURRENCIES ================= */
$currencies = get_currencies_array("enabled");

/* ================= CONVERT VALUE ================= */
$spent_display = from_to(
    $currencies,
    $settings["site_base_currency"],
    $user["currency_type"],
    $spent_base
);

/* ================= GET SYMBOL (SAFE) ================= */
$symbol = "$";
foreach ($currencies as $group) {
    foreach ($group as $currency) {
        if (strtoupper($currency["currency_code"]) === strtoupper($user["currency_type"])) {
            $symbol = $currency["currency_symbol"];
            break 2;
        }
    }
}

/* ================= LEVEL THRESHOLDS ================= */
$bronze   = from_to($currencies, $settings["site_base_currency"], $user["currency_type"], $settings["bronz_statu"]);
$silver   = from_to($currencies, $settings["site_base_currency"], $user["currency_type"], $settings["silver_statu"]);
$gold     = from_to($currencies, $settings["site_base_currency"], $user["currency_type"], $settings["gold_statu"]);
$reseller = from_to($currencies, $settings["site_base_currency"], $user["currency_type"], $settings["bayi_statu"]);

/* ================= LEVEL BENEFITS ================= */
$level_benefits = [
    "Bronze Member" => [
        "Normal Live Chat Support",
        "Normal Order Handling",
        "Normal Problem Support",
    ],
    "Silver Member" => [
        "WhatsApp Support",
        "Normal Order Handling",
        "Normal Issues Support",
        "2% Bonus on Every Payment",
    ],
    "Gold Member" => [
        "WhatsApp 24/7 Support",
        "Direct Admin Contact",
        "Best Support",
        "Best Order Handling",
        "3% Bonus on All Payments",
        "2% Discount on All Services",
    ],
    "Reseller Member" => [
        "WhatsApp 24/7 Support",
        "Direct Admin Contact",
        "Best AI Support",
        "Refiller Access (Refill Completed in Minutes)",
        "Best Order Handling",
        "4% Bonus on All Payments",
        "5% Discount on All Services",
        "10% Discount on Special Services",
    ],
];

/* ================= STATUS LOGIC ================= */
$account_status = "Bronze Member";
$status_color   = "dark";
$next_level     = "";
$remaining      = 0;
$progress_start = 0;
$progress_end   = 0;

if ($spent_base >= $settings["bayi_statu"]) {
    $account_status = "Reseller Member";
    $status_color   = "primary";
    $next_level     = "Max Level";
    $remaining      = 0;
    $progress_start = $reseller;
    $progress_end   = $reseller;
} elseif ($spent_base >= $settings["gold_statu"]) {
    $account_status = "Gold Member";
    $status_color   = "warning";
    $next_level     = "Reseller Member";
    $remaining      = $reseller - $spent_display;
    $progress_start = $gold;
    $progress_end   = $reseller;
} elseif ($spent_base >= $settings["silver_statu"]) {
    $account_status = "Silver Member";
    $status_color   = "info";
    $next_level     = "Gold Member";
    $remaining      = $gold - $spent_display;
    $progress_start = $silver;
    $progress_end   = $gold;
} else {
    $account_status = "Bronze Member";
    $status_color   = "dark";
    $next_level     = "Silver Member";
    $remaining      = $silver - $spent_display;
    $progress_start = 0;
    $progress_end   = $silver;
}

/* ================= SAFE VALUES ================= */
$remaining     = round($remaining, 2);
$spent_display = round($spent_display, 2);

/* ================= CURRENT LEVEL BENEFITS ================= */
$current_benefits = $level_benefits[$account_status] ?? [];

/* ================= RECENT ORDERS WIDGET ================= */
$client_id = $user["client_id"];

$q_recent = $conn->prepare("SELECT orders.order_id, orders.service_id, orders.order_url, orders.order_quantity, 
    orders.order_charge, orders.order_status, orders.order_create, services.service_name
    FROM orders
    LEFT JOIN services ON services.service_id = orders.service_id
    WHERE orders.client_id = :cid
    ORDER BY orders.order_id DESC
    LIMIT 8");
$q_recent->execute(['cid' => $client_id]);
$recent_orders_raw = $q_recent->fetchAll(PDO::FETCH_ASSOC);

$recent_orders = [];
foreach ($recent_orders_raw as $order) {
    $charge_display = round(from_to(
        $currencies,
        $settings["site_base_currency"],
        $user["currency_type"],
        (float) $order["order_charge"]
    ), 2);

    $recent_orders[] = [
        "order_id"     => $order["order_id"],
        "service_id"   => $order["service_id"],
        "service_name" => $order["service_name"] ?? ('Service #' . $order["service_id"]),
        "link"         => $order["order_url"],
        "quantity"     => $order["order_quantity"],
        "charge"       => $charge_display,
        "status"       => $order["order_status"],
        "date"         => date('Y-m-d H:i', strtotime($order["order_create"])),
    ];
}

/* ================= TWIG GLOBALS ================= */
$twig->addGlobal('account_status',   $account_status);
$twig->addGlobal('status_color',     $status_color);
$twig->addGlobal('next_level',       $next_level);
$twig->addGlobal('remaining',        $remaining);
$twig->addGlobal('progress_start',   $progress_start);
$twig->addGlobal('progress_end',     $progress_end);
$twig->addGlobal('user_spent',       $spent_display);
$twig->addGlobal('symbol',           $symbol);
$twig->addGlobal('level_benefits',   $level_benefits);
$twig->addGlobal('current_benefits', $current_benefits);
$twig->addGlobal('recent_orders',    $recent_orders);