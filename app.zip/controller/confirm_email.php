<?php
if(!defined('BASEPATH')) {
   die('Direct access to the script is not allowed');
}

$title .= "Confirm Email";

if( $_SESSION["msmbilisim_userlogin"] != 1  || $user["client_type"] == 1  ){
  Header("Location:".site_url('logout'));
}
if( $settings["email_confirmation"] == 1 && $user["email_type"] == 1  ){
  //Header("Location:".site_url(''));
}



            if( route(1) == "resend" ){
        $code = $user['apikey'];
        $to = $user['email'];
        $confirm_url = site_url()."confirm_email/activate/".$code;

        $update = $conn->prepare("UPDATE clients SET resend_max=resend_max+1 WHERE client_id=:id");
        $update->execute(array("id"=> $user["client_id"] )); 

        $subject = 'Email Confirmation - Resend';
        $message = "Please confirm email address for your account. <br><br> Click the link below to confirm: <br> <a href='$confirm_url'>$confirm_url</a>";
        
        // SMM Panels mein aksar 'mailphp' ya 'sendMail' function hota hai jo SMTP use karta hai
        // Agar aapka signup email chal raha hai, toh wahan check karein kaunsa function hai.
        // Filhal hum standard PHPMailer logic ke headers use kar rahe hain:
        
        $from = $settings["smtp_user"];
        $site_name = $settings["site_name"];

        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: $site_name <$from>" . "\r\n";

        // Agar simple mail() fail ho raha hai toh panel ka default 'sendMail' check karein
        $send = mail($to, $subject, $message, $headers);

        if( $send ){
            $success = 1;
            $successText = "A confirmation email has been sent to " . $to;
            echo '<script>setTimeout(function(){window.location="'.site_url('confirm_email').'"},2000)</script>';
        } else {
            $error = 1;
            $errorText = "Email sending failed. Please ensure SMTP is connected in Admin Settings.";
        }
    }

if( route(1) == "verify-change" ){
    // URL se apikey aur encoded email uthayein
    $apikey = route(2);
    $new_mail = base64_decode($_GET["mail"]);

    // Basic check: Email valid hai ya nahi
    if(!empty($new_mail) && filter_var($new_mail, FILTER_VALIDATE_EMAIL)){
        
        // Database mein email UPDATE karein
        $update = $conn->prepare("UPDATE clients SET email=:email WHERE apikey=:key");
        $update->execute(array("email" => $new_mail, "key" => $apikey));
        
        // Report mein entry dalein
        $insert_log = $conn->prepare("INSERT INTO client_report SET client_id=:c_id, action=:action, report_ip=:ip, report_date=:date");
        $insert_log->execute(array(
            "c_id" => $user["client_id"],
            "action" => "Email successfully changed to: " . $new_mail,
            "ip" => GetIP(),
            "date" => date("Y-m-d H:i:s")
        ));

        // User ko wapas account page par bhej dein success message ke sath
        header("Location: " . site_url('account')); 
        exit();
    } else {
        // Agar link kharab hai toh home par bhej dein
        header("Location: " . site_url(''));
        exit();
    }
}


    if( route(1) == "activate" ){
		
	
    $code = route(2);
    
        $update = $conn->prepare("UPDATE clients SET email_type=:type WHERE apikey=:key ");
        $update->execute(array("type"=> 2,"key"=> $code ));


    Header("Location:".site_url(''));
    exit();
  
} 
    

    
   if( $_POST ){
    foreach ($_POST as $key => $value) {
      $_SESSION["data"][$key]  = $value;
    }


$pass  = $_POST["password"];
$newemail  = $_POST["newemail"];
 if( empty($newemail) ){
        $error    = 1;
        $errorText= "Please enter a valid email";
} elseif( empty($pass) ){
        $error    = 1;
        $errorText= "Please enter your password";
  } elseif (userdata_check("email", $newemail)) {
    $error      = 1;
    $errorText  = "Email is already registered";
    // }elseif( !userlogin_check($user["username"],$pass) ){

    // $error      = 1;
    // $errorText  = "Incorrect password";
  } elseif ( md5($pass) != $user["password"] ) {
        // Agar user ka enter kiya gaya password session password se match nahi karta
        $error      = 1;
        $errorText  = "Incorrect password";




} else {
    // 1. Database mein email update karein
    $update = $conn->prepare("UPDATE clients SET email=:email, change_email=:mail WHERE client_id=:id");
    $update->execute(array("id"=> $user["client_id"], "mail"=> 1, "email"=> $newemail ));

    // 2. Activation Link tayyar karein
    $code = $user['apikey'];
    $confirm_url = site_url()."confirm_email/activate/".$code;
    
    // 3. HTML Message aur Headers
    $msg = "Please confirm email address for your account. <br><br> Click the link below to confirm your email: <br> <a href='$confirm_url'>$confirm_url</a>";
    
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: ".$settings["site_name"]." <".$settings["smtp_user"].">" . "\r\n";
       
    // 4. Email Send karein
    $send = mail($newemail, "Email Confirmation", $msg, $headers);

    // 5. Activity log insert karein
    $mail_old = $user["email"];
    $insert2 = $conn->prepare("INSERT INTO client_report SET client_id=:c_id, action=:action, report_ip=:ip, report_date=:date ");
    $insert2->execute(array(
        "c_id" => $user["client_id"],
        "action" => "User changed email from $mail_old to $newemail.",
        "ip" => GetIP(),
        "date" => date("Y-m-d H:i:s")
    ));
        
    if ($update && $send) {
        $success = 1;
        $successText = "A confirmation email has been sent to your new email address.";
        echo '<script>setTimeout(function(){window.location="'.site_url('confirm_email').'"},2000)</script>';
    } else {
        $error = 1;
        $errorText = "Failed to update email or send confirmation.";
    }
 }

}
 
 if( route(1) == "pause" ):
    $order_id = route(2);
    $row      =   $conn->prepare("SELECT * FROM orders WHERE order_id=:id && ( subscriptions_status=:status || subscriptions_status=:status2 ) ");
    $row      ->  execute(array("id"=>$order_id,"status"=>"active","status2"=>"expired" ));
      if( $row->rowCount() ):
        $row    = $row->fetch(PDO::FETCH_ASSOC);
        $update = $conn->prepare("UPDATE orders SET subscriptions_status=:status WHERE order_id=:id  ");
        $update->execute(array("id"=>$order_id,"status"=>"paused"  ));
        $insert= $conn->prepare("INSERT INTO client_report SET client_id=:c_id, action=:action, report_ip=:ip, report_date=:date ");
        $insert= $insert->execute(array("c_id"=>$user["client_id"],"action"=>"Abonelik durduruldu #".$row["order_id"],"ip"=>GetIP(),"date"=>date("Y-m-d H:i:s") ));
      endif;
    Header("Location:".site_url('subscriptions'));
    exit();
  elseif( route(1) == "resume" ):
    $order_id = route(2);
    $row      =   $conn->prepare("SELECT * FROM orders WHERE order_id=:id && subscriptions_status=:status ");
    $row      ->  execute(array("id"=>$order_id,"status"=>"paused" ));
      if( $row->rowCount() ):
        $row    = $row->fetch(PDO::FETCH_ASSOC);
        $update = $conn->prepare("UPDATE orders SET subscriptions_status=:status WHERE order_id=:id  ");
        $update->execute(array("id"=>$order_id,"status"=>"active"  ));
        $insert= $conn->prepare("INSERT INTO client_report SET client_id=:c_id, action=:action, report_ip=:ip, report_date=:date ");
        $insert= $insert->execute(array("c_id"=>$user["client_id"],"action"=>"Abonelik aktifleştirildi #".$row["order_id"],"ip"=>GetIP(),"date"=>date("Y-m-d H:i:s") ));
      endif;
    Header("Location:".site_url('subscriptions'));
    exit();
  elseif( route(1) == "stop" ):
    $order_id = route(2);
    $row      =   $conn->prepare("SELECT * FROM orders WHERE order_id=:id && ( subscriptions_status=:status || subscriptions_status=:status2 ) ");
    $row      ->  execute(array("id"=>$order_id,"status"=>"paused","status2"=>"active" ));
      if( $row->rowCount() ):
        $row    = $row->fetch(PDO::FETCH_ASSOC);
        $update = $conn->prepare("UPDATE orders SET subscriptions_status=:status WHERE order_id=:id  ");
        $update->execute(array("id"=>$order_id,"status"=>"canceled"  ));
        $insert= $conn->prepare("INSERT INTO client_report SET client_id=:c_id, action=:action, report_ip=:ip, report_date=:date ");
        $insert= $insert->execute(array("c_id"=>$user["client_id"],"action"=>"Abonelik iptal edildi #".$row["order_id"],"ip"=>GetIP(),"date"=>date("Y-m-d H:i:s") ));
      endif;
    Header("Location:".site_url('subscriptions'));
    exit();
  endif;

$status_list  = ["all","active","completed","canceled","paused","expired"];
$search_statu = route(1); if( !route(1) ):  $route[1] = "all";  endif;

  if( !in_array($search_statu,$status_list) ):
    $route[1]         = "all";
  endif;

  if( route(2) ):
    $page         = route(2);
  else:
    $page         = 1;
  endif;
    if( route(1) != "all" ): $search  = "&& subscriptions_status='".route(1)."'"; else: $search = ""; endif;
    if( !empty($_GET["search"]) ): $search.= " && ( order_url LIKE '%".$_GET["search"]."%' ||  order_id LIKE '%".$_GET["search"]."%' ) "; endif;
    $c_id       = $user["client_id"];
    $to         = 25;
    $count      = $conn->query("SELECT * FROM orders WHERE client_id='$c_id' && dripfeed='1' && subscriptions_type='2' $search ")->rowCount();
    $pageCount  = ceil($count/$to);
      if( $page > $pageCount ): $page = 1; endif;
    $where      = ($page*$to)-$to;
    $paginationArr = ["count"=>$pageCount,"current"=>$page,"next"=>$page+1,"previous"=>$page-1];

  $orders = $conn->prepare("SELECT * FROM orders INNER JOIN services WHERE services.service_id = orders.service_id && orders.dripfeed=:dripfeed && orders.subscriptions_type=:subs && orders.client_id=:c_id $search ORDER BY orders.order_id DESC LIMIT $where,$to ");
  $orders-> execute(array("c_id"=>$user["client_id"],"dripfeed"=>1,"subs"=>2 ));
  $orders = $orders->fetchAll(PDO::FETCH_ASSOC);
  $ordersList = [];

    foreach ($orders as $order) {
      $o["id"]              = $order["order_id"];
      $o["date_created"]    = date("d.m.Y H:i:s", (strtotime($order["order_create"])+$user["timezone"]) );
      $o["date_updated"]    = date("d.m.Y H:i:s", (strtotime($order["last_check"])+$user["timezone"]) );
      $o["date_expiry"]     = date("d.m.Y", strtotime($order["subscriptions_expiry"]) ); if( $o["date_expiry"] == "01.01.1970 00:00" ): $o["date_expiry"] = ""; endif;
      $o["link"]            = $order["order_url"];
      $o["service"]         = $order["service_name"];
      $o["posts"]           = $order["subscriptions_posts"];
      $o["current_count"]   = $order["subscriptions_delivery"];
      $o["quantity_min"]    = $order["subscriptions_min"];
      $o["quantity_max"]    = $order["subscriptions_max"];
      $o["delay"]           = ($order["subscriptions_delay"]/60); if( $o["delay"] == 0 ): $o["delay"] = "Gecikme yok"; endif;
      $o["status_name"]     = $languageArray["subscriptions.status.".$order["subscriptions_status"]];
      $o["status"]          = $order["subscriptions_status"];
      array_push($ordersList,$o);
    }
