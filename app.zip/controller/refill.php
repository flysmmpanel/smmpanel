<?php
if (!defined('BASEPATH')) {
  die('Direct access to the script is not allowed');
}

if ($_SESSION["msmbilisim_userlogin"] != 1 || $user["client_type"] == 1) {
  Header("Location:".site_url('logout'));
}

// Last refill order ID session se lo (agar refill button se aya hai)
$highlighted_order_id = null;
if (!empty($_SESSION['last_refill_order_id'])) {
  $highlighted_order_id = $_SESSION['last_refill_order_id'];
  unset($_SESSION['last_refill_order_id']);
}

// Status filter
$status_list = ['all', 'Pending', 'Refilling', 'Completed', 'Rejected', 'Error'];
$status = route(1) ? route(1) : 'all';
if (!in_array($status, $status_list)) $status = 'all';

// Page
$page = route(2) ? route(2) : 1;

// Search
$search_query = '';
$search = '';
if (!empty(urldecode(strip_tags($_GET['search'])))) {
  $search_query = urldecode(strip_tags($_GET['search']));
  $search = " && ( rs.order_id LIKE '%$search_query%' OR rs.order_url LIKE '%$search_query%' ) ";
}

// Status filter SQL
$status_filter = '';
if ($status != 'all') {
  $status_filter = " && rs.refill_status = '$status' ";
}

$c_id = $user['client_id'];
$to = 25;

// Count
$count = $conn->query("SELECT * FROM refill_status rs WHERE rs.client_id='$c_id' $status_filter $search");
$count = $count ? $count->rowCount() : 0;

$pageCount = ceil($count / $to);
if ($page > $pageCount) $page = 1;
$where = $page * $to - $to;

$paginationArr = [
  'count'    => $pageCount,
  'current'  => $page,
  'next'     => $page + 1,
  'previous' => $page - 1,
];

// Fetch refill orders
$refills = $conn->prepare("SELECT rs.*, o.order_url as link, o.order_id as original_order_id 
  FROM refill_status rs 
  LEFT JOIN orders o ON o.order_id = rs.order_id
  WHERE rs.client_id=:c_id $status_filter $search 
  ORDER BY rs.id DESC LIMIT $where,$to");
$refills->execute(['c_id' => $c_id]);
$refills = $refills->fetchAll(PDO::FETCH_ASSOC);

$ordersList = [];
foreach ($refills as $r) {
  $o = [];
  $o['refill_id']     = $r['id'];
  $o['id']            = $r['order_id'];
  $o['date']          = $r['creation_date'];
  $o['link']          = $r['order_url'] ?? $r['link'] ?? '';
  $o['service']       = $r['service_name'];
  $o['refill_status'] = $r['refill_status'];
  $o['highlighted']   = ($r['order_id'] == $highlighted_order_id);
  array_push($ordersList, $o);
}

$orders     = $ordersList;
$pagination = $paginationArr;
$search     = $search_query;