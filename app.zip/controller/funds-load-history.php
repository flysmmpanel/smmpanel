<?php
if(!defined('BASEPATH')){
    die('Direct access not allowed');
}

$title = "Funds & Transaction History";

if($user["client_type"] == 1){
    header("Location:".site_url('logout'));
    exit;
}

if(session_status() == PHP_SESSION_NONE){
    session_start();
}

$client_id = $_SESSION['msmbilisim_userid'] ?? 0;

if(!$client_id){
    header("Location:".site_url('login'));
    exit;
}

// --- Fetch all transactions without pagination ---
$stmt = $conn->prepare("
SELECT * FROM (

    SELECT 
        payment_id AS txn_id,
        payment_create_date AS txn_date,
        payment_amount AS amount,
        'Add Funds' AS type,
        payment_status AS status,
        payment_note AS remarks
    FROM payments
    WHERE client_id = :client_id

    UNION ALL

    SELECT 
        order_id AS txn_id,
        order_create AS txn_date,
        -order_charge AS amount,
        'Order' AS type,
        order_status AS status,
        order_url AS remarks
    FROM orders
    WHERE client_id = :client_id

) AS transactions

ORDER BY txn_date DESC
");

$stmt->bindValue(":client_id",$client_id,PDO::PARAM_INT);
// $stmt->execute();
// $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// // --- No pagination needed ---
// $twig->addGlobal('transactions', $transactions);

$stmt->execute();
$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ✅ YAHAN SE START ADD KARO
$transactionsFormatted = [];

foreach($transactions as $txn){

    $txn['amount'] = format_amount_string(
        $user["currency_type"],
        from_to(
            get_currencies_array("enabled"),
            $settings["site_base_currency"],
            $user["currency_type"],
            $txn['amount']
        )
    );

    $transactionsFormatted[] = $txn;
}


// ✅ NEW USE KARO
$twig->addGlobal('transactions', $transactionsFormatted);

// Directly include Twig template
include 'funds-load-history.twig';