<?php
if (!defined('ADDFUNDS')) {
    http_response_code(404);
    die();
}

// বিকাশ callback প্রসেসিং শুরু
$paymentStatus = $_GET['paymentStatus']; // পেমেন্ট স্ট্যাটাস
$orderId = $_GET['merchantInvoiceNumber']; // অর্ডার আইডি

// পেমেন্ট স্ট্যাটাস চেক করুন এবং ডেটাবেস আপডেট করুন
if ($paymentStatus == 'Completed') {
    $update = $conn->prepare(
        "UPDATE payments SET payment_status=:status WHERE payment_extra=:extra"
    );
    $update->execute([
        "status" => "Completed",
        "extra" => $orderId
    ]);

    echo "Payment Successful!";
} else {
    $update = $conn->prepare(
        "UPDATE payments SET payment_status=:status WHERE payment_extra=:extra"
    );
    $update->execute([
        "status" => "Failed",
        "extra" => $orderId
    ]);

    echo "Payment Failed!";
}
?>