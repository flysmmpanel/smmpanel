<?php
if (!defined('PAYMENT')) {
    http_response_code(404);
    die();
}

require_once("geniusboyverify/lib/binancepay.php");

// Get Binance Pay configuration
$certSn = $methodExtras["cert_sn"];
$secretKey = $methodExtras["secret_key"];

if (empty($certSn) || empty($secretKey)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Configuration error']);
    exit;
}

// Initialize Binance Pay
$binancePay = new BinancePay($certSn, $secretKey);

// Handle payment status check (AJAX request)
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['check_status'])) {
    $prepayId = $_GET['check_status'];
    
    try {
        // Query payment status from Binance Pay
        $paymentInfo = $binancePay->queryOrder($prepayId);
        
        $status = 'pending';
        if (isset($paymentInfo['data']['status'])) {
            $paymentStatus = $paymentInfo['data']['status'];
            
            if ($binancePay->isPaymentSuccessful($paymentStatus)) {
                $status = 'PAY_SUCCESS';
            } elseif ($binancePay->isPaymentFailed($paymentStatus)) {
                $status = 'failed';
            }
        }
        
        header('Content-Type: application/json');
        echo json_encode(['status' => $status]);
        exit;
        
    } catch (Exception $e) {
        header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        exit;
    }
}

// Handle webhook notification (POST request)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Get webhook data and headers
    $headers = getallheaders();
    $body = file_get_contents('php://input');
    
    // Log the webhook for debugging (remove in production)
    error_log("Binance Pay Webhook Body: " . $body);
    error_log("Binance Pay Webhook Headers: " . json_encode($headers));
    
    try {
        // Parse webhook data
        $webhookData = $binancePay->parseWebhook($body);
        
        if (!$webhookData['merchantTradeNo']) {
            http_response_code(400);
            echo "Missing merchant trade number";
            exit;
        }
        
        $merchantTradeNo = $webhookData['merchantTradeNo'];
        $prepayId = $webhookData['prepayId'];
        $status = $webhookData['status'];
        $orderAmount = $webhookData['orderAmount'];
        $totalFee = $webhookData['totalFee'];
        $currency = $webhookData['currency'];
        $transactionId = $webhookData['transactionId'];
        $transactionTime = $webhookData['transactionTime'];
        $payerInfo = $webhookData['payerInfo'];
        $sourceAmount = $webhookData['sourceAmount'];
        $sourceCurrency = $webhookData['sourceCurrency'];
        $fiatAmount = $webhookData['fiatAmount'];
        $fiatCurrency = $webhookData['fiatCurrency'];
        
        // Verify webhook signature if available
        $timestamp = $headers['BinancePay-Timestamp'] ?? $headers['binancepay-timestamp'] ?? null;
        $nonce = $headers['BinancePay-Nonce'] ?? $headers['binancepay-nonce'] ?? null;
        $signature = $headers['BinancePay-Signature'] ?? $headers['binancepay-signature'] ?? null;
        
        if ($signature && $timestamp && $nonce) {
            $webhookDataForVerification = json_decode($body, true);
            if (!$binancePay->verifyWebhook($webhookDataForVerification, $signature, $timestamp, $nonce)) {
                http_response_code(401);
                echo "Invalid signature";
                exit;
            }
        }
        
        // Find payment record
        $paymentDetails = $conn->prepare("SELECT * FROM payments WHERE payment_extra=:order_id");
        $paymentDetails->execute(['order_id' => $merchantTradeNo]);
        
        if (!$paymentDetails->rowCount()) {
            // Try to find by prepay ID if merchant trade no fails
            $paymentDetails = $conn->prepare("SELECT * FROM payments WHERE payment_extra2=:prepay_id");
            $paymentDetails->execute(['prepay_id' => $prepayId]);
            
            if (!$paymentDetails->rowCount()) {
                http_response_code(404);
                echo "Order not found";
                exit;
            }
        }
        
        $paymentDetails = $paymentDetails->fetch(PDO::FETCH_ASSOC);
        
        // Check if already processed
        if ($paymentDetails['payment_status'] == 3) {
            // Already processed successfully
            echo "SUCCESS";
            exit;
        }
        
        // Get user details
        $userDetails = $conn->prepare("SELECT * FROM clients WHERE client_id=:id");
        $userDetails->execute(['id' => $paymentDetails['client_id']]);
        $user = $userDetails->fetch(PDO::FETCH_ASSOC);
        
        if (!$user) {
            http_response_code(404);
            echo "User not found";
            exit;
        }
        
        // Process payment based on status
        if ($binancePay->isPaymentSuccessful($status)) {
            
            // Payment successful
            $expectedAmount = floatval($paymentDetails["payment_amount"]);
            $receivedAmount = floatval($totalFee);
            
            // Use source amount if available (actual paid amount)
            if ($sourceAmount && $sourceAmount > 0) {
                $receivedAmount = floatval($sourceAmount);
                $actualCurrency = $sourceCurrency;
            } else {
                $actualCurrency = $currency;
            }
            
            // Apply fees if configured
            if ($paymentFee > 0) {
                $fee = ($receivedAmount * ($paymentFee / 100));
                $receivedAmount -= $fee;
            }
            
            // Apply bonus if configured
            if ($paymentBonusStartAmount != 0 && $receivedAmount > $paymentBonusStartAmount) {
                $bonus = $receivedAmount * ($paymentBonus / 100);
                $receivedAmount += $bonus;
            }
            
            // Convert currency if needed
            $finalAmount = from_to($currencies_array, $methodCurrency, $settings["site_base_currency"], $receivedAmount);
            
            // Update payment record
            $update = $conn->prepare('UPDATE payments SET 
                client_balance=:balance,
                payment_status=:status, 
                payment_delivery=:delivery,
                payment_update_date=:update_date,
                payment_extra3=:transaction_id
                WHERE payment_id=:id');
            
            $update->execute([
                'balance' => $user["balance"],
                'status' => 3, // Success
                'delivery' => 2, // Delivered
                'update_date' => date("Y.m.d H:i:s"),
                'transaction_id' => $transactionId,
                'id' => $paymentDetails['payment_id']
            ]);
            
            // Update user balance
            $balance = $conn->prepare('UPDATE clients SET balance=:balance WHERE client_id=:id');
            $balance->execute([
                "balance" => $user["balance"] + $finalAmount,
                "id" => $user["client_id"]
            ]);
            
            // Log successful payment
            error_log("Binance Pay: Payment successful for order {$merchantTradeNo}, amount: {$finalAmount}, txid: {$transactionId}");
            
            echo "SUCCESS";
            
        } elseif ($binancePay->isPaymentFailed($status)) {
            
            // Payment failed/cancelled
            $update = $conn->prepare('UPDATE payments SET 
                payment_status=:status, 
                payment_delivery=:delivery,
                payment_update_date=:update_date,
                payment_extra3=:note
                WHERE payment_id=:id');
            
            $update->execute([
                'status' => 2, // Failed
                'delivery' => 1, // Not delivered
                'update_date' => date("Y.m.d H:i:s"),
                'note' => 'Payment ' . $status,
                'id' => $paymentDetails['payment_id']
            ]);
            
            error_log("Binance Pay: Payment failed for order {$merchantTradeNo}, status: {$status}");
            
            echo "SUCCESS";
            
        } elseif ($binancePay->isPaymentPending($status)) {
            
            // Payment pending - update status but don't credit balance yet
            $update = $conn->prepare('UPDATE payments SET 
                payment_status=:status,
                payment_update_date=:update_date,
                payment_extra3=:note
                WHERE payment_id=:id');
            
            $update->execute([
                'status' => 1, // Pending
                'update_date' => date("Y.m.d H:i:s"),
                'note' => 'Payment ' . $status,
                'id' => $paymentDetails['payment_id']
            ]);
            
            error_log("Binance Pay: Payment pending for order {$merchantTradeNo}, status: {$status}");
            
            echo "SUCCESS";
            
        } else {
            
            // Unknown status
            error_log("Binance Pay: Unknown payment status {$status} for order {$merchantTradeNo}");
            echo "SUCCESS";
            
        }
        
    } catch (Exception $e) {
        error_log("Binance Pay webhook error: " . $e->getMessage());
        http_response_code(500);
        echo "Internal error";
    }
    
} elseif ($_SERVER["REQUEST_METHOD"] == "GET") {
    
    // Handle return URL (when user comes back from Binance Pay)
    $status = $_GET['status'] ?? '';
    
    if ($status === 'success') {
        // Redirect to success page
        header("Location: " . site_url("addfunds?payment=success"));
    } elseif ($status === 'cancelled' || $status === 'failed') {
        // Redirect to failed page
        header("Location: " . site_url("addfunds?payment=failed"));
    } else {
        // Default redirect
        header("Location: " . site_url("addfunds"));
    }
    
} else {
    http_response_code(405);
    echo "Method not allowed";
}
?> 