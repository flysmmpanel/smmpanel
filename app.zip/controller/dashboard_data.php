<?php
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(E_ALL);
header('Content-Type: application/json');

require_once __DIR__ . '/../init.php';

if(!isset($_SESSION["msmbilisim_userlogin"]) || $_SESSION["msmbilisim_userlogin"] != 1){
    echo json_encode([]);
    exit;
}

$client_id = $_SESSION["msmbilisim_userid"];

$from = $_GET['from'] ?? date("Y-m-d", strtotime("-6 days"));
$to   = $_GET['to'] ?? date("Y-m-d");

$params = [
    'client_id' => $client_id,
    'from' => $from,
    'to' => $to
];


// ================= ORDERS =================
$orderStmt = $conn->prepare("
    SELECT 
        DATE(order_create) as date,
        SUM(order_status='completed') as completed,
        SUM(order_status='canceled') as canceled,
        SUM(order_status='partial') as partial
    FROM orders
    WHERE client_id = :client_id
    AND DATE(order_create) BETWEEN :from AND :to
    GROUP BY DATE(order_create)
");
$orderStmt->execute($params);
$orderData = $orderStmt->fetchAll(PDO::FETCH_ASSOC);


// ================= PAYMENTS =================
$paymentStmt = $conn->prepare("
    SELECT 
        DATE(payment_create_date) as date,
        SUM(CASE WHEN payment_amount > 0 THEN payment_amount ELSE 0 END) as addedFunds,
        SUM(CASE WHEN payment_amount < 0 THEN payment_amount ELSE 0 END) as deductedFunds
    FROM payments
    WHERE client_id = :client_id
    AND payment_status = 3
    AND DATE(payment_create_date) BETWEEN :from AND :to
    GROUP BY DATE(payment_create_date)
");
$paymentStmt->execute($params);
$paymentData = $paymentStmt->fetchAll(PDO::FETCH_ASSOC);


// ================= ZERO FILL =================
$period = new DatePeriod(
    new DateTime($from),
    new DateInterval('P1D'),
    (new DateTime($to))->modify('+1 day')
);

$finalData = [];

foreach ($period as $dateObj) {

    $date = $dateObj->format("Y-m-d");

    $completed = 0;
    $canceled = 0;
    $partial = 0;
    $addedFunds = 0;
    $deductedFunds = 0;

    foreach ($orderData as $row) {
        if ($row['date'] == $date) {
            $completed = (int)$row['completed'];
            $canceled  = (int)$row['canceled'];
            $partial   = (int)$row['partial'];
            break;
        }
    }

    foreach ($paymentData as $row) {
        if ($row['date'] == $date) {
            $addedFunds    = (float)$row['addedFunds'];
            $deductedFunds = (float)$row['deductedFunds'];
            break;
        }
    }

    $finalData[] = [
        'date' => $date,
        'completed' => $completed,
        'canceled' => $canceled,
        'partial' => $partial,
        'addedFunds' => $addedFunds,
        'deductedFunds' => $deductedFunds
    ];
}

echo json_encode($finalData);
exit;