<?php

/*

 * - by DEV IMON
 

 */

function volzix_fail($msg = "Payment verification failed.")
{
    header("Location: " . site_url("addfunds") . "?error=" . urlencode($msg));
    exit;
}

function volzix_success($msg = "Payment verified successfully.")
{
    header("Location: " . site_url("addfunds") . "?success=" . urlencode($msg));
    exit;
}

function constant_time_equals($a, $b)
{
    if (!is_string($a) || !is_string($b)) return false;
    if (function_exists("hash_equals")) return hash_equals($a, $b);
    if (strlen($a) !== strlen($b)) return false;

    $res = 0;
    for ($i = 0; $i < strlen($a); $i++) {
        $res |= ord($a[$i]) ^ ord($b[$i]);
    }
    return $res === 0;
}

function volzix_inquire($merchant_mid, $secret_key, array $params)
{
    $timestamp = $params["timestamp"];

    if (!empty($params["flow_id"])) {
        $signing_string = $merchant_mid . "|" . $params["flow_id"] . "|" . $timestamp;
        $request_body = [
            "merchant_mid" => $merchant_mid,
            "flow_id"      => $params["flow_id"],
            "timestamp"    => $timestamp,
            "signature"    => hash_hmac("sha256", $signing_string, $secret_key),
        ];
    } else {
        $signing_string = $merchant_mid . "|" . $params["web_id"] . "|" . $timestamp;
        $request_body = [
            "merchant_mid" => $merchant_mid,
            "web_id"       => $params["web_id"],
            "timestamp"    => $timestamp,
            "signature"    => hash_hmac("sha256", $signing_string, $secret_key),
        ];
    }

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://volzix.com/inquire/v1/");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($request_body));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);

    $result    = curl_exec($ch);
    $curl_err  = curl_error($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($result === false) {
        return ["ok" => false, "error" => $curl_err ?: "cURL error"];
    }

    $resp = json_decode($result, true);
    if (!is_array($resp)) {
        return ["ok" => false, "error" => "Invalid JSON response", "raw" => $result];
    }

    if (($resp["status"] ?? "") !== "ok" || empty($resp["payment"])) {
        return [
            "ok"        => false,
            "error"     => $resp["message"] ?? "Inquiry failed",
            "resp"      => $resp,
            "http_code" => $http_code
        ];
    }

    return [
        "ok"        => true,
        "payment"   => $resp["payment"],
        "resp"      => $resp,
        "http_code" => $http_code
    ];
}

// --- Load method config (methodId 37) ---
$methodId = 37;
$method = $conn->prepare("SELECT * FROM paymentmethods WHERE methodId = :id LIMIT 1");
$method->execute(["id" => $methodId]);
$method = $method->fetch(PDO::FETCH_ASSOC);

if (!$method) {
    volzix_fail("Payment method not found.");
}

$methodExtras = json_decode($method["methodExtras"] ?? "{}", true);
$merchant_mid = $methodExtras["merchant_mid"] ?? "";
$secret_key   = $methodExtras["secret_key"] ?? "";

if (!$merchant_mid || !$secret_key) {
    volzix_fail("Volzix is not configured.");
}

// --- Identify transaction ---
$web_id  = isset($_GET["web_id"]) ? trim((string)$_GET["web_id"]) : "";
$flow_id = isset($_GET["flow_id"]) ? trim((string)$_GET["flow_id"]) : "";

if (!$web_id && !$flow_id) {
    volzix_fail("Missing reference.");
}

// --- Fetch pending payment ---
if ($web_id) {
    $paymentDetails = $conn->prepare("SELECT * FROM payments WHERE t_id = ? AND payment_status = 1 LIMIT 1");
    $paymentDetails->execute([$web_id]);
} else {
    $paymentDetails = $conn->prepare("SELECT * FROM payments WHERE payment_extra LIKE ? AND payment_status = 1 LIMIT 1");
    $paymentDetails->execute(['%"flow_id":"' . $flow_id . '"%']);
}

$paymentDetails = $paymentDetails->fetch(PDO::FETCH_ASSOC);

if (!$paymentDetails) {
    volzix_fail("Payment not found or already processed.");
}

// --- Parse stored extra ---
$extra                = json_decode($paymentDetails["payment_extra"] ?? "{}", true);
$stored_web_id        = $extra["web_id"] ?? ($paymentDetails["t_id"] ?? "");
$stored_flow_id       = $extra["flow_id"] ?? ($paymentDetails["trx_id"] ?? "");
$stored_gateway_amount = $extra["gateway_amount"] ?? null;
$stored_currency      = $extra["currency"] ?? null;

// Prefer stored identifiers if missing
if (!$flow_id && $stored_flow_id) {
    $flow_id = (string)$stored_flow_id;
}
if (!$web_id && $stored_web_id) {
    $web_id = (string)$stored_web_id;
}

// --- Inquiry verify ---
$inquiry = volzix_inquire($merchant_mid, $secret_key, [
    "timestamp" => time(),
    "flow_id"   => $flow_id ?: null,
    "web_id"    => $web_id ?: null,
]);

if (!$inquiry["ok"]) {
    error_log("Volzix inquiry failed: " . json_encode($inquiry));
    volzix_fail("Unable to verify payment.");
}

$payment = $inquiry["payment"];
error_log("Volzix inquiry response: " . json_encode($payment));

// --- Ensure identifier match ---
if (!empty($payment["web_id"]) && $stored_web_id && (string)$payment["web_id"] !== (string)$stored_web_id) {
    error_log("Volzix reference mismatch. API web_id=" . ($payment["web_id"] ?? "") . " stored_web_id=" . $stored_web_id);
    volzix_fail("Reference mismatch.");
}

if (!empty($payment["flow_id"]) && $stored_flow_id && (string)$payment["flow_id"] !== (string)$stored_flow_id) {
    error_log("Volzix flow mismatch. API flow_id=" . ($payment["flow_id"] ?? "") . " stored_flow_id=" . $stored_flow_id);
    volzix_fail("Flow mismatch.");
}

// --- Ensure amount/currency match initiated request ---
if ($stored_gateway_amount !== null && isset($payment["amount"])) {
    $api_amount = number_format((float)$payment["amount"], 2, ".", "");
    if (!constant_time_equals((string)$api_amount, (string)$stored_gateway_amount)) {
        error_log("Volzix amount mismatch. API amount=" . $api_amount . " stored_amount=" . $stored_gateway_amount);
        volzix_fail("Amount mismatch.");
    }
}

if ($stored_currency && !empty($payment["currency"]) && strtoupper($payment["currency"]) !== strtoupper($stored_currency)) {
    error_log("Volzix currency mismatch. API currency=" . ($payment["currency"] ?? "") . " stored_currency=" . $stored_currency);
    volzix_fail("Currency mismatch.");
}

// --- Verify completed status ---
$status_code = (int)($payment["status_code"] ?? 0);
if ($status_code !== 200) {
    error_log("Volzix payment not completed. Status code: " . $status_code);
    volzix_fail("Payment not completed.");
}

// --- Load user ---
$user = $conn->prepare("SELECT * FROM clients WHERE client_id = ? LIMIT 1");
$user->execute([$paymentDetails["client_id"]]);
$user = $user->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    error_log("Volzix user not found for client_id=" . ($paymentDetails["client_id"] ?? "null"));
    volzix_fail("User not found.");
}

// --- Update payment row ---
$updatePayment = $conn->prepare("UPDATE payments SET
    payment_status = 3,
    payment_delivery = 2,
    client_balance = ?
    WHERE payment_id = ? AND payment_status = 1");

$updatePayment->execute([
    $user["balance"],
    $paymentDetails["payment_id"]
]);

if ($updatePayment->rowCount() < 1) {
    error_log("Volzix payment update affected 0 rows for payment_id=" . ($paymentDetails["payment_id"] ?? "null"));
    volzix_fail("Payment could not be updated.");
}

// --- Credit client balance ---
$updateClient = $conn->prepare("UPDATE clients SET balance = balance + ? WHERE client_id = ?");
$updateClient->execute([
    $paymentDetails["payment_amount"],
    $user["client_id"]
]);

error_log("Volzix payment completed successfully for payment_id=" . ($paymentDetails["payment_id"] ?? "null"));

volzix_success("Payment completed successfully.");
?>
